import logging

from fastapi import APIRouter, BackgroundTasks, File, Form, HTTPException, UploadFile
from fastapi.responses import JSONResponse

from ..core.settings import get_settings
from ..models.schemas import AnalyzeCertificateAckResponse
from ..services.analysis_pipeline_service import AnalysisPipelineService, AnalysisRequest

logger = logging.getLogger(__name__)
router = APIRouter()


async def _process_in_background(request_data: AnalysisRequest, certificate_bytes: bytes) -> None:
    settings = get_settings()
    pipeline = AnalysisPipelineService(settings)
    await pipeline.process(request_data, certificate_bytes)


# No single response_model: 202 returns ack JSON; wait_for_result=true returns full score payload.
@router.post("/analyze-certificate", status_code=202)
async def analyze_certificate(
    background_tasks: BackgroundTasks,
    parameter_id: str = Form(...),
    tenant_id: str = Form(...),
    student_id: str = Form(...),
    certificate_name: str = Form(...),
    certificate: UploadFile = File(...),
    wait_for_result: bool = Form(False),
):
    try:
        certificate_bytes = await certificate.read()
        if not certificate_bytes:
            raise HTTPException(status_code=400, detail="Uploaded certificate file is empty")

        req = AnalysisRequest(
            parameter_id=parameter_id,
            tenant_id=tenant_id,
            student_id=student_id,
            certificate_name=certificate_name,
        )

        if wait_for_result:
            settings = get_settings()
            pipeline = AnalysisPipelineService(settings)
            result_payload = await pipeline.process(req, certificate_bytes)
            return JSONResponse(
                status_code=200,
                content=result_payload.model_dump_for_spring(),
            )

        background_tasks.add_task(_process_in_background, req, certificate_bytes)

        ack = AnalyzeCertificateAckResponse(
            parameter_id=parameter_id,
            message="Request accepted for asynchronous processing",
        )
        return JSONResponse(status_code=202, content=ack.model_dump())
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Failed to enqueue analysis")
        raise HTTPException(status_code=500, detail=f"Failed to enqueue analysis: {exc}")
