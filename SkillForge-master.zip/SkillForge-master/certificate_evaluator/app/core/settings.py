from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # API
    APP_NAME: str = "Forensic Certificate Analysis Service"
    API_PREFIX: str = "/api"

    # PostgreSQL (RDS)
    DATABASE_URL: str = ""
    DB_HOST: str = ""
    DB_PORT: int = 5432
    DB_NAME: str = ""
    DB_USER: str = ""
    DB_PASSWORD: str = ""

    # AWS Textract
    AWS_ACCESS_KEY_ID: str = ""
    AWS_SECRET_ACCESS_KEY: str = ""
    AWS_REGION: str = "ap-south-1"

    # Azure OpenAI
    AZURE_OPENAI_API_KEY: str = ""
    AZURE_OPENAI_ENDPOINT: str = ""
    AZURE_OPENAI_API_VERSION: str = "2024-02-15-preview"
    AZURE_OPENAI_DEPLOYMENT: str = ""

    # Callback
    WEBHOOK_URL: str = ""
    WEBHOOK_TIMEOUT_SECONDS: float = 20.0

    # Forensic thresholds
    BASELINE_SHIFT_THRESHOLD: float = 0.005
    FONT_SCALE_VARIANCE_THRESHOLD: float = 0.10
    ELA_JPEG_QUALITY: int = 90
    ELA_VARIANCE_THRESHOLD: float = 55.0


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
