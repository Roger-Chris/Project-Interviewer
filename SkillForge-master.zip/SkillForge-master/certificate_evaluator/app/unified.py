"""Mount certificate_evaluator on the unified SkillForge evaluator FastAPI app."""

from __future__ import annotations

import logging
from typing import Any, Sequence

from fastapi import FastAPI

from .routes.analyze_certificate import router as analyze_certificate_router

logger = logging.getLogger(__name__)


def mount_certificate_evaluator(
    app: FastAPI,
    *,
    dependencies: Sequence[Any] | None = None,
) -> bool:
    """
    Attach POST /api/analyze-certificate to the unified SkillForge app.

    Returns True when routes were registered.
    """
    deps: list[Any] = list(dependencies or [])
    app.include_router(
        analyze_certificate_router,
        prefix="/api",
        tags=["certificate-evaluator"],
        dependencies=deps,
    )
    logger.info("certificate_evaluator routes registered at POST /api/analyze-certificate")
    return True
