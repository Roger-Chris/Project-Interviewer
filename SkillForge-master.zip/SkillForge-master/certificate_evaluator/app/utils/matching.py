def compute_match_status(extracted_text: str, expected: str) -> str:
    """Compute text match status as yes/partial/no/no_expected_value/no_text."""
    if not expected:
        return "no_expected_value"
    if not extracted_text:
        return "no_text"

    e_text = extracted_text.lower()
    e_expected = expected.lower()
    if e_expected in e_text:
        return "yes"

    expected_tokens = [token for token in e_expected.split() if token]
    if expected_tokens and all(token in e_text for token in expected_tokens[: max(1, len(expected_tokens) // 2)]):
        return "partial"
    return "no"
