from typing import Any

from pydantic import BaseModel, Field


class AnalyzeCertificateAckResponse(BaseModel):
    status: str = "accepted"
    parameter_id: str
    message: str


class WebhookPayload(BaseModel):
    parameter_id: str
    student_id: str
    confidence_score: float = Field(ge=0.0, le=1.0)
    explanation: str

    def model_dump_for_spring(self) -> dict:
        """Snake_case plus Java-friendly aliases (Jackson often maps score / confidenceScore)."""
        d = self.model_dump()
        s = d["confidence_score"]
        d["score"] = s
        d["confidenceScore"] = s
        return d


class TextractBlockMatch(BaseModel):
    text: str
    block_type: str
    bounding_box: dict[str, float]


class TextractExtractionResult(BaseModel):
    raw_text: str
    student_name_matches: list[TextractBlockMatch] = Field(default_factory=list)
    certificate_name_matches: list[TextractBlockMatch] = Field(default_factory=list)
    line_blocks: list[dict[str, Any]] = Field(default_factory=list)


class LlmSynthesisResult(BaseModel):
    confidence_score: float = Field(ge=0.0, le=1.0)
    explanation: str
