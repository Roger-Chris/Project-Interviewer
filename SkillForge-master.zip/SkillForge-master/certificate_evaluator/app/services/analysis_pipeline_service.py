import logging
from dataclasses import dataclass

from ..core.settings import Settings
from ..models.schemas import LlmSynthesisResult, WebhookPayload
from ..utils.matching import compute_match_status
from .ai_synthesis_service import AISynthesisService
from .database_service import DatabaseService
from .forensic_service import ForensicService
from .textract_service import TextractService
from .webhook_service import WebhookService

logger = logging.getLogger(__name__)


@dataclass
class AnalysisRequest:
    parameter_id: str
    tenant_id: str
    student_id: str
    certificate_name: str


def _manual_score(student_name_status: str, cert_status: str, flags: list[str]) -> float:
    score = 1.0
    if student_name_status == "no":
        score *= 0.2
    elif student_name_status == "partial":
        score *= 0.6

    if cert_status == "no":
        score *= 0.5
    elif cert_status == "partial":
        score *= 0.8

    for flag in flags:
        if flag.startswith("ELA_INSERTION_ANOMALY"):
            score *= 0.35
        elif flag.startswith("BASELINE_SHIFT_ANOMALY") or flag.startswith("FONT_SCALE_ANOMALY"):
            score *= 0.65
        elif "NOT_FOUND" in flag or "FAILED" in flag:
            score *= 0.75

    return max(0.0, min(1.0, score))


class AnalysisPipelineService:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.db_service = DatabaseService(settings)
        self.textract_service = TextractService(settings)
        self.forensic_service = ForensicService(settings)
        self.ai_service = AISynthesisService(settings)
        self.webhook_service = WebhookService(settings)

    async def process(self, request: AnalysisRequest, image_bytes: bytes) -> WebhookPayload:
        explanation_notes: list[str] = []
        expected_name = ""
        extracted_text = ""
        flags: list[str] = []
        student_match_status = "no"
        cert_match_status = "no"

        try:
            # 1) DB lookup
            try:
                expected_name = self.db_service.get_expected_student_name(request.tenant_id, request.student_id) or ""
                if not expected_name:
                    explanation_notes.append("Student not found in DB; running best-effort analysis.")
            except Exception as db_exc:
                logger.exception("Database stage failed")
                explanation_notes.append(f"DB lookup failed: {db_exc}")

            # 2) Textract extraction
            textract_result = None
            try:
                textract_result = self.textract_service.analyze_document(
                    image_bytes=image_bytes,
                    expected_student_name=expected_name,
                    certificate_name=request.certificate_name,
                )
                extracted_text = textract_result.raw_text
            except Exception as tx_exc:
                logger.exception("Textract stage failed")
                flags.append("TEXTRACT_ERROR")
                explanation_notes.append(f"Textract failed: {tx_exc}")

            # 3) Forensic checks
            if textract_result:
                student_match_status = compute_match_status(extracted_text, expected_name)
                cert_match_status = compute_match_status(extracted_text, request.certificate_name)

                try:
                    flags.extend(
                        self.forensic_service.analyze(
                            image_bytes=image_bytes,
                            student_matches=textract_result.student_name_matches,
                            line_blocks=textract_result.line_blocks,
                        )
                    )
                except Exception as fr_exc:
                    logger.exception("Forensic stage failed")
                    flags.append("FORENSIC_STAGE_ERROR")
                    explanation_notes.append(f"Forensic stage failed: {fr_exc}")
            else:
                flags.append("NO_TEXTRACT_RESULT")

            heuristic = _manual_score(student_match_status, cert_match_status, flags)

            # 4) LLM synthesis with fallback
            synthesis: LlmSynthesisResult | None = None
            try:
                synthesis = self.ai_service.synthesize(
                    expected_name=expected_name,
                    certificate_name=request.certificate_name,
                    student_name_match_status=student_match_status,
                    certificate_name_match_status=cert_match_status,
                    forensic_flags=flags,
                )
            except Exception as ai_exc:
                logger.exception("AI synthesis stage failed")
                explanation_notes.append(f"AI synthesis failed: {ai_exc}")

            if synthesis is None:
                synthesis = LlmSynthesisResult(
                    confidence_score=heuristic,
                    explanation="Manual fallback score used due to AI failure.",
                )

            final_score = (0.5 * heuristic) + (0.5 * synthesis.confidence_score)
            if student_match_status == "no":
                final_score = min(final_score, 0.35)
            if any(flag.startswith("ELA_INSERTION_ANOMALY") for flag in flags):
                final_score = min(final_score, 0.40)

            final_score = max(0.0, min(1.0, final_score))
            explanation = synthesis.explanation
            if explanation_notes:
                explanation = f"{explanation} | Notes: {'; '.join(explanation_notes)}"

            payload = WebhookPayload(
                parameter_id=request.parameter_id,
                student_id=request.student_id,
                confidence_score=final_score,
                explanation=explanation,
            )
            try:
                await self.webhook_service.send_callback(payload)
            except Exception as callback_exc:
                logger.exception("Webhook callback failed")
                # Do not fail analysis result just because callback endpoint is unavailable.
                payload.explanation = f"{payload.explanation} | Callback failed: {callback_exc}"
            return payload
        except Exception as fatal_exc:
            logger.exception("Pipeline fatal failure")
            fallback_payload = WebhookPayload(
                parameter_id=request.parameter_id,
                student_id=request.student_id,
                confidence_score=0.0,
                explanation=f"Fatal processing error: {fatal_exc}",
            )
            try:
                await self.webhook_service.send_callback(fallback_payload)
            except Exception:
                logger.exception("Webhook callback failed after fatal error")
            return fallback_payload
