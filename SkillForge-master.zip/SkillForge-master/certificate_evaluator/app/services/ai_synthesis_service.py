import json
import logging

from openai import AzureOpenAI

from ..core.settings import Settings
from ..models.schemas import LlmSynthesisResult

logger = logging.getLogger(__name__)


class AISynthesisService:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.client = AzureOpenAI(
            api_key=settings.AZURE_OPENAI_API_KEY,
            azure_endpoint=settings.AZURE_OPENAI_ENDPOINT,
            api_version=settings.AZURE_OPENAI_API_VERSION,
        )

    def synthesize(
        self,
        expected_name: str,
        certificate_name: str,
        student_name_match_status: str,
        certificate_name_match_status: str,
        forensic_flags: list[str],
    ) -> LlmSynthesisResult:
        system_prompt = (
            "You are a forensic document examiner. "
            "Return STRICT JSON only with keys: confidence_score (float 0-1) and explanation (short string). "
            "Heavily penalize score for name mismatch and severe spatial/ELA anomalies."
        )
        user_payload = {
            "expected_student_name": expected_name,
            "certificate_name": certificate_name,
            "student_name_match_status": student_name_match_status,
            "certificate_name_match_status": certificate_name_match_status,
            "forensic_flags": forensic_flags,
        }

        response = self.client.chat.completions.create(
            model=self.settings.AZURE_OPENAI_DEPLOYMENT,
            temperature=0.0,
            response_format={"type": "json_object"},
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": json.dumps(user_payload)},
            ],
        )

        content = response.choices[0].message.content if response.choices else "{}"
        parsed = json.loads(content or "{}")
        confidence = float(parsed.get("confidence_score", 0.0))
        confidence = max(0.0, min(1.0, confidence))
        explanation = str(parsed.get("explanation", "No explanation provided"))
        return LlmSynthesisResult(confidence_score=confidence, explanation=explanation)
