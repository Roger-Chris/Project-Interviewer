import logging

import boto3

from ..core.settings import Settings
from ..models.schemas import TextractBlockMatch, TextractExtractionResult

logger = logging.getLogger(__name__)


class TextractService:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.client = boto3.client(
            "textract",
            region_name=settings.AWS_REGION,
            aws_access_key_id=settings.AWS_ACCESS_KEY_ID or None,
            aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY or None,
        )

    @staticmethod
    def _contains_phrase(text: str, phrase: str) -> bool:
        if not phrase:
            return False
        return phrase.lower() in text.lower()

    def analyze_document(self, image_bytes: bytes, expected_student_name: str, certificate_name: str) -> TextractExtractionResult:
        response = self.client.analyze_document(Document={"Bytes": image_bytes}, FeatureTypes=["FORMS"])
        blocks = response.get("Blocks", [])

        line_blocks: list[dict] = []
        raw_text_lines: list[str] = []
        student_matches: list[TextractBlockMatch] = []
        certificate_matches: list[TextractBlockMatch] = []

        for block in blocks:
            if block.get("BlockType") not in {"LINE", "WORD"}:
                continue
            text = block.get("Text", "")
            bbox = block.get("Geometry", {}).get("BoundingBox", {})
            if block.get("BlockType") == "LINE":
                raw_text_lines.append(text)
                line_blocks.append({"text": text, "bounding_box": bbox, "id": block.get("Id")})

            if self._contains_phrase(text, expected_student_name):
                student_matches.append(
                    TextractBlockMatch(text=text, block_type=block.get("BlockType", ""), bounding_box=bbox)
                )

            if self._contains_phrase(text, certificate_name):
                certificate_matches.append(
                    TextractBlockMatch(text=text, block_type=block.get("BlockType", ""), bounding_box=bbox)
                )

        return TextractExtractionResult(
            raw_text="\n".join(raw_text_lines),
            student_name_matches=student_matches,
            certificate_name_matches=certificate_matches,
            line_blocks=line_blocks,
        )
