import logging
from contextlib import contextmanager
from typing import Generator

import psycopg2

from ..core.settings import Settings

logger = logging.getLogger(__name__)


class DatabaseService:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings

    @contextmanager
    def _connect(self) -> Generator:
        conn = None
        try:
            if self.settings.DATABASE_URL:
                conn = psycopg2.connect(self.settings.DATABASE_URL)
            else:
                conn = psycopg2.connect(
                    host=self.settings.DB_HOST,
                    port=self.settings.DB_PORT,
                    dbname=self.settings.DB_NAME,
                    user=self.settings.DB_USER,
                    password=self.settings.DB_PASSWORD,
                )
            yield conn
        finally:
            if conn is not None:
                conn.close()

    def get_expected_student_name(self, tenant_id: str, student_id: str) -> str | None:
        query = "SELECT name FROM students WHERE tenant_id = %s AND id = %s LIMIT 1"
        with self._connect() as conn:
            with conn.cursor() as cur:
                cur.execute(query, (tenant_id, student_id))
                row = cur.fetchone()
                if not row:
                    logger.warning("No student record found for tenant_id=%s student_id=%s", tenant_id, student_id)
                    return None
                return str(row[0]).strip() if row[0] is not None else None
