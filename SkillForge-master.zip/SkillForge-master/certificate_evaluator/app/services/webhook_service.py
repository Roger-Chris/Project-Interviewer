import logging

import httpx

from ..core.settings import Settings
from ..models.schemas import WebhookPayload

logger = logging.getLogger(__name__)


class WebhookService:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings

    async def send_callback(self, payload: WebhookPayload) -> None:
        if not self.settings.WEBHOOK_URL:
            # Optional: async flow posts results here; omit in local dev without a Spring callback.
            logger.debug("WEBHOOK_URL not set; skipping HTTP callback.")
            return

        timeout = httpx.Timeout(self.settings.WEBHOOK_TIMEOUT_SECONDS)
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.post(
                self.settings.WEBHOOK_URL,
                json=payload.model_dump_for_spring(),
            )
            response.raise_for_status()
