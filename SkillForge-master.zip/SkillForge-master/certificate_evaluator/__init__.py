"""Certificate forensic analysis service (mounted on unified SkillForge API)."""
