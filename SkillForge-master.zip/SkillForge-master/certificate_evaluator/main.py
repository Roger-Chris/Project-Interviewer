"""Standalone entrypoint: uvicorn certificate_evaluator.main:app (from SkillForge repo root)."""

from certificate_evaluator.app.main import app, create_app

__all__ = ["app", "create_app"]
