"""
FastAPI app — health + optional RDS pool lifecycle.
"""

from contextlib import asynccontextmanager

try:
    from dotenv import load_dotenv

    from skillforge_env import resolve_dotenv_path

    load_dotenv(resolve_dotenv_path())
except ImportError:
    pass

from fastapi import FastAPI

from core import db
from routers import student_chat


@asynccontextmanager
async def lifespan(app: FastAPI):
    await db.get_pool()
    yield
    await db.close_pool()


app = FastAPI(title="Student AI Service", version="0.1.0", lifespan=lifespan)

app.include_router(student_chat.router, prefix="/chat", tags=["student-chat"])


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/health/db")
async def health_db() -> dict:
    """Deep check: Amazon RDS reachable; includes ai_db_ping() if deployed."""
    return await db.ping_database()


if __name__ == "__main__":
    import os

    import uvicorn

    port = int(os.environ.get("PORT", "8000"))
    uvicorn.run("main:app", host="0.0.0.0", port=port)
