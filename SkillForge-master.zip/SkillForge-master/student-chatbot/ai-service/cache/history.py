"""
Redis list of prior chat turns (user + assistant text only).

If neither ``REDIS_URL`` nor ``REDIS_HOST``/``REDIS_PASSWORD`` is set, history
is skipped — chat still works without memory. Azure: use ``rediss://`` or split
vars (see ``_resolve_redis_url``).
"""

from __future__ import annotations

import json
import os
from typing import Any
from urllib.parse import quote_plus

_redis: Any = None


def _resolve_redis_url() -> str | None:
    """
    Prefer REDIS_URL if set.

    Otherwise build from Azure Managed Redis-style vars:
    REDIS_HOST, REDIS_PORT (e.g. 10000), REDIS_USERNAME, REDIS_PASSWORD, REDIS_SSL_ENABLED.
    Use scheme ``rediss://`` when TLS is enabled (default for split config).
    """
    direct = os.environ.get("REDIS_URL", "").strip()
    if direct:
        return direct

    host = os.environ.get("REDIS_HOST", "").strip()
    password = os.environ.get("REDIS_PASSWORD", "").strip()
    if not host or not password:
        return None

    port = os.environ.get("REDIS_PORT", "10000").strip() or "10000"
    username = os.environ.get("REDIS_USERNAME", "default").strip() or "default"
    ssl_raw = os.environ.get("REDIS_SSL_ENABLED", "true").strip().lower()
    use_tls = ssl_raw in ("true", "1", "yes", "on")
    scheme = "rediss" if use_tls else "redis"

    user_q = quote_plus(username, safe="")
    pass_q = quote_plus(password, safe="")
    return f"{scheme}://{user_q}:{pass_q}@{host}:{port}/0"


async def get_redis():
    global _redis
    if _redis is not None:
        return _redis
    url = _resolve_redis_url()
    if not url:
        return None
    import redis.asyncio as redis  # noqa: PLC0415

    _redis = redis.from_url(
        url,
        decode_responses=True,
        socket_connect_timeout=float(
            os.environ.get("REDIS_SOCKET_TIMEOUT_S", "10").strip() or "10"
        ),
    )
    return _redis


def history_key(*, tenant_id: str, student_id: str, session_id: str) -> str:
    sid = session_id.strip() or "default"
    return f"ai:chat:{tenant_id}:{student_id}:{sid}"


async def load_chat_messages(
    *,
    tenant_id: str,
    student_id: str,
    session_id: str,
    max_messages: int | None = None,
) -> list[dict[str, str]]:
    """
    Load prior turns as OpenAI-style messages with role user|assistant and content.
    """
    if max_messages is None:
        raw = os.environ.get("CHAT_HISTORY_MAX_MESSAGES", "40").strip()
        try:
            max_messages = max(2, int(raw))
        except ValueError:
            max_messages = 40

    client = await get_redis()
    if client is None:
        return []

    key = history_key(
        tenant_id=tenant_id, student_id=student_id, session_id=session_id
    )
    raw_list = await client.lrange(key, -max_messages, -1)
    out: list[dict[str, str]] = []
    for item in raw_list:
        try:
            d = json.loads(item)
            role = d.get("role")
            content = d.get("content")
            if role in ("user", "assistant") and isinstance(content, str):
                out.append({"role": role, "content": content})
        except (json.JSONDecodeError, TypeError):
            continue
    return out


async def append_chat_messages(
    *,
    tenant_id: str,
    student_id: str,
    session_id: str,
    messages: list[dict[str, str]],
    max_stored: int | None = None,
    ttl_seconds: int | None = None,
) -> None:
    """Append one or more user/assistant messages and trim the list."""
    if max_stored is None:
        raw = os.environ.get("CHAT_HISTORY_MAX_MESSAGES", "40").strip()
        try:
            max_stored = max(2, int(raw))
        except ValueError:
            max_stored = 40
    if ttl_seconds is None:
        raw_ttl = os.environ.get("CHAT_HISTORY_TTL_SECONDS", "604800").strip()
        try:
            ttl_seconds = max(60, int(raw_ttl))
        except ValueError:
            ttl_seconds = 604800

    client = await get_redis()
    if client is None:
        return

    key = history_key(
        tenant_id=tenant_id, student_id=student_id, session_id=session_id
    )
    for m in messages:
        role = m.get("role")
        content = m.get("content")
        if role not in ("user", "assistant") or not isinstance(content, str):
            continue
        await client.rpush(key, json.dumps({"role": role, "content": content}))
    await client.ltrim(key, -max_stored, -1)
    await client.expire(key, ttl_seconds)
