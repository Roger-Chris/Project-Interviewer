# Redis cache (chat history)
