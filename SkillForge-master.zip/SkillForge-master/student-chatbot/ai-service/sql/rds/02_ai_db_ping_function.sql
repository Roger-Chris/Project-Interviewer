-- Run as schema owner after your application tables exist.
-- Grants EXECUTE to ai_readonly so the Python service can sanity-check RDS from code.

CREATE OR REPLACE FUNCTION public.ai_db_ping()
RETURNS timestamptz
LANGUAGE sql
SECURITY INVOKER
STABLE
AS $$
  SELECT now();
$$;

-- GRANT EXECUTE ON FUNCTION public.ai_db_ping() TO ai_readonly;
