"""Resolve SkillForge/.env with fallback to ai-service/.env (legacy)."""

from pathlib import Path


def resolve_dotenv_path() -> Path:
    here = Path(__file__).resolve().parent
    # SkillForge/student-chatbot/ai-service -> SkillForge/.env
    skillforge_env = here.parent.parent / ".env"
    # Legacy: one extra repo nesting level
    legacy_env = here.parent.parent.parent / ".env"
    local = here / ".env"
    if skillforge_env.is_file():
        return skillforge_env
    if legacy_env.is_file():
        return legacy_env
    if local.is_file():
        return local
    return skillforge_env
