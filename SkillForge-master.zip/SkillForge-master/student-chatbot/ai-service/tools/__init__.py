# LLM-callable student tools (use with request context set by the router)
