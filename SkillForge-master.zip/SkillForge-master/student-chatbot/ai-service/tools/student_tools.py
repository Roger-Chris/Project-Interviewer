"""
Student chat tool functions — tenant/student come from request context only
(set by the gateway from JWT), never from LLM arguments.

Aligned with database_schema.md: students, student_skills, student_job_fitments,
student_experience_submissions, student_formal_submissions (CERTIFICATE), gaps vs job_skill_requirements.
"""

from __future__ import annotations

import asyncio
import re
from typing import Any

from core import context as request_context
from core import student_repository

EXPERIENCE_TYPES = {"HACKATHON", "PROJECT", "INTERNSHIP"}
ACADEMIC_TYPES = {"ASSESSMENT", "ACADEMICS", "CERTIFICATE"}
_STOPWORDS = {
    "i",
    "me",
    "my",
    "for",
    "about",
    "in",
    "on",
    "to",
    "the",
    "a",
    "an",
    "and",
    "want",
    "need",
    "learn",
    "improve",
    "roadmap",
    "progress",
    "skill",
    "skills",
    "job",
    "role",
    "certificate",
    "certification",
    "certifications",
    "course",
    "courses",
}


def _ctx() -> tuple[str, str] | None:
    ident = request_context.get_identity()
    if ident is None:
        return None
    return ident.tenant_id, ident.student_id


def _fallback_queries(raw_text: str) -> list[str]:
    cleaned = (raw_text or "").strip()
    if not cleaned:
        return []

    normalized = re.sub(r"[^A-Za-z0-9+#. ]+", " ", cleaned)
    normalized = re.sub(r"\s+", " ", normalized).strip()

    queries: list[str] = []
    for q in (cleaned, normalized):
        if q and q not in queries:
            queries.append(q)

    tokens = [
        t
        for t in normalized.split(" ")
        if len(t) >= 3 and t.lower() not in _STOPWORDS
    ]

    if len(tokens) >= 2:
        # Highest-signal bigrams first: "react jsx", "data analyst" etc.
        for i in range(len(tokens) - 1):
            bg = f"{tokens[i]} {tokens[i + 1]}"
            if bg not in queries:
                queries.append(bg)

    for t in tokens:
        if t not in queries:
            queries.append(t)

    return queries[:8]


async def get_my_profile() -> dict[str, Any]:
    ids = _ctx()
    if ids is None:
        return {"error": "identity_not_set"}
    tenant_id, student_id = ids
    row = await student_repository.fetch_student_row(
        tenant_id=tenant_id, student_id=student_id
    )
    if row is None:
        return {"profile": None, "note": "no student row"}
    return {"profile": row}


async def get_my_skills() -> dict[str, Any]:
    ids = _ctx()
    if ids is None:
        return {"error": "identity_not_set"}
    tenant_id, student_id = ids
    skills = await student_repository.fetch_student_skills(
        tenant_id=tenant_id, student_id=student_id
    )
    return {"skills": skills, "count": len(skills)}


async def get_my_certificates() -> dict[str, Any]:
    """Formal submissions with parameter_type = CERTIFICATE (see schema)."""
    ids = _ctx()
    if ids is None:
        return {"error": "identity_not_set"}
    tenant_id, student_id = ids
    rows = await student_repository.fetch_student_certificate_submissions(
        tenant_id=tenant_id, student_id=student_id
    )
    return {"certificates": rows, "count": len(rows)}


async def get_certificate_recommendations(query_text: str = "") -> dict[str, Any]:
    """
    Recommend available certificates from DB catalog (`formal_parameters` type CERTIFICATE)
    excluding certificates already completed/approved by the student.
    """
    ids = _ctx()
    if ids is None:
        return {"error": "identity_not_set"}
    tenant_id, student_id = ids

    cleaned = (query_text or "").strip()
    attempted = _fallback_queries(cleaned) if cleaned else []
    if not attempted:
        attempted = [""]

    matched_query: str | None = None
    rows: list[dict[str, Any]] = []
    for q in attempted:
        candidate_rows = await student_repository.fetch_available_certificates_for_student(
            tenant_id=tenant_id,
            student_id=student_id,
            query_text=q,
            limit=10,
        )
        if candidate_rows:
            rows = candidate_rows
            matched_query = q
            break

    if not rows and attempted != [""]:
        # last fallback: broad catalog (still excludes completed certs)
        rows = await student_repository.fetch_available_certificates_for_student(
            tenant_id=tenant_id,
            student_id=student_id,
            query_text="",
            limit=10,
        )

    completed_rows = await student_repository.fetch_student_certificate_submissions(
        tenant_id=tenant_id,
        student_id=student_id,
    )
    completed_parameter_ids = sorted(
        {
            str(r.get("parameter_id"))
            for r in completed_rows
            if str(r.get("parameter_id") or "").strip()
            and str(r.get("status") or "").upper() in {"APPROVED", "COMPLETED"}
        }
    )

    return {
        "query_text": cleaned,
        "matched_query": matched_query,
        "attempted_queries": attempted,
        "recommended_certificates": rows,
        "recommended_count": len(rows),
        "completed_certificate_parameter_ids": completed_parameter_ids,
        "completed_certificate_count": len(completed_parameter_ids),
        "note": (
            "Recommendations are fetched from formal_parameters (CERTIFICATE) and exclude already completed certificates."
        ),
    }


async def get_my_job_fitment() -> dict[str, Any]:
    ids = _ctx()
    if ids is None:
        return {"error": "identity_not_set"}
    tenant_id, student_id = ids
    rows = await student_repository.fetch_student_job_fitments(
        tenant_id=tenant_id, student_id=student_id
    )
    return {"fitments": rows, "count": len(rows)}


async def get_my_experience() -> dict[str, Any]:
    ids = _ctx()
    if ids is None:
        return {"error": "identity_not_set"}
    tenant_id, student_id = ids
    rows = await student_repository.fetch_student_experience(
        tenant_id=tenant_id, student_id=student_id
    )
    return {"experience": rows, "count": len(rows)}


async def get_my_recommendations() -> dict[str, Any]:
    """
    Skill rows for the best fitment job: required weight vs student proficiency
    (NULL proficiency = gap to improve).
    """
    ids = _ctx()
    if ids is None:
        return {"error": "identity_not_set"}
    tenant_id, student_id = ids
    data = await student_repository.fetch_skill_gaps_for_best_fit_job(
        tenant_id=tenant_id, student_id=student_id
    )
    return data


async def get_job_fit_details(job_name: str) -> dict[str, Any]:
    """
    Job-specific fitment and gap analysis for the logged-in student.
    """
    ids = _ctx()
    if ids is None:
        return {"error": "identity_not_set"}
    tenant_id, student_id = ids

    cleaned = (job_name or "").strip()
    if not cleaned:
        return {"error": "missing_job_name"}

    candidates: list[dict[str, Any]] = []
    matched_query: str | None = None
    attempted = _fallback_queries(cleaned)
    for query in attempted:
        rows = await student_repository.find_job_by_name(
            tenant_id=tenant_id,
            job_name=query,
        )
        if rows:
            candidates = rows
            matched_query = query
            break

    if not candidates:
        return {
            "job_name": cleaned,
            "matches": [],
            "note": "No matching active job found for your tenant",
            "attempted_queries": attempted,
        }

    job = candidates[0]
    job_details, student_skills, fitment = await asyncio.gather(
        student_repository.get_job_details(
            tenant_id=tenant_id,
            job_ontology_id=job["job_ontology_id"],
        ),
        student_repository.fetch_student_skills(
            tenant_id=tenant_id,
            student_id=student_id,
        ),
        student_repository.get_job_fitment_score(
            tenant_id=tenant_id,
            student_id=student_id,
            job_ontology_id=job["job_ontology_id"],
        ),
    )

    skill_map = {s["skill_id"]: s for s in student_skills}
    gap_list: list[dict[str, Any]] = []
    for req in job_details:
        s = skill_map.get(req["skill_id"])
        score = float(s["proficiency_score"]) if s and s.get("proficiency_score") is not None else 0.0
        threshold = float(req["skill_weightage"] or 0)
        gap_list.append(
            {
                "skill_id": req["skill_id"],
                "skill_name": req["skill_name"],
                "required_weightage": threshold,
                "group": req.get("group_category"),
                "priority_label_from_db": req.get("group_category"),
                "student_score": round(score, 2),
                "skill_level": s.get("skill_level") if s else "NOT_STARTED",
                "gap": round(max(0.0, threshold - score), 2),
                "status": (
                    "not_started"
                    if score == 0
                    else "meets_requirement"
                    if score >= threshold
                    else "needs_work"
                ),
            }
        )
    gap_list.sort(key=lambda x: x["gap"], reverse=True)

    return {
        "job_name": cleaned,
        "matched_query": matched_query,
        "matches": [
            {
                "job_ontology_id": c["job_ontology_id"],
                "job_title": c["job_title"],
                "required_level": c.get("required_level"),
            }
            for c in candidates
        ],
        "selected_job": {
            "job_ontology_id": job["job_ontology_id"],
            "title": job["job_title"],
            "description": job.get("description"),
            "market_insight": job.get("market_insight"),
            "required_level": job.get("required_level"),
            "must_have_weightage": float(job.get("must_have_weightage") or 0),
            "good_to_have_weightage": float(job.get("good_to_have_weightage") or 0),
        },
        "existing_fitment_score": float(fitment["fitment_score"]) if fitment else None,
        "gap_analysis": gap_list,
        "summary": {
            "total_skills": len(gap_list),
            "meets_requirement": sum(
                1 for g in gap_list if g["status"] == "meets_requirement"
            ),
            "needs_work": sum(1 for g in gap_list if g["status"] == "needs_work"),
            "not_started": sum(1 for g in gap_list if g["status"] == "not_started"),
        },
    }


async def get_skill_progress_details(skill_name: str) -> dict[str, Any]:
    """
    Skill-specific rubric, evidence, and history for the logged-in student.
    """
    ids = _ctx()
    if ids is None:
        return {"error": "identity_not_set"}
    tenant_id, student_id = ids

    cleaned = (skill_name or "").strip()
    if not cleaned:
        return {"error": "missing_skill_name"}

    candidates: list[dict[str, Any]] = []
    matched_query: str | None = None
    attempted = _fallback_queries(cleaned)
    for query in attempted:
        rows = await student_repository.find_skill_by_name(
            tenant_id=tenant_id,
            skill_name=query,
        )
        if rows:
            candidates = rows
            matched_query = query
            break

    if not candidates:
        return {
            "skill_name": cleaned,
            "matches": [],
            "note": "No matching active skill found",
            "attempted_queries": attempted,
        }

    skill = candidates[0]
    skill_id = skill["skill_id"]

    rubric_rows, all_skills, formal_ev, exp_ev, history = await asyncio.gather(
        student_repository.get_skill_rubric(tenant_id=tenant_id, skill_id=skill_id),
        student_repository.fetch_student_skills(tenant_id=tenant_id, student_id=student_id),
        student_repository.get_student_formal_evidence(
            tenant_id=tenant_id,
            student_id=student_id,
            skill_id=skill_id,
        ),
        student_repository.get_student_experience_evidence(
            tenant_id=tenant_id,
            student_id=student_id,
            skill_id=skill_id,
        ),
        student_repository.get_skill_history(
            tenant_id=tenant_id,
            student_id=student_id,
            skill_id=skill_id,
        ),
    )

    student_skill = next((s for s in all_skills if s["skill_id"] == skill_id), None)

    submitted_types = {str(e.get("parameter_type", "")).upper() for e in formal_ev}
    submitted_types |= {str(e.get("type", "")).upper() for e in exp_ev}

    unused = sorted(
        [r for r in rubric_rows if str(r.get("type", "")).upper() not in submitted_types],
        key=lambda r: float(r.get("type_weightage") or 0),
        reverse=True,
    )

    return {
        "skill_name": cleaned,
        "matched_query": matched_query,
        "matches": [
            {
                "skill_id": c["skill_id"],
                "skill_name": c["skill_name"],
                "type": c.get("type"),
            }
            for c in candidates
        ],
        "selected_skill": {
            "skill_id": skill_id,
            "name": skill["skill_name"],
            "description": skill.get("description"),
        },
        "current_score": (
            round(float(student_skill["proficiency_score"]), 2)
            if student_skill and student_skill.get("proficiency_score") is not None
            else None
        ),
        "skill_level": (
            student_skill.get("skill_level") if student_skill else "NOT_STARTED"
        ),
        "rubric": {
            "experience_channel": [
                {
                    "type": r["type"],
                    "weight": float(r.get("type_weightage") or 0),
                    "max_count": r.get("count"),
                }
                for r in rubric_rows
                if str(r.get("type", "")).upper() in EXPERIENCE_TYPES
            ],
            "academics_channel": [
                {
                    "type": r["type"],
                    "weight": float(r.get("type_weightage") or 0),
                    "max_count": r.get("count"),
                }
                for r in rubric_rows
                if str(r.get("type", "")).upper() in ACADEMIC_TYPES
            ],
        },
        "evidence_summary": {
            "formal_count": len(formal_ev),
            "experience_count": len(exp_ev),
            "recent_formal": formal_ev[:3],
            "recent_experience": exp_ev[:3],
        },
        "highest_impact_unused_channels": [
            {
                "type": r["type"],
                "weight": float(r.get("type_weightage") or 0),
                "max_submissions": r.get("count"),
            }
            for r in unused[:3]
        ],
        "score_history": history,
    }


async def get_recommended_jobs_detailed() -> dict[str, Any]:
    """
    Rank active jobs by stored fitment score and include strong student skills.
    """
    ids = _ctx()
    if ids is None:
        return {"error": "identity_not_set"}
    tenant_id, student_id = ids

    all_jobs, student_skills = await asyncio.gather(
        student_repository.get_active_jobs_for_tenant(tenant_id=tenant_id),
        student_repository.fetch_student_skills(tenant_id=tenant_id, student_id=student_id),
    )

    sample = all_jobs[:20]
    fitments = await asyncio.gather(
        *[
            student_repository.get_job_fitment_score(
                tenant_id=tenant_id,
                student_id=student_id,
                job_ontology_id=j["job_ontology_id"],
            )
            for j in sample
        ]
    )

    ranked = sorted(
        [
            {
                "job_title": j["job_title"],
                "description": j.get("description"),
                "required_level": j.get("required_level"),
                "fitment_score": float(f["fitment_score"]),
            }
            for j, f in zip(sample, fitments)
            if f is not None and f.get("fitment_score") is not None
        ],
        key=lambda x: x["fitment_score"],
        reverse=True,
    )[:5]

    strong_skills = [
        {
            "name": s["skill_name"],
            "score": round(float(s["proficiency_score"]), 2),
            "level": s["skill_level"],
        }
        for s in student_skills
        if s.get("proficiency_score") is not None and float(s["proficiency_score"]) >= 70
    ][:8]

    return {
        "top_matched_jobs": ranked,
        "student_skill_count": len(student_skills),
        "strong_skills": strong_skills,
    }
