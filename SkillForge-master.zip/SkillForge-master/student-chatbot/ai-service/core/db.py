"""
PostgreSQL async pool (asyncpg) — AWS RDS, Azure, or local.

Supports:
- `DATABASE_URL` = postgresql://...
- `DB_URL` = jdbc:postgresql://... (Java/Spring style) + `DB_USERNAME`, `DB_PASSWORD`,
  optional `DB_NAME` to override the path segment
- `DATABASE_SSL_CA` / `SSL_ROOTCERT` — PEM path for verify-full (matches JDBC sslrootcert)
"""

from __future__ import annotations

import os
import ssl
from typing import Any
from urllib.parse import parse_qs, quote, quote_plus, unquote, urlparse

_pool: Any = None


def _strip_host_scheme(raw: str) -> str:
    h = raw.strip()
    for prefix in ("https://", "http://"):
        if h.lower().startswith(prefix):
            h = h[len(prefix) :]
    return h.split("/")[0].strip()


def _parse_jdbc_postgresql(jdbc: str) -> dict[str, Any] | None:
    """Parse jdbc:postgresql://host:port/dbname?sslmode=...&sslrootcert=..."""
    s = jdbc.strip()
    if not s.lower().startswith("jdbc:postgresql:"):
        return None
    inner = s[len("jdbc:") :]  # postgresql://...
    p = urlparse(inner)
    if p.scheme != "postgresql" or not p.hostname:
        return None
    port = p.port or 5432
    dbname = (p.path or "").lstrip("/").split("/")[0]
    qs = parse_qs(p.query)
    sslmode = (qs.get("sslmode") or ["require"])[0]
    cert_raw = (qs.get("sslrootcert") or [None])[0]
    cert = unquote(cert_raw) if cert_raw else None
    return {
        "host": p.hostname,
        "port": port,
        "dbname": dbname,
        "sslmode": sslmode,
        "sslrootcert": cert,
    }


def _database_url_from_parts() -> str | None:
    host = (
        os.environ.get("POSTGRES_HOST", "").strip()
        or os.environ.get("AZURE_POSTGRES_HOST", "").strip()
        or os.environ.get("DB_HOST", "").strip()
    )
    user = (
        os.environ.get("POSTGRES_USER", "").strip()
        or os.environ.get("AZURE_POSTGRES_USER", "").strip()
        or os.environ.get("DB_USERNAME", "").strip()
        or os.environ.get("DB_USER", "").strip()
    )
    password = (
        os.environ.get("POSTGRES_PASSWORD", "").strip()
        or os.environ.get("AZURE_POSTGRES_PASSWORD", "").strip()
        or os.environ.get("DB_PASSWORD", "").strip()
    )
    db = (
        os.environ.get("POSTGRES_DB", "").strip()
        or os.environ.get("POSTGRES_DATABASE", "").strip()
        or os.environ.get("AZURE_POSTGRES_DATABASE", "").strip()
        or os.environ.get("DB_NAME", "").strip()
    )
    port = (
        os.environ.get("POSTGRES_PORT", "").strip()
        or os.environ.get("AZURE_POSTGRES_PORT", "").strip()
        or os.environ.get("DB_PORT", "").strip()
        or "5432"
    )
    if not (host and user and password and db):
        return None

    host = _strip_host_scheme(host)
    env_mode = os.environ.get("DATABASE_SSLMODE", "").strip().lower()
    if env_mode in ("disable", "false", "0"):
        ssl_q = "disable"
    elif env_mode in ("require", "verify-full", "verify-ca", "allow", "prefer"):
        ssl_q = env_mode
    elif _is_local_pg_host(host):
        ssl_q = "disable"
    else:
        ssl_q = "require"

    user_q = quote_plus(user, safe="")
    pass_q = quote_plus(password, safe="")
    db_path = quote(db, safe="")

    return (
        f"postgresql://{user_q}:{pass_q}@{host}:{port}/{db_path}?sslmode={ssl_q}"
    )


def _is_local_pg_host(hostname: str | None) -> bool:
    if not hostname:
        return False
    h = hostname.lower().strip()
    return h in ("localhost", "127.0.0.1", "::1")


def _ssl_from_env_and_ca(cafile: str | None) -> bool | ssl.SSLContext:
    mode = os.environ.get("DATABASE_SSLMODE", "require").strip().lower()
    ca = (
        (cafile or "").strip()
        or os.environ.get("DATABASE_SSL_CA", "").strip()
        or os.environ.get("SSL_ROOTCERT", "").strip()
    )
    if mode in ("disable", "false", "0"):
        return False
    if ca:
        return ssl.create_default_context(cafile=ca)
    if mode in ("require", "allow", "prefer"):
        # Encrypt transport but do not require CA validation unless a CA file is provided.
        # This avoids local/dev failures with managed DB certificate chains.
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return ctx
    return ssl.create_default_context()


def _ssl_for_plain_dsn(dsn: str) -> bool | ssl.SSLContext:
    """
    asyncpg `ssl=` must match the server. Local Postgres often has no TLS;
    RDS/Azure need TLS. Honor sslmode in the URL and DATABASE_SSLMODE.
    """
    p = urlparse(dsn)
    qs = parse_qs(p.query)
    sm = (qs.get("sslmode") or [""])[0].strip().lower()
    env_mode = os.environ.get("DATABASE_SSLMODE", "").strip().lower()

    if sm == "disable" or env_mode in ("disable", "false", "0"):
        return False

    if not sm and not env_mode and _is_local_pg_host(p.hostname):
        return False

    ca = os.environ.get("DATABASE_SSL_CA", "").strip() or os.environ.get(
        "SSL_ROOTCERT", ""
    ).strip()
    if ca:
        return ssl.create_default_context(cafile=ca)
    if sm in ("require", "allow", "prefer") or env_mode in ("require", "allow", "prefer"):
        # Same behavior as _ssl_from_env_and_ca(): TLS on, cert verification off unless CA provided.
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return ctx
    return ssl.create_default_context()


def _dsn_from_jdbc() -> tuple[str | None, bool | ssl.SSLContext]:
    jdbc = (
        os.environ.get("DB_URL", "").strip()
        or os.environ.get("DATABASE_URL", "").strip()
    )
    if not jdbc.lower().startswith("jdbc:postgresql:"):
        return None, False
    parsed = _parse_jdbc_postgresql(jdbc)
    if not parsed:
        return None, False

    user = (
        os.environ.get("DB_USERNAME", "").strip()
        or os.environ.get("POSTGRES_USER", "").strip()
    )
    password = (
        os.environ.get("DB_PASSWORD", "").strip()
        or os.environ.get("POSTGRES_PASSWORD", "").strip()
    )
    if not user or not password:
        return None, False

    dbn = (
        os.environ.get("DB_NAME", "").strip()
        or os.environ.get("POSTGRES_DB", "").strip()
        or parsed["dbname"]
    )
    host = parsed["host"]
    port = parsed["port"]
    sslmode = (parsed.get("sslmode") or "require").strip().lower()
    ca = parsed.get("sslrootcert")

    user_q = quote_plus(user, safe="")
    pass_q = quote_plus(password, safe="")
    db_path = quote(dbn, safe="")

    # asyncpg uses the ssl= argument for TLS; keep sslmode in URI for clarity
    dsn = f"postgresql://{user_q}:{pass_q}@{host}:{port}/{db_path}?sslmode={sslmode}"

    if sslmode in ("disable", "false", "0"):
        ssl_arg: bool | ssl.SSLContext = False
    elif ca:
        ssl_arg = ssl.create_default_context(cafile=ca)
    elif sslmode in ("verify-full", "verify-ca"):
        ssl_arg = _ssl_from_env_and_ca(None)
    else:
        ssl_arg = _ssl_from_env_and_ca(None)

    return dsn, ssl_arg


def resolve_dsn_and_ssl() -> tuple[str | None, bool | ssl.SSLContext]:
    """
    Returns (dsn, ssl_arg) for asyncpg.create_pool(ssl=ssl_arg).

    Priority:
    1. DATABASE_URL if it is postgresql:// (not jdbc:)
    2. DB_URL jdbc:postgresql:... + DB_USERNAME / DB_PASSWORD / optional DB_NAME
    3. POSTGRES_* / AZURE_POSTGRES_* / DB_* host+user+pass+db
    """
    raw = os.environ.get("DATABASE_URL", "").strip()
    if raw:
        if raw.lower().startswith("jdbc:"):
            pass  # fall through — user may also set DB_URL; try jdbc branch below
        else:
            return raw, _ssl_for_plain_dsn(raw)

    dsn_j, ssl_j = _dsn_from_jdbc()
    if dsn_j:
        return dsn_j, ssl_j

    parts = _database_url_from_parts()
    if parts:
        return parts, _ssl_for_plain_dsn(parts)

    return None, False


def get_database_url() -> str | None:
    dsn, _ = resolve_dsn_and_ssl()
    return dsn


def _statement_timeout_ms() -> int:
    raw = os.environ.get("DATABASE_STATEMENT_TIMEOUT_MS", "5000").strip()
    try:
        return max(100, int(raw))
    except ValueError:
        return 5000


async def _init_connection(conn) -> None:
    ms = _statement_timeout_ms()
    await conn.execute(f"SET statement_timeout = {ms}")


async def get_pool():
    """Shared pool; None if no usable database config (service still starts)."""
    global _pool
    if _pool is not None:
        return _pool
    url, ssl_arg = resolve_dsn_and_ssl()
    if not url:
        return None

    import asyncpg  # noqa: PLC0415

    command_timeout = float(
        os.environ.get("DATABASE_COMMAND_TIMEOUT_S", "30").strip() or "30"
    )

    _pool = await asyncpg.create_pool(
        dsn=url,
        ssl=ssl_arg,
        min_size=1,
        max_size=int(os.environ.get("DATABASE_POOL_MAX", "10").strip() or "10"),
        init=_init_connection,
        command_timeout=command_timeout,
    )
    return _pool


async def close_pool() -> None:
    global _pool
    if _pool is not None:
        await _pool.close()
        _pool = None


async def ping_database() -> dict[str, Any]:
    pool = await get_pool()
    if pool is None:
        return {"configured": False, "ok": False}

    async with pool.acquire() as conn:
        one = await conn.fetchval("SELECT 1")
        try:
            ts = await conn.fetchval("SELECT public.ai_db_ping()")
            return {"configured": True, "ok": True, "select_1": one, "ai_db_ping": str(ts)}
        except Exception:
            return {"configured": True, "ok": True, "select_1": one, "ai_db_ping": None}
