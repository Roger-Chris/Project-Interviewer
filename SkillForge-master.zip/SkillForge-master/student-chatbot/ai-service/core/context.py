"""
Per-request identity (tenant + student) from trusted headers.

Spring will send X-Tenant-Id and X-Student-Id; values are never taken from the
LLM or untrusted JSON body. Uses contextvars so async handlers stay isolated.
"""

from __future__ import annotations

from contextvars import ContextVar, Token
from dataclasses import dataclass

from fastapi import HTTPException, status


@dataclass(frozen=True, slots=True)
class RequestIdentity:
    tenant_id: str
    student_id: str


_identity: ContextVar[RequestIdentity | None] = ContextVar(
    "request_identity", default=None
)


def set_identity(*, tenant_id: str, student_id: str) -> Token:
    return _identity.set(RequestIdentity(tenant_id=tenant_id, student_id=student_id))


def reset_identity(token: Token) -> None:
    _identity.reset(token)


def get_identity() -> RequestIdentity | None:
    return _identity.get()


def get_identity_or_raise() -> RequestIdentity:
    ctx = get_identity()
    if ctx is None:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Request identity not set",
        )
    return ctx
