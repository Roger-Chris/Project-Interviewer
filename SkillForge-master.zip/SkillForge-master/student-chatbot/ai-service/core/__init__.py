# Core: LLM, DB, security (added incrementally)
