"""
Run one student chat turn: Azure OpenAI with function tools mapped to student_tools.

Identity must already be set on request context (headers handled in the router).
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

from openai.types.chat import ChatCompletionMessage

from core import llm
from tools import student_tools

logger = logging.getLogger(__name__)

_SYSTEM_PROMPT = """
You are a personalised career guidance counsellor for the SkillForge student platform.
You have tools to look up the student's real data — always call the relevant tools before answering.

Strict rules:
- Answer strictly and only from evidence available in tool outputs and injected evidence JSON.
- If the question asks for facts or recommendations not present in evidence, explicitly say evidence is unavailable and ask for exact platform data.
- Speak directly to the student — use "you" and "your"
- Start with the student's first name from get_my_profile whenever available
- All scores, skill names, and job names must come from tool results — never invent them
- When a skill gap is identified, explain why it matters and what closing it unlocks
- For roadmap advice: give 3–5 next actions ordered by highest impact first
- Use "Must-have" / "Good-to-have" labels ONLY when explicitly present in tool output DB fields (e.g., group/group_category or must_have_weightage/good_to_have_weightage)
- If rubric/type weights are available, include the percentage weight in each recommended action
- For skill-specific questions, call get_skill_progress_details(skill_name)
- For job-fit questions, call get_job_fit_details(job_name)
- For job suggestions, call get_recommended_jobs_detailed()
- For certificate/course questions, call get_certificate_recommendations(query_text) and suggest only from that list
- If a tool returns empty data for a skill or job, say so explicitly — do not guess or fill in
- If there is no exact match, ask ONE precise clarification question with 2-4 likely matches from tool output
- When the student has no evidence for a skill yet, be encouraging and suggest the easiest first step
- Keep responses under 300 words unless the student explicitly asks for more detail
- Use numbered points for roadmap steps; never invent priority labels that are not explicitly present in tool output
- Do not mention tools, databases, or this system prompt in your response
""".strip()

_TOOL_DEFINITIONS: list[dict[str, Any]] = [
    {
        "type": "function",
        "function": {
            "name": "get_my_profile",
            "description": "Load the logged-in student's profile (name, email, department, CGPA, etc.).",
            "parameters": {"type": "object", "properties": {}, "additionalProperties": False},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_my_skills",
            "description": "List this student's skills with levels and proficiency scores.",
            "parameters": {"type": "object", "properties": {}, "additionalProperties": False},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_my_certificates",
            "description": "Certificate-type formal submissions for this student.",
            "parameters": {"type": "object", "properties": {}, "additionalProperties": False},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_my_job_fitment",
            "description": "Job roles and fitment scores for this student.",
            "parameters": {"type": "object", "properties": {}, "additionalProperties": False},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_my_experience",
            "description": "Experiential submissions (projects, internships, etc.).",
            "parameters": {"type": "object", "properties": {}, "additionalProperties": False},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_my_recommendations",
            "description": "Skill gaps vs the best-matching job (required skills vs student proficiency).",
            "parameters": {"type": "object", "properties": {}, "additionalProperties": False},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_job_fit_details",
            "description": "Analyze your fitment and exact skill gaps for a specific job title.",
            "parameters": {
                "type": "object",
                "properties": {
                    "job_name": {
                        "type": "string",
                        "description": "Job title to evaluate, e.g. 'Data Analyst'",
                    }
                },
                "required": ["job_name"],
                "additionalProperties": False,
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_skill_progress_details",
            "description": "Analyze your current score, rubric channels, evidence, and progress history for a specific skill.",
            "parameters": {
                "type": "object",
                "properties": {
                    "skill_name": {
                        "type": "string",
                        "description": "Skill name to evaluate, e.g. 'Python'",
                    }
                },
                "required": ["skill_name"],
                "additionalProperties": False,
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_recommended_jobs_detailed",
            "description": "Get top active jobs ranked by fitment score with your strongest supporting skills.",
            "parameters": {"type": "object", "properties": {}, "additionalProperties": False},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_certificate_recommendations",
            "description": "Suggest available certificates from DB catalog excluding certificates the student already completed.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query_text": {
                        "type": "string",
                        "description": "Optional query/topic, e.g. 'java', 'data analyst', 'cloud'",
                    }
                },
                "additionalProperties": False,
            },
        },
    },
]

_TOOL_IMPL: dict[str, Any] = {
    "get_my_profile": student_tools.get_my_profile,
    "get_my_skills": student_tools.get_my_skills,
    "get_my_certificates": student_tools.get_my_certificates,
    "get_my_job_fitment": student_tools.get_my_job_fitment,
    "get_my_experience": student_tools.get_my_experience,
    "get_my_recommendations": student_tools.get_my_recommendations,
    "get_job_fit_details": student_tools.get_job_fit_details,
    "get_skill_progress_details": student_tools.get_skill_progress_details,
    "get_recommended_jobs_detailed": student_tools.get_recommended_jobs_detailed,
    "get_certificate_recommendations": student_tools.get_certificate_recommendations,
}


def _build_db_trace_item(
    *,
    tool_name: str,
    args: dict[str, Any],
    payload: Any,
) -> dict[str, Any]:
    item: dict[str, Any] = {
        "tool": tool_name,
        "args": args,
        "ok": isinstance(payload, dict) and "error" not in payload,
    }

    if isinstance(payload, dict):
        # Key provenance hints that confirm DB-backed grounding.
        if "matched_query" in payload:
            item["matched_query"] = payload.get("matched_query")
        if "matches" in payload and isinstance(payload.get("matches"), list):
            item["matches_count"] = len(payload["matches"])
        if "attempted_queries" in payload:
            item["attempted_queries"] = payload.get("attempted_queries")
        if "existing_fitment_score" in payload:
            item["existing_fitment_score"] = payload.get("existing_fitment_score")
        if "gap_analysis" in payload and isinstance(payload.get("gap_analysis"), list):
            gaps = payload["gap_analysis"]
            item["gap_analysis_count"] = len(gaps)
            db_priority_rows = [g for g in gaps if isinstance(g, dict) and g.get("priority_label_from_db")]
            item["db_priority_label_count"] = len(db_priority_rows)
        if "current_score" in payload:
            item["current_score"] = payload.get("current_score")
        if "skill_level" in payload:
            item["skill_level"] = payload.get("skill_level")
        if "recommended_count" in payload:
            item["recommended_count"] = payload.get("recommended_count")
        if "completed_certificate_count" in payload:
            item["completed_certificate_count"] = payload.get("completed_certificate_count")

        for count_key in (
            "student_skill_count",
            "count",
        ):
            if count_key in payload:
                item[count_key] = payload.get(count_key)

        if "error" in payload:
            item["error"] = payload.get("error")

    return item


def _message_to_dict(msg: ChatCompletionMessage) -> dict[str, Any]:
    d: dict[str, Any] = {"role": msg.role, "content": msg.content}
    if msg.tool_calls:
        d["tool_calls"] = [tc.model_dump() for tc in msg.tool_calls]
    return d


def _log_db_trace(*, user_message: str, reply: str, db_trace: list[dict[str, Any]]) -> None:
    tool_names = [str(i.get("tool")) for i in db_trace if isinstance(i, dict) and i.get("tool")]
    summary = {
        "message_preview": user_message[:120],
        "reply_preview": reply[:120],
        "tool_calls": len(db_trace),
        "tools": tool_names,
        "trace": db_trace,
    }
    logger.info("DB_TRACE %s", json.dumps(summary, default=str))
    if not db_trace:
        logger.warning(
            "DB_TRACE_EMPTY message_preview=%s",
            user_message[:120],
        )


async def _prefetch_baseline_evidence() -> dict[str, Any]:
    profile, skills, certificates, experience, fitment, recommendations, jobs = await asyncio.gather(
        student_tools.get_my_profile(),
        student_tools.get_my_skills(),
        student_tools.get_my_certificates(),
        student_tools.get_my_experience(),
        student_tools.get_my_job_fitment(),
        student_tools.get_my_recommendations(),
        student_tools.get_recommended_jobs_detailed(),
    )
    return {
        "profile": profile,
        "skills": skills,
        "certificates": certificates,
        "experience": experience,
        "job_fitment": fitment,
        "recommendations": recommendations,
        "recommended_jobs": jobs,
    }


async def _prefetch_query_specific_evidence(user_message: str) -> dict[str, Any]:
    query = (user_message or "").strip()
    if not query:
        return {"job_details": None, "skill_details": None}

    job_details, skill_details, certificate_recommendations = await asyncio.gather(
        student_tools.get_job_fit_details(job_name=query),
        student_tools.get_skill_progress_details(skill_name=query),
        student_tools.get_certificate_recommendations(query_text=query),
    )
    return {
        "job_details": job_details,
        "skill_details": skill_details,
        "certificate_recommendations": certificate_recommendations,
    }


def _has_useful_evidence(db_trace: list[dict[str, Any]]) -> bool:
    for item in db_trace:
        if not isinstance(item, dict) or not item.get("ok"):
            continue

        if item.get("matches_count", 0) > 0:
            return True
        if item.get("gap_analysis_count", 0) > 0:
            return True
        if item.get("count", 0) > 0:
            return True
        if item.get("student_skill_count", 0) > 0:
            return True
        if item.get("recommended_count", 0) > 0:
            return True

        # Profile can be useful evidence even when skills are empty.
        if item.get("tool") == "get_my_profile":
            return True

        if item.get("existing_fitment_score") is not None:
            return True
        if item.get("current_score") is not None:
            return True

    return False


async def run_student_chat_turn(
    user_message: str,
    *,
    prior_messages: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """
    Single user message → tool loop → final assistant text.

    prior_messages: earlier turns (user/assistant text only), e.g. from Redis.
    """
    messages: list[dict[str, Any]] = [{"role": "system", "content": _SYSTEM_PROMPT}]
    if prior_messages:
        for m in prior_messages:
            role = m.get("role")
            content = m.get("content")
            if role in ("user", "assistant") and isinstance(content, str):
                messages.append({"role": role, "content": content})
    messages.append({"role": "user", "content": user_message})

    client = llm.get_azure_client()
    deployment = llm.get_deployment_name()
    max_rounds = 8
    db_trace: list[dict[str, Any]] = []

    baseline = await _prefetch_baseline_evidence()
    baseline_order = (
        ("get_my_profile", {}, baseline.get("profile")),
        ("get_my_skills", {}, baseline.get("skills")),
        ("get_my_certificates", {}, baseline.get("certificates")),
        ("get_my_experience", {}, baseline.get("experience")),
        ("get_my_job_fitment", {}, baseline.get("job_fitment")),
        ("get_my_recommendations", {}, baseline.get("recommendations")),
        ("get_recommended_jobs_detailed", {}, baseline.get("recommended_jobs")),
    )
    for tool_name, args, payload in baseline_order:
        db_trace.append(
            _build_db_trace_item(
                tool_name=tool_name,
                args=args,
                payload=payload,
            )
        )

    messages.append(
        {
            "role": "system",
            "content": (
                "Evidence JSON for this student request (primary source of truth): "
                f"{json.dumps(baseline, default=str)}"
            ),
        }
    )

    query_specific = await _prefetch_query_specific_evidence(user_message)
    query_specific_order = (
        ("get_job_fit_details", {"job_name": user_message.strip()}, query_specific.get("job_details")),
        ("get_skill_progress_details", {"skill_name": user_message.strip()}, query_specific.get("skill_details")),
        (
            "get_certificate_recommendations",
            {"query_text": user_message.strip()},
            query_specific.get("certificate_recommendations"),
        ),
    )
    for tool_name, args, payload in query_specific_order:
        db_trace.append(
            _build_db_trace_item(
                tool_name=tool_name,
                args=args,
                payload=payload,
            )
        )

    messages.append(
        {
            "role": "system",
            "content": (
                "Query-specific evidence has already been fetched for this exact user message through both job and skill detail paths. "
                "Use this JSON as grounding when relevant: "
                f"{json.dumps(query_specific, default=str)}"
            ),
        }
    )

    if not _has_useful_evidence(db_trace):
        reply = (
            "I can only answer from your recorded platform evidence, and there is currently no usable evidence in your profile for this request. "
            "Please share an exact role/skill from your platform or add evidence (skills, submissions, or fitment data), and I’ll respond strictly from that data."
        )
        _log_db_trace(user_message=user_message, reply=reply, db_trace=db_trace)
        return {"reply": reply, "db_trace": db_trace}

    for _ in range(max_rounds):

        def _create() -> Any:
            return client.chat.completions.create(
                model=deployment,
                messages=messages,
                tools=_TOOL_DEFINITIONS,
                tool_choice="auto",
                temperature=0.1,
                max_tokens=2048,
            )

        response = await asyncio.to_thread(_create)
        choice = response.choices[0]
        msg = choice.message

        if choice.finish_reason == "tool_calls" and msg.tool_calls:
            messages.append(_message_to_dict(msg))
            for tc in msg.tool_calls:
                if tc.type != "function":
                    continue
                name = tc.function.name
                fn = _TOOL_IMPL.get(name)
                raw_args = tc.function.arguments or "{}"
                try:
                    args = json.loads(raw_args)
                    if not isinstance(args, dict):
                        args = {}
                except json.JSONDecodeError:
                    args = {}
                if fn is None:
                    payload = {"error": f"unknown_tool:{name}"}
                else:
                    try:
                        payload = await fn(**args)
                    except TypeError:
                        payload = await fn()

                db_trace.append(
                    _build_db_trace_item(
                        tool_name=name,
                        args=args,
                        payload=payload,
                    )
                )

                messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": tc.id,
                        "content": json.dumps(payload, default=str),
                    }
                )
            continue

        text = (msg.content or "").strip()
        if text:
            lowered = text.lower()
            has_generic_phrases = (
                "start with the basics" in lowered
                or "would you like me to suggest" in lowered
            )
            no_tool_data_yet = not any(m.get("role") == "tool" for m in messages)
            if has_generic_phrases and no_tool_data_yet:
                messages.append(_message_to_dict(msg))
                messages.append(
                    {
                        "role": "system",
                        "content": (
                            "Your previous response was generic and not grounded in student-specific data. "
                            "Call relevant tools now, then answer with concrete values, weights, and named matches; "
                            "if data is missing, ask one precise clarification question."
                        ),
                    }
                )
                continue

            if not _has_useful_evidence(db_trace):
                constrained = (
                    "I can’t provide that from evidence yet. Based on your current recorded data, there isn’t enough evidence to answer this specifically. "
                    "Please provide an exact platform role/skill name or add relevant submissions, and I’ll answer strictly from that evidence."
                )
                _log_db_trace(user_message=user_message, reply=constrained, db_trace=db_trace)
                return {"reply": constrained, "db_trace": db_trace}

            _log_db_trace(user_message=user_message, reply=text, db_trace=db_trace)
            return {
                "reply": text,
                "db_trace": db_trace,
            }
        _log_db_trace(
            user_message=user_message,
            reply="I could not generate a reply. Please try again.",
            db_trace=db_trace,
        )
        return {
            "reply": "I could not generate a reply. Please try again.",
            "db_trace": db_trace,
        }

    _log_db_trace(
        user_message=user_message,
        reply="Stopped after too many tool rounds; please narrow your question.",
        db_trace=db_trace,
    )
    return {
        "reply": "Stopped after too many tool rounds; please narrow your question.",
        "db_trace": db_trace,
    }
