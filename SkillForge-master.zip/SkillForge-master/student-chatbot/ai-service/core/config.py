"""
Centralised settings for the student-chatbot ai-service.

All Azure OpenAI credentials and app-level knobs live here.
DB and Redis connection strings are intentionally left to their own
modules (core/db.py, cache/history.py) because they handle complex
multi-DSN resolution that cannot be expressed as simple scalar fields.

The dotenv file is resolved by main.py at startup via skillforge_env.py
before this module is imported, so Settings() reads from os.environ
in practice. The env_file=".env" fallback covers direct script runs and tests.
"""

from __future__ import annotations

from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # ------------------------------------------------------------------ #
    # Azure OpenAI                                                         #
    # ------------------------------------------------------------------ #
    azure_openai_api_key: str
    azure_openai_endpoint: str
    # Accept both naming conventions found across deployments.
    azure_openai_deployment: str | None = None
    azure_openai_deployment_name: str | None = None
    azure_openai_api_version: str = "2024-10-21"

    # ------------------------------------------------------------------ #
    # App                                                                  #
    # ------------------------------------------------------------------ #
    env: str = "production"

    # ------------------------------------------------------------------ #
    # Chat history defaults (cache/history.py reads these as int env vars) #
    # ------------------------------------------------------------------ #
    chat_history_max_messages: int = 40
    chat_history_ttl_seconds: int = 604_800  # 7 days

    model_config = SettingsConfigDict(
        env_file=".env",
        case_sensitive=False,
        # Silently ignore DB_*, POSTGRES_*, REDIS_* and other vars that are
        # handled by db.py / history.py with their own resolution logic.
        extra="ignore",
    )

    @model_validator(mode="after")
    def _resolve_deployment(self) -> "Settings":
        """Allow AZURE_OPENAI_DEPLOYMENT_NAME as an alias for AZURE_OPENAI_DEPLOYMENT."""
        if not self.azure_openai_deployment and self.azure_openai_deployment_name:
            self.azure_openai_deployment = self.azure_openai_deployment_name
        if not self.azure_openai_deployment:
            raise ValueError(
                "AZURE_OPENAI_DEPLOYMENT (or AZURE_OPENAI_DEPLOYMENT_NAME) must be set"
            )
        return self


settings = Settings()
