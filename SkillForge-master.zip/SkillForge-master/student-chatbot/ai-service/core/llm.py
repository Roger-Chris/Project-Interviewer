"""
Azure OpenAI chat (e.g. gpt-4.1-mini via your deployment name).

In Azure, `model=` in the API is the deployment name you created in the portal,
not necessarily the public model id string.

Credentials are read from core.config.settings (Pydantic-validated at startup),
so missing or mistyped env vars raise a clear error before the first request.
"""

from __future__ import annotations

import asyncio
from typing import Any

from openai import AzureOpenAI

from core.config import settings


def get_azure_client() -> AzureOpenAI:
    return AzureOpenAI(
        api_key=settings.azure_openai_api_key,
        api_version=settings.azure_openai_api_version,
        azure_endpoint=settings.azure_openai_endpoint.rstrip("/"),
    )


def get_deployment_name() -> str:
    """Deployment name for your model in Azure (e.g. gpt-4.1-mini)."""
    return settings.azure_openai_deployment  # type: ignore[return-value]


async def chat_completion(
    messages: list[dict[str, Any]],
    *,
    temperature: float = 0.7,
    max_tokens: int | None = 1024,
) -> str:
    """
    Non-streaming chat completion. Runs the sync SDK in a thread pool so FastAPI
    async routes are not blocked.
    """
    client = get_azure_client()
    deployment = get_deployment_name()

    def _call():
        kwargs: dict[str, Any] = {
            "model": deployment,
            "messages": messages,
            "temperature": temperature,
        }
        if max_tokens is not None:
            kwargs["max_tokens"] = max_tokens
        resp = client.chat.completions.create(**kwargs)
        choice = resp.choices[0]
        content = choice.message.content
        return (content or "").strip()

    return await asyncio.to_thread(_call)
