"""
Read-only access to `students` — aligned with database_schema.md (`students`).

IDs are VARCHAR in the DB; callers pass tenant_id and student_id as strings.
Next steps (separate files): request context, HTTP router, then more tables.
"""

from __future__ import annotations

from typing import Any

from core import db


def _rows_to_dicts(rows: list[Any]) -> list[dict[str, Any]]:
  return [dict(r) for r in rows]

_STUDENT_SELECT = """
SELECT
  id,
  register_number,
  tenant_id,
  name,
  email,
  phone,
  date_of_birth,
  gender,
  address,
  city,
  state,
  country,
  postal_code,
  profile_picture_url,
  resume_url,
  department,
  year,
  passing_out_year,
  degree,
  section,
  tag1,
  tag2,
  tag3,
  tag4,
  last_login,
  favorite_job_ids,
  favorite_skill_ids,
  is_active,
  is_assigned,
  current_education_level,
  current_institution,
  current_course,
  graduation_year,
  cgpa,
  current_cgpa,
  completed_education,
  alternate_email,
  created_at,
  updated_at
FROM students
WHERE tenant_id = $1 AND id = $2
LIMIT 1
"""


async def fetch_student_row(
    *,
    tenant_id: str,
    student_id: str,
) -> dict[str, Any] | None:
    """
    One row from `students` for this tenant, or None if not found / no pool.
    Never selects `password`.
    """
    pool = await db.get_pool()
    if pool is None:
        return None

    async with pool.acquire() as conn:
        row = await conn.fetchrow(_STUDENT_SELECT, tenant_id, student_id)
        if row is None:
            return None
        return dict(row)


_SKILLS_QUERY = """
SELECT
  ss.skill_id,
  st.skill_name,
  ss.skill_level,
  ss.proficiency_score,
  ss.last_updated,
  ss.notes
FROM student_skills ss
JOIN skill_taxonomy st ON st.skill_id = ss.skill_id
WHERE ss.tenant_id = $1
  AND ss.student_id = $2
  AND ss.is_active = TRUE
ORDER BY st.skill_name
"""


async def fetch_student_skills(
    *,
    tenant_id: str,
    student_id: str,
) -> list[dict[str, Any]]:
    pool = await db.get_pool()
    if pool is None:
        return []
    async with pool.acquire() as conn:
        rows = await conn.fetch(_SKILLS_QUERY, tenant_id, student_id)
        return [dict(r) for r in rows]


_CERTIFICATE_SUBMISSIONS_QUERY = """
SELECT
  sfs.artifact_id,
  sfs.parameter_id,
  sfs.score,
  sfs.status,
  sfs.title,
  sfs.parameter_type,
  sfs.created_at,
  sfs.updated_at
FROM student_formal_submissions sfs
WHERE sfs.tenant_id = $1
  AND sfs.student_id = $2
  AND sfs.parameter_type = 'CERTIFICATE'
ORDER BY sfs.updated_at DESC NULLS LAST
"""


async def fetch_student_certificate_submissions(
    *,
    tenant_id: str,
    student_id: str,
) -> list[dict[str, Any]]:
    pool = await db.get_pool()
    if pool is None:
        return []
    async with pool.acquire() as conn:
        rows = await conn.fetch(_CERTIFICATE_SUBMISSIONS_QUERY, tenant_id, student_id)
        return [dict(r) for r in rows]


_AVAILABLE_CERTIFICATES_QUERY = """
SELECT
  fp.parameter_id,
  fp.name,
  fp.provider,
  fp.description,
  fp.type,
  fp.tenant_id,
  ARRAY_REMOVE(ARRAY_AGG(DISTINCT st.skill_name), NULL) AS mapped_skill_names
FROM formal_parameters fp
LEFT JOIN formal_skill_mapping fsm
  ON fsm.parameter_id = fp.parameter_id
 AND (fsm.tenant_id = fp.tenant_id OR fsm.tenant_id = $1)
LEFT JOIN skill_taxonomy st ON st.skill_id = fsm.skill_id
WHERE fp.is_active = TRUE
  AND fp.type = 'CERTIFICATE'
  AND (fp.tenant_id = $1 OR fp.tenant_id IS NULL)
  AND NOT EXISTS (
    SELECT 1
    FROM student_formal_submissions sfs
    WHERE sfs.tenant_id = $1
      AND sfs.student_id = $2
      AND sfs.parameter_type = 'CERTIFICATE'
      AND sfs.parameter_id = fp.parameter_id
      AND UPPER(COALESCE(sfs.status, '')) IN ('APPROVED', 'COMPLETED')
  )
  AND (
    COALESCE($3, '') = ''
    OR fp.name ILIKE ('%' || $3 || '%')
    OR COALESCE(fp.provider, '') ILIKE ('%' || $3 || '%')
    OR EXISTS (
      SELECT 1
      FROM formal_skill_mapping fsm2
      JOIN skill_taxonomy st2 ON st2.skill_id = fsm2.skill_id
      WHERE fsm2.parameter_id = fp.parameter_id
        AND (fsm2.tenant_id = fp.tenant_id OR fsm2.tenant_id = $1)
        AND st2.skill_name ILIKE ('%' || $3 || '%')
    )
  )
GROUP BY
  fp.parameter_id,
  fp.name,
  fp.provider,
  fp.description,
  fp.type,
  fp.tenant_id
ORDER BY fp.name
LIMIT $4
"""


async def fetch_available_certificates_for_student(
    *,
    tenant_id: str,
    student_id: str,
    query_text: str | None = None,
    limit: int = 10,
) -> list[dict[str, Any]]:
    pool = await db.get_pool()
    if pool is None:
        return []
    normalized_query = (query_text or "").strip()
    safe_limit = max(1, min(limit, 30))
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            _AVAILABLE_CERTIFICATES_QUERY,
            tenant_id,
            student_id,
            normalized_query,
            safe_limit,
        )
        return _rows_to_dicts(rows)


_FITMENT_QUERY = """
SELECT
  sjf.job_id AS tenant_job_ontology_id,
  sjf.fitment_score,
  jt.job_title,
  tjo.required_level
FROM student_job_fitments sjf
LEFT JOIN tenant_job_ontology tjo
  ON tjo.job_ontology_id = sjf.job_id AND tjo.tenant_id = sjf.tenant_id
LEFT JOIN job_taxonomy jt ON jt.job_id = tjo.job_id
WHERE sjf.tenant_id = $1
  AND sjf.student_id = $2
  AND (sjf.is_active IS NULL OR sjf.is_active = TRUE)
ORDER BY sjf.fitment_score DESC NULLS LAST
"""


async def fetch_student_job_fitments(
    *,
    tenant_id: str,
    student_id: str,
) -> list[dict[str, Any]]:
    pool = await db.get_pool()
    if pool is None:
        return []
    async with pool.acquire() as conn:
        rows = await conn.fetch(_FITMENT_QUERY, tenant_id, student_id)
        return [dict(r) for r in rows]


_EXPERIENCE_QUERY = """
SELECT
  parameter_id,
  type,
  title,
  description,
  start_date,
  end_date,
  organization,
  team_size,
  role,
  outcomes,
  status,
  created_at,
  updated_at
FROM student_experience_submissions
WHERE tenant_id = $1
  AND student_id = $2
ORDER BY updated_at DESC NULLS LAST
"""


async def fetch_student_experience(
    *,
    tenant_id: str,
    student_id: str,
) -> list[dict[str, Any]]:
    pool = await db.get_pool()
    if pool is None:
        return []
    async with pool.acquire() as conn:
        rows = await conn.fetch(_EXPERIENCE_QUERY, tenant_id, student_id)
        return [dict(r) for r in rows]


_RECOMMENDATIONS_QUERY = """
WITH best AS (
  SELECT job_id AS ontology_id, fitment_score
  FROM student_job_fitments
  WHERE tenant_id = $1
    AND student_id = $2
    AND (is_active IS NULL OR is_active = TRUE)
  ORDER BY fitment_score DESC NULLS LAST
  LIMIT 1
)
SELECT
  b.ontology_id AS target_job_ontology_id,
  b.fitment_score AS target_fitment_score,
  st.skill_id,
  st.skill_name,
  jsr.weightage AS requirement_weightage,
  ss.proficiency_score AS student_proficiency,
  ss.skill_level AS student_skill_level
FROM best b
JOIN job_skill_requirements jsr
  ON jsr.tenant_job_ontology_id = b.ontology_id
JOIN skill_taxonomy st ON st.skill_id = jsr.skill_id
LEFT JOIN student_skills ss
  ON ss.skill_id = jsr.skill_id
  AND ss.student_id = $2
  AND ss.tenant_id = $1
  AND ss.is_active = TRUE
ORDER BY jsr.weightage DESC NULLS LAST
"""


async def fetch_skill_gaps_for_best_fit_job(
    *,
    tenant_id: str,
    student_id: str,
) -> dict[str, Any]:
    """
    Best-matching job (by fitment) vs required skills; left join student_skills
    shows gaps (NULL proficiency = missing or weak).
    """
    pool = await db.get_pool()
    if pool is None:
        return {"target_job_ontology_id": None, "skill_rows": []}
    async with pool.acquire() as conn:
        rows = await conn.fetch(_RECOMMENDATIONS_QUERY, tenant_id, student_id)
        if not rows:
            return {"target_job_ontology_id": None, "skill_rows": []}
        first = rows[0]
        return {
            "target_job_ontology_id": first["target_job_ontology_id"],
            "target_fitment_score": first["target_fitment_score"],
            "skill_rows": [dict(r) for r in rows],
        }


_FIND_JOB_BY_NAME_QUERY = """
SELECT
  tjo.job_ontology_id,
  tjo.job_id,
  tjo.required_level,
  tjo.must_have_weightage,
  tjo.good_to_have_weightage,
  tjo.must_have_behavioural_weightage,
  jt.job_title,
  jt.description,
  jt.market_insight
FROM tenant_job_ontology tjo
JOIN job_taxonomy jt ON jt.job_id = tjo.job_id
WHERE tjo.tenant_id = $1
  AND tjo.is_active = TRUE
  AND jt.is_active = TRUE
  AND jt.job_title ILIKE $2
LIMIT 5
"""


async def find_job_by_name(
    *,
    tenant_id: str,
    job_name: str,
) -> list[dict[str, Any]]:
    pool = await db.get_pool()
    if pool is None:
        return []
    async with pool.acquire() as conn:
        rows = await conn.fetch(_FIND_JOB_BY_NAME_QUERY, tenant_id, f"%{job_name}%")
        return _rows_to_dicts(rows)


_JOB_DETAILS_QUERY = """
SELECT
  tjo.job_ontology_id,
  tjo.required_level,
  tjo.must_have_weightage,
  tjo.good_to_have_weightage,
  tjo.must_have_behavioural_weightage,
  jt.job_title,
  jt.description,
  jt.market_insight,
  jsr.skill_id,
  jsr.weightage AS skill_weightage,
  jsr.group_category,
  st.skill_name,
  st.description AS skill_description
FROM tenant_job_ontology tjo
JOIN job_taxonomy jt ON jt.job_id = tjo.job_id
JOIN job_skill_requirements jsr
  ON jsr.tenant_job_ontology_id = tjo.job_ontology_id
JOIN skill_taxonomy st ON st.skill_id = jsr.skill_id
WHERE tjo.job_ontology_id = $1
  AND tjo.tenant_id = $2
  AND tjo.is_active = TRUE
"""


async def get_job_details(
    *,
    tenant_id: str,
    job_ontology_id: str,
) -> list[dict[str, Any]]:
    pool = await db.get_pool()
    if pool is None:
        return []
    async with pool.acquire() as conn:
        rows = await conn.fetch(_JOB_DETAILS_QUERY, job_ontology_id, tenant_id)
        return _rows_to_dicts(rows)


_JOB_FITMENT_SCORE_QUERY = """
SELECT
  fitment_score,
  updated_at::text AS updated_at
FROM student_job_fitments
WHERE student_id = $1
  AND job_id = $2
  AND tenant_id = $3
  AND (is_active IS NULL OR is_active = TRUE)
LIMIT 1
"""


async def get_job_fitment_score(
    *,
    tenant_id: str,
    student_id: str,
    job_ontology_id: str,
) -> dict[str, Any] | None:
    pool = await db.get_pool()
    if pool is None:
        return None
    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            _JOB_FITMENT_SCORE_QUERY,
            student_id,
            job_ontology_id,
            tenant_id,
        )
        return dict(row) if row else None


_FIND_SKILL_BY_NAME_QUERY = """
SELECT
  skill_id,
  skill_name,
  description,
  type
FROM skill_taxonomy
WHERE (tenant_id = $1 OR tenant_id IS NULL)
  AND is_active = TRUE
  AND skill_name ILIKE $2
LIMIT 5
"""


async def find_skill_by_name(
    *,
    tenant_id: str,
    skill_name: str,
) -> list[dict[str, Any]]:
    pool = await db.get_pool()
    if pool is None:
        return []
    async with pool.acquire() as conn:
        rows = await conn.fetch(_FIND_SKILL_BY_NAME_QUERY, tenant_id, f"%{skill_name}%")
        return _rows_to_dicts(rows)


_SKILL_RUBRIC_QUERY = """
SELECT
  rt.rubric_id,
  rt.total_weightage,
  rty.id AS type_id,
  rty.type,
  rty.weightage AS type_weightage,
  rty.count
FROM rubrics_templates rt
JOIN rubrics_type rty ON rty.rubric_id = rt.rubric_id
WHERE rt.skill_id = $1
  AND rt.tenant_id = $2
  AND rt.is_active = TRUE
"""


async def get_skill_rubric(
    *,
    tenant_id: str,
    skill_id: str,
) -> list[dict[str, Any]]:
    pool = await db.get_pool()
    if pool is None:
        return []
    async with pool.acquire() as conn:
        rows = await conn.fetch(_SKILL_RUBRIC_QUERY, skill_id, tenant_id)
        return _rows_to_dicts(rows)


_STUDENT_FORMAL_EVIDENCE_QUERY = """
SELECT
  sfs.artifact_id,
  sfs.parameter_type,
  sfs.score,
  sfs.status,
  sfs.title,
  sfs.created_at::text AS created_at,
  fp.name AS parameter_name
FROM student_formal_submissions sfs
JOIN formal_skill_mapping fsm
  ON fsm.parameter_id = sfs.parameter_id
 AND fsm.parameter_type = sfs.parameter_type
 AND fsm.tenant_id = $3
JOIN formal_parameters fp
  ON fp.parameter_id = sfs.parameter_id
 AND fp.tenant_id = $3
WHERE sfs.student_id = $1
  AND fsm.skill_id = $2
  AND sfs.tenant_id = $3
  AND sfs.status = 'APPROVED'
ORDER BY sfs.created_at DESC
LIMIT 10
"""


async def get_student_formal_evidence(
    *,
    tenant_id: str,
    student_id: str,
    skill_id: str,
) -> list[dict[str, Any]]:
    pool = await db.get_pool()
    if pool is None:
        return []
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            _STUDENT_FORMAL_EVIDENCE_QUERY,
            student_id,
            skill_id,
            tenant_id,
        )
        return _rows_to_dicts(rows)


_STUDENT_EXPERIENCE_EVIDENCE_QUERY = """
SELECT
  ses.parameter_id,
  ses.type,
  ses.title,
  ses.organization,
  ses.role,
  ses.start_date::text AS start_date,
  ses.end_date::text AS end_date,
  ses.status,
  esm.score AS skill_score,
  esm.evaluated_at::text AS evaluated_at
FROM student_experience_submissions ses
JOIN experience_skill_mapping esm
  ON esm.parameter_id = ses.parameter_id
 AND esm.skill_id = $2
 AND esm.tenant_id = $3
WHERE ses.student_id = $1
  AND ses.tenant_id = $3
  AND ses.status = 'APPROVED'
ORDER BY ses.end_date DESC NULLS LAST
LIMIT 10
"""


async def get_student_experience_evidence(
    *,
    tenant_id: str,
    student_id: str,
    skill_id: str,
) -> list[dict[str, Any]]:
    pool = await db.get_pool()
    if pool is None:
        return []
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            _STUDENT_EXPERIENCE_EVIDENCE_QUERY,
            student_id,
            skill_id,
            tenant_id,
        )
        return _rows_to_dicts(rows)


_SKILL_HISTORY_QUERY = """
SELECT
  proficiency_score,
  skill_level,
  recorded_at::text AS recorded_at
FROM student_skill_history
WHERE student_id = $1
  AND skill_id = $2
  AND tenant_id = $3
ORDER BY recorded_at DESC
LIMIT 6
"""


async def get_skill_history(
    *,
    tenant_id: str,
    student_id: str,
    skill_id: str,
) -> list[dict[str, Any]]:
    pool = await db.get_pool()
    if pool is None:
        return []
    async with pool.acquire() as conn:
        rows = await conn.fetch(_SKILL_HISTORY_QUERY, student_id, skill_id, tenant_id)
        return _rows_to_dicts(rows)


_ACTIVE_JOBS_QUERY = """
SELECT
  tjo.job_ontology_id,
  tjo.required_level,
  tjo.must_have_weightage,
  tjo.good_to_have_weightage,
  jt.job_title,
  jt.description
FROM tenant_job_ontology tjo
JOIN job_taxonomy jt ON jt.job_id = tjo.job_id
WHERE tjo.tenant_id = $1
  AND tjo.is_active = TRUE
  AND jt.is_active = TRUE
ORDER BY jt.job_title
LIMIT 50
"""


async def get_active_jobs_for_tenant(*, tenant_id: str) -> list[dict[str, Any]]:
    pool = await db.get_pool()
    if pool is None:
        return []
    async with pool.acquire() as conn:
        rows = await conn.fetch(_ACTIVE_JOBS_QUERY, tenant_id)
        return _rows_to_dicts(rows)
