"""
Student-facing routes: identity from headers, data from DB.

Send X-Tenant-Id and X-Student-Id (e.g. from Spring after you add auth there).
"""

from __future__ import annotations

from fastapi import APIRouter, Header, HTTPException, status
from pydantic import BaseModel, Field

from cache import history as chat_history
from core.config import settings
from core import context as request_context
from core import student_chat_runner
from core import student_repository

router = APIRouter()


class StudentChatBody(BaseModel):
    message: str = Field(..., min_length=1, max_length=32_000)
    session_id: str | None = Field(
        default=None,
        description="Conversation thread id; omit for 'default' per student.",
    )


class StudentChatReply(BaseModel):
    reply: str
    session_id: str
    db_trace: list[dict] | None = None


def _require_header(value: str | None, name: str) -> str:
    if value is None or not str(value).strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Missing header {name}",
        )
    return str(value).strip()


@router.get(
    "/student/profile",
    summary="Load current student row (students table)",
)
async def get_student_profile(
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
    x_student_id: str | None = Header(default=None, alias="X-Student-Id"),
) -> dict:
    tenant_id = _require_header(x_tenant_id, "X-Tenant-Id")
    student_id = _require_header(x_student_id, "X-Student-Id")

    token = request_context.set_identity(tenant_id=tenant_id, student_id=student_id)
    try:
        row = await student_repository.fetch_student_row(
            tenant_id=tenant_id,
            student_id=student_id,
        )
        if row is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Student not found for this tenant",
            )
        return row
    finally:
        request_context.reset_identity(token)


@router.post(
    "/student",
    response_model=StudentChatReply,
    summary="Student chat (Azure tools + DB)",
)
async def post_student_chat(
    body: StudentChatBody,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
    x_student_id: str | None = Header(default=None, alias="X-Student-Id"),
) -> StudentChatReply:
    tenant_id = _require_header(x_tenant_id, "X-Tenant-Id")
    student_id = _require_header(x_student_id, "X-Student-Id")

    token = request_context.set_identity(tenant_id=tenant_id, student_id=student_id)
    try:
        session_id = (body.session_id or "").strip() or "default"
        prior = await chat_history.load_chat_messages(
            tenant_id=tenant_id,
            student_id=student_id,
            session_id=session_id,
        )
        try:
            result = await student_chat_runner.run_student_chat_turn(
                body.message,
                prior_messages=prior,
            )
        except RuntimeError as exc:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail=str(exc),
            ) from exc
        reply = str(result.get("reply", "")).strip()
        db_trace = result.get("db_trace")
        await chat_history.append_chat_messages(
            tenant_id=tenant_id,
            student_id=student_id,
            session_id=session_id,
            messages=[
                {"role": "user", "content": body.message},
                {"role": "assistant", "content": reply},
            ],
        )
        include_trace = settings.env.lower() in {"development", "dev", "local"}
        return StudentChatReply(
            reply=reply,
            session_id=session_id,
            db_trace=db_trace if include_trace else None,
        )
    finally:
        request_context.reset_identity(token)
