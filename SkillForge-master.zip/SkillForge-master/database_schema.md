# Database schema (Skill Sphere / Keystone)

**Source:** Flyway migrations under [`skill-sphere/src/main/resources/db/migration/`](../skill-sphere/src/main/resources/db/migration/) (versions **V1** through **V60** as of this export).

**How to use this document**

- This file is a **human-readable catalog** of tables and columns **as created or altered in migrations**. It does not list every PostgreSQL **function**, **trigger**, or **view** (many are defined in large scripts such as `V26__Core_skill_and_job_functions.sql`, `V38__Optimize_job_fitment_recalculation.sql`, `V39__Batch_recalculation_functions.sql`, `V41__Create_evaluate_submission_async_function.sql`, etc.).
- For a **byte-accurate** snapshot of a live database (including object permissions and live state), run:

  `pg_dump --schema-only --no-owner --no-privileges -h HOST -U USER -d DATABASE -f schema.sql`

---

## PostgreSQL enum types (selected)

| Enum | Values / notes | Introduced in |
|------|----------------|---------------|
| `recalculation_trigger_type` | `JOB_ONTOLOGY`, `JOB_REQUIREMENTS`, `RUBRIC_TEMPLATE`, `RUBRIC_TYPE`, plus later `FORMAL_PARAMETER`, `STUDENT_SUBMISSION` (via `V31`) | `V25` / `V31` |
| `recalculation_queue_status` | `PENDING`, `PROCESSING`, `COMPLETED`, `FAILED` | `V25` |
| `bulk_upload_type` | `SKILL_RUBRICS`, `JOB_ONTOLOGY`, `FORMAL_PARAMETERS`, `STUDENT_MARKS`, `STUDENT_ENROLLMENT`, `JOB_TAXONOMY`, `SKILL_TAXONOMY` | `V29` |
| `bulk_upload_status` | `PENDING`, `VALIDATING`, `PROCESSING`, `COMPLETED`, `FAILED`, `CANCELLED` | `V29` |

---

## Tables (alphabetical)

### `admin_skills`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | |
| admin_id | VARCHAR(255) NOT NULL | FK → `users(id)` |
| skill_id | VARCHAR(255) NOT NULL | FK → `skill_taxonomy(skill_id)` |
| tenant_id | VARCHAR(255) NOT NULL | |
| created_at | TIMESTAMP NOT NULL DEFAULT now | |

**Migration:** `V54__Create_admin_skills_table.sql` — UNIQUE(`admin_id`, `skill_id`).

---

### `admin_template_permissions`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | |
| template_id | VARCHAR(255) NOT NULL | FK → `admin_templates(id)` |
| permission_id | VARCHAR(255) NOT NULL | FK → `permissions_list(id)` |

**Migration:** `V52__Create_admin_template_permissions_table.sql` — UNIQUE(`template_id`, `permission_id`).

---

### `admin_templates`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | |
| tenant_id | VARCHAR(255) NOT NULL | FK → `tenants(id)` |
| name | VARCHAR(100) NOT NULL | |
| description | VARCHAR(255) | |
| created_by | VARCHAR(255) NOT NULL | |
| created_at | TIMESTAMP DEFAULT now | |

**Migration:** `V51__Create_admin_templates_table.sql` — UNIQUE(`tenant_id`, `name`).

---

### `band_distribution_config`

| Column | Type | Notes |
|--------|------|-------|
| id | BIGSERIAL PK | |
| tenant_id | VARCHAR(255) NOT NULL | |
| type | VARCHAR(20) NOT NULL | CHECK: `SKILL` \| `JOB` |
| total_bands | INT NOT NULL | CHECK: 1–10 |
| configuration_data | JSONB NOT NULL | Band definitions |
| is_active | BOOLEAN DEFAULT TRUE | |
| is_default | BOOLEAN DEFAULT FALSE | |
| created_at, updated_at | TIMESTAMP | |
| created_by, updated_by | VARCHAR(255) | |

**Migration:** `V20__Create_band_distribution_config_table.sql` — validation trigger on JSON; seed rows per tenant.

---

### `bulk_upload_job_queue`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | |
| tenant_id | VARCHAR(255) | nullable (master admin) |
| upload_type | VARCHAR(50) NOT NULL | CHECK against upload types |
| file_name | VARCHAR(500) | |
| file_size | BIGINT | |
| created_by | VARCHAR(255) NOT NULL | |
| created_by_name | VARCHAR(255) | |
| status | VARCHAR(50) NOT NULL | includes `PARTIALLY_COMPLETED` |
| total_rows, validated_rows, processed_rows, successful_rows, failed_rows, skipped_rows | INTEGER | |
| results, errors, validation_errors, metadata | JSONB | |
| error_message | TEXT | |
| created_at, updated_at, started_at, validated_at, completed_at | TIMESTAMP | |

**Migration:** `V29__Create_bulk_upload_job_queue_table.sql` — FK `tenant_id` → `tenants(id)` when set.

---

### `categories`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK DEFAULT gen_random_uuid()::text | |
| type | VARCHAR(50) NOT NULL | CHECK: `job` \| `skill` |
| name | VARCHAR(255) NOT NULL | |
| tenant_id | VARCHAR(255) | |
| role | VARCHAR(50) | CHECK: SUPER_ADMIN, MASTER_ADMIN, MENTOR, STUDENT |
| is_active | BOOLEAN NOT NULL DEFAULT TRUE | |
| created_at, updated_at | TIMESTAMP | |
| created_by, updated_by | VARCHAR(255) | |

**Migration:** `V32__Create_categories_table.sql` — UNIQUE(`type`, `name`, `tenant_id`).

---

### `certificate_feedback`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | |
| tenant_id | VARCHAR(255) NOT NULL | |
| student_id | VARCHAR(255) NOT NULL | |
| student_register_number | VARCHAR(255) | |
| parameter_id | VARCHAR(255) NOT NULL | |
| certificate_name, platform | VARCHAR(255) | |
| batch | VARCHAR(50) | |
| skill_ids | JSONB | |
| submitted_at | TIMESTAMP NOT NULL DEFAULT now | |
| survey_answers | JSONB | |
| student_comment | TEXT | |
| super_admin_comment, master_admin_comment | TEXT | |
| super_admin_status, master_admin_status | BOOLEAN | |

**Migration:** `V43__Create_certificate_feedback_table.sql` — UNIQUE(`student_id`, `parameter_id`).

---

### `certificate_suggestions`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | |
| tenant_id | VARCHAR(255) NOT NULL | |
| tenant_name | VARCHAR(255) | |
| student_id | VARCHAR(255) NOT NULL | |
| student_register_number | VARCHAR(255) | |
| batch_year | VARCHAR(50) | |
| certification_name | VARCHAR(255) NOT NULL | |
| organization | VARCHAR(255) NOT NULL | |
| official_url | TEXT NOT NULL | |
| is_paid | BOOLEAN | |
| price | VARCHAR(100) | |
| primary_skills | TEXT | |
| suggest_reason, student_comment | TEXT | |
| super_admin_comment, master_admin_comment | TEXT | |
| super_admin_status, master_admin_status | BOOLEAN DEFAULT FALSE | |
| submitted_at | TIMESTAMP NOT NULL DEFAULT now | |

**Migration:** `V44__Create_certificate_suggestions_table.sql`.

---

### `cohort_student_tracking`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | |
| student_id | VARCHAR(255) NOT NULL | FK → `students(id)` |
| cohort_id | VARCHAR(255) NOT NULL | |
| tenant_id | VARCHAR(255) NOT NULL | FK → `tenants(id)` |
| first_seen_at | TIMESTAMP NOT NULL DEFAULT now | |
| last_email_sent_at | TIMESTAMP | |
| created_at, updated_at | TIMESTAMP | |

**Migration:** `V47__Create_cohort_student_tracking_table.sql` — UNIQUE(`student_id`, `cohort_id`).

---

### `evaluator_config`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | |
| evaluator_id | VARCHAR(255) NOT NULL UNIQUE | FK → `users(id)` |
| current_monthly_assigned_count | INTEGER NOT NULL DEFAULT 0 | |
| total_limit_assigned_count | INTEGER NOT NULL DEFAULT 0 | |
| is_stop | BOOLEAN NOT NULL DEFAULT FALSE | |

**Migration:** `V56__Create_evaluator_config_table.sql`.

---

### `experience_skill_mapping`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | |
| parameter_id | VARCHAR(255) NOT NULL | FK → `student_experience_submissions(parameter_id)` |
| skill_id | VARCHAR(255) NOT NULL | FK → `skill_taxonomy(skill_id)` |
| tenant_id | VARCHAR(255) NOT NULL | FK → `tenants(id)` |
| score | DECIMAL(5,2) NOT NULL DEFAULT 0 | 0–100 |
| created_at, updated_at | TIMESTAMP | |
| created_by, updated_by, evaluated_by | VARCHAR(255) | |
| evaluated_at | TIMESTAMP | |
| assigned_admin_id | VARCHAR(255) | FK → `users(id)` SET NULL |

**Migration:** `V55__Create_experience_skill_mapping_table.sql`.

---

### `feature_flag_config`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | |
| name | VARCHAR(100) NOT NULL UNIQUE | |
| display_name | VARCHAR(100) NOT NULL | |
| description | VARCHAR(255) | |
| created_at | TIMESTAMP DEFAULT now | |

**Migration:** `V48__Create_features_flag_config_table.sql`.

---

### `formal_parameter_api_config`

| Column | Type | Notes |
|--------|------|-------|
| config_id | VARCHAR(255) PK | |
| parameter_id | VARCHAR(255) NOT NULL | composite FK with tenant |
| tenant_id | VARCHAR(255) NOT NULL | |
| endpoint | VARCHAR(500) | |
| username, password | VARCHAR(255) | |
| notes | VARCHAR(1000) | |
| created_at, updated_at | TIMESTAMP | |

**Migration:** `V6__Create_formal_parameter_api_config_table.sql`.

---

### `formal_parameter_mapping`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | |
| rubric_id | VARCHAR(255) NOT NULL | FK → `rubrics_templates(rubric_id)` |
| tenant_id | VARCHAR(255) NOT NULL | FK → `tenants(id)` |
| parameter_id | VARCHAR(255) NOT NULL | FK → `formal_parameters(parameter_id, tenant_id)` |
| weightage | DECIMAL(5,2) | |
| type | VARCHAR(50) | |
| created_at, updated_at | TIMESTAMP | |

**Migration:** `V18__Create_formal_parameter_mapping_table.sql` — UNIQUE(`rubric_id`, `tenant_id`, `parameter_id`).

---

### `formal_parameters`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | UUID in app |
| parameter_id | VARCHAR(255) NOT NULL | business key |
| name | VARCHAR(255) NOT NULL | |
| type | VARCHAR(50) NOT NULL | CHECK: ASSESSMENT, ACADEMICS, CERTIFICATE, HACKATHON, INTERNSHIP, PROJECT |
| typecode | VARCHAR(50) | |
| provider | VARCHAR(255) | |
| description | TEXT | |
| is_api_available | BOOLEAN DEFAULT FALSE | |
| is_count | BOOLEAN DEFAULT TRUE | |
| max_score | VARCHAR(50) | |
| frequency, occurrence_type | VARCHAR(50) | |
| update_logic | TEXT | |
| tenant_id | VARCHAR(255) | FK → `tenants` |
| is_active | BOOLEAN DEFAULT TRUE | |
| created_at, updated_at | TIMESTAMP | |
| created_by, updated_by | VARCHAR(255) | |

**Migration:** `V11__Create_formal_parameters_table.sql` — unique (`parameter_id`, `tenant_id`, `type`) in V11; **`V57`** changes uniqueness to (`parameter_id`, `tenant_id`) only (drops `type` from unique constraint).

---

### `formal_skill_mapping`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | |
| parameter_id | VARCHAR(255) NOT NULL | validated by trigger |
| skill_id | VARCHAR(255) NOT NULL | FK → `skill_taxonomy(skill_id)` |
| parameter_type | VARCHAR(50) NOT NULL DEFAULT ASSESSMENT | CHECK: same six types as formal submissions |
| tenant_id | VARCHAR(255) | |
| created_at, updated_at | TIMESTAMP | |

**Migration:** `V17__Create_formal_skill_mapping_table.sql` — UNIQUE(`parameter_id`, `skill_id`, `parameter_type`, `tenant_id`).

---

### `impersonation_sessions`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | |
| admin_id | VARCHAR(255) NOT NULL | app-validated |
| student_id | VARCHAR(255) NOT NULL | FK → `students(id)` |
| tenant_id | VARCHAR(255) NOT NULL | FK → `tenants(id)` |
| session_token | VARCHAR(2000) NOT NULL UNIQUE | |
| started_at, expires_at | TIMESTAMP | |
| ended_at | TIMESTAMP | |
| reason | TEXT | |
| ip_address | VARCHAR(45) | |
| user_agent | TEXT | |
| created_at, updated_at | TIMESTAMP | |

**Migration:** `V30__Create_impersonation_sessions_table.sql`.

---

### `job_skill_requirements`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | |
| tenant_job_ontology_id | VARCHAR(255) NOT NULL | FK → `tenant_job_ontology(job_ontology_id)` |
| skill_id | VARCHAR(255) NOT NULL | FK → `skill_taxonomy(skill_id)` |
| weightage | DECIMAL(5,2) NOT NULL | 0–100 |
| group_category | VARCHAR(50) | |
| created_at, updated_at | TIMESTAMP | |

**Migration:** `V9__Create_job_skill_requirements_table.sql`.

---

### `job_taxonomy`

| Column | Type | Notes |
|--------|------|-------|
| job_id | VARCHAR(255) PK | |
| job_title | VARCHAR(255) NOT NULL | |
| description | TEXT | |
| category_id, sub_category_id | VARCHAR(255) | |
| market_insight | TEXT | |
| role | VARCHAR(255) | |
| tenant_id | VARCHAR(255) | |
| is_active | BOOLEAN DEFAULT TRUE | |
| created_at, updated_at | TIMESTAMP | |
| created_by, updated_by | VARCHAR(255) | |

**Migration:** `V3__Create_job_taxonomy_table.sql`. FKs to `categories` / `subcategories` added in **`V34__Add_foreign_keys_to_taxonomy_tables.sql`**.

---

### `mentor_student_relationships`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | |
| admin_user_id | VARCHAR(255) NOT NULL | FK → `users(id)` |
| student_id | VARCHAR(255) NOT NULL | FK → `students(id)` |
| tenant_id | VARCHAR(255) | FK → `tenants(id)` |
| is_active | BOOLEAN DEFAULT TRUE | |
| created_at, updated_at | TIMESTAMP | |
| created_by, updated_by | VARCHAR(255) | |

**Migration:** `V15__Create_mentor_student_relationships_table.sql` — partial UNIQUE(`admin_user_id`, `student_id`) WHERE `is_active`.

---

### `notifications`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | |
| tenant_id | VARCHAR(255) NOT NULL | FK → `tenants` |
| sender_id | VARCHAR(255) | |
| recipient_id | VARCHAR(255) NOT NULL | |
| title | VARCHAR(255) NOT NULL | |
| message | JSONB NOT NULL | |
| notification_type | VARCHAR(50) NOT NULL | CHECK: SKILL_UPDATE, JOB_MATCH, … |
| is_read | BOOLEAN NOT NULL DEFAULT FALSE | |
| is_service_bus | BOOLEAN NOT NULL DEFAULT FALSE | |
| read_at | TIMESTAMP | |
| action_url | VARCHAR(500) | |
| action_text | VARCHAR(100) | |
| metadata | JSONB DEFAULT `{}` | |
| created_by | VARCHAR(255) | |
| created_at | TIMESTAMP NOT NULL DEFAULT now | |
| expires_at | TIMESTAMP | |

**Migration:** `V16__Create_notifications_table.sql`.

---

### `permissions_list`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | |
| name | VARCHAR(100) NOT NULL UNIQUE | |
| resource | VARCHAR(100) NOT NULL | |
| action | VARCHAR(50) NOT NULL | |
| description | VARCHAR(255) | |
| feature_id | VARCHAR(255) | FK → `feature_flag_config(id)` SET NULL |
| created_at | TIMESTAMP DEFAULT now | |

**Migration:** `V49__Create_permissions_list_table.sql` — UNIQUE(`resource`, `action`).

---

### `queue_batch_summary`

| Column | Type | Notes |
|--------|------|-------|
| batch_id | VARCHAR(255) PK | |
| tenant_id | VARCHAR(255) NOT NULL | FK → `tenants` |
| triggered_by_user_id | VARCHAR(255) | |
| triggered_by_api | VARCHAR(500) | |
| description | VARCHAR(500) | |
| total_queue_items, completed_queue_items, failed_queue_items | INTEGER | |
| total_records_to_process, total_records_processed | INTEGER | |
| status | VARCHAR(20) NOT NULL DEFAULT PENDING | |
| progress_percentage | DECIMAL(5,2) DEFAULT 0 | |
| created_at, started_at, completed_at, estimated_completion_at | TIMESTAMP | |
| processing_duration_ms | BIGINT | |
| error_summary | TEXT | |

**Migration:** `V37__Add_queue_monitoring_and_progress_tracking.sql`.

---

### `queue_processing_history`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | |
| queue_item_id | VARCHAR(255) NOT NULL | |
| tenant_id | VARCHAR(255) NOT NULL | FK → `tenants` |
| trigger_type | VARCHAR(50) NOT NULL | |
| trigger_id | VARCHAR(255) NOT NULL | |
| batch_id | VARCHAR(255) | |
| triggered_by_user_id, triggered_by_api | VARCHAR | |
| status | VARCHAR(20) NOT NULL | |
| total_items, items_processed | INTEGER | |
| error_message | TEXT | |
| created_at, started_at, completed_at | TIMESTAMP | |
| processing_duration_ms | BIGINT | |
| retry_count | INTEGER DEFAULT 0 | |

**Migration:** `V37__Add_queue_monitoring_and_progress_tracking.sql`.

---

### `refresh_tokens`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | |
| token | VARCHAR(500) NOT NULL UNIQUE | |
| user_id | VARCHAR(255) NOT NULL | users or students id |
| expiry_date | TIMESTAMP NOT NULL | |
| created_at | TIMESTAMP NOT NULL DEFAULT now | |
| revoked | BOOLEAN NOT NULL DEFAULT FALSE | |
| revoked_at | TIMESTAMP | |
| revoked_reason | VARCHAR(255) | |
| last_used_at | TIMESTAMP | |
| ip_address | VARCHAR(45) | |
| user_agent | VARCHAR(500) | |

**Migration:** `V27__Create_refresh_tokens_table.sql`.

---

### `rubrics_templates`

| Column | Type | Notes |
|--------|------|-------|
| rubric_id | VARCHAR(255) PK | |
| id | VARCHAR(255) NOT NULL | **Added in `V58`** — mirrors `rubric_id` for JPA |
| tenant_id | VARCHAR(255) NOT NULL | FK → `tenants` |
| skill_id | VARCHAR(255) | FK → `skill_taxonomy` |
| total_weightage | DECIMAL(5,2) DEFAULT 100 | |
| created_by | VARCHAR(255) NOT NULL | |
| created_at, updated_at | TIMESTAMP | |
| is_active | BOOLEAN NOT NULL DEFAULT TRUE | |

**Migrations:** `V10__Create_rubrics_templates_table.sql`, **`V58__Align_rubrics_templates_id_column.sql`**.

---

### `rubrics_type`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | |
| rubric_id | VARCHAR(255) NOT NULL | FK → `rubrics_templates(rubric_id)` |
| type | VARCHAR(50) NOT NULL | |
| weightage | DECIMAL(5,2) | 0–100 |
| count | INTEGER | |
| created_at, updated_at | TIMESTAMP | |

**Migration:** `V19__Create_rubrics_type_table.sql`.

---

### `skill_recalculation_queue`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | |
| tenant_id | VARCHAR(255) NOT NULL | FK → `tenants` |
| trigger_type | `recalculation_trigger_type` NOT NULL | extended in later migrations |
| trigger_id | VARCHAR(255) NOT NULL | |
| affected_students | JSONB | |
| status | `recalculation_queue_status` NOT NULL DEFAULT PENDING | |
| error_message | TEXT | |
| created_at, started_at, completed_at | TIMESTAMP | |
| triggered_by_user_id | VARCHAR(255) | **`V37`** |
| triggered_by_api | VARCHAR(500) | **`V37`** |
| batch_id | VARCHAR(255) | **`V37`** |
| total_items, items_processed | INTEGER | **`V37`** |
| processing_duration_ms | BIGINT | **`V37`** |
| retry_count | INTEGER DEFAULT 0 | **`V37`** |
| progress_updated_at | TIMESTAMP | **`V37`** |

**Migrations:** `V25__Create_skill_recalculation_queue_table.sql`, **`V37__Add_queue_monitoring_and_progress_tracking.sql`**.

---

### `skill_taxonomy`

| Column | Type | Notes |
|--------|------|-------|
| skill_id | VARCHAR(255) PK | |
| skill_name | VARCHAR(255) NOT NULL | |
| description | TEXT | |
| category_id, sub_category_id | VARCHAR(255) | |
| type | VARCHAR(100) | |
| role | VARCHAR(255) | |
| tenant_id | VARCHAR(255) | |
| is_active | BOOLEAN DEFAULT TRUE | |
| created_at, updated_at | TIMESTAMP | |
| created_by, updated_by | VARCHAR(255) | |

**Migration:** `V2__Create_skill_taxonomy_table.sql`. FKs to `categories` / `subcategories` in **`V34`**.

---

### `student_experience_submissions`

| Column | Type | Notes |
|--------|------|-------|
| parameter_id | VARCHAR(255) PK | |
| student_id | VARCHAR(255) NOT NULL | FK → `students` |
| type | VARCHAR(50) NOT NULL | |
| title | VARCHAR(255) NOT NULL | |
| description | TEXT | |
| start_date, end_date | TIMESTAMP | |
| organization | VARCHAR(255) | |
| team_size | INTEGER | |
| role | VARCHAR(255) | |
| outcomes | VARCHAR(5000) | |
| supervisor_name, supervisor_email | VARCHAR(255) | |
| tenant_id | VARCHAR(255) | FK → `tenants` |
| status | VARCHAR(50) DEFAULT PENDING | |
| additional_data | JSONB | |
| created_at, updated_at | TIMESTAMP | |
| created_by, updated_by | VARCHAR(255) | |

**Migration:** `V12__Create_student_experience_submissions_table.sql`.

---

### `student_formal_submissions`

| Column | Type | Notes |
|--------|------|-------|
| artifact_id | VARCHAR(255) PK | |
| parameter_id | VARCHAR(255) | |
| score | DECIMAL(7,2) | 0–10000 |
| tenant_id | VARCHAR(255) | FK → `tenants` |
| student_id | VARCHAR(255) NOT NULL | FK → `students` |
| status | VARCHAR(50) | |
| evaluator_comments | JSONB | |
| attempt | INTEGER DEFAULT 1 | |
| parameter_type | VARCHAR(50) NOT NULL DEFAULT ASSESSMENT | six types + CHECK |
| title | VARCHAR(255) | |
| created_at, updated_at | TIMESTAMP | |
| created_by, updated_by | VARCHAR(255) | |

**Migration:** `V13__Create_student_formal_submissions_table.sql` — triggers for validation and skill recalculation (see later migrations).

---

### `student_job_fitment_history`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | |
| student_id | VARCHAR(255) NOT NULL | FK → `students` |
| job_id | VARCHAR(255) NOT NULL | |
| fitment_score | DECIMAL(5,2) NOT NULL | |
| tenant_id | VARCHAR(255) NOT NULL | FK → `tenants` |
| recorded_at | TIMESTAMP NOT NULL DEFAULT now | |

**Migration:** `V24__Create_student_job_fitment_history_table.sql`.

---

### `student_job_fitments`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK DEFAULT gen_random_uuid()::text | |
| student_id | VARCHAR(255) NOT NULL | FK → `students` |
| job_id | VARCHAR(255) NOT NULL | tenant job ontology id |
| fitment_score | DECIMAL(5,2) NOT NULL | |
| tenant_id | VARCHAR(255) NOT NULL | FK → `tenants` |
| is_active | BOOLEAN DEFAULT TRUE | |
| created_at, updated_at | TIMESTAMP | |

**Migration:** `V22__Create_student_job_fitments_table.sql` — UNIQUE(`student_id`, `job_id`).

---

### `student_skill_history`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | |
| student_id | VARCHAR(255) NOT NULL | FK → `students` |
| skill_id | VARCHAR(255) NOT NULL | |
| proficiency_score | DECIMAL(5,2) NOT NULL | |
| skill_level | VARCHAR(50) | |
| tenant_id | VARCHAR(255) NOT NULL | FK → `tenants` |
| recorded_at | TIMESTAMP NOT NULL DEFAULT now | |

**Migration:** `V23__Create_student_skill_history_table.sql`.

---

### `student_skills`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | |
| student_id | VARCHAR(255) NOT NULL | FK → `students` |
| skill_id | VARCHAR(255) NOT NULL | FK → `skill_taxonomy` |
| tenant_id | VARCHAR(255) NOT NULL | FK → `tenants` |
| skill_level | VARCHAR(50) NOT NULL DEFAULT BEGINNER | CHECK: BEGINNER, INTERMEDIATE, ADVANCED, EXPERT |
| proficiency_score | DECIMAL(5,2) DEFAULT 0 | 0–100 |
| last_updated | DATE | |
| notes | TEXT | |
| created_at, updated_at | TIMESTAMP | |
| is_active | BOOLEAN NOT NULL DEFAULT TRUE | |

**Migration:** `V7__Create_student_skills_table.sql` — UNIQUE(`student_id`, `skill_id`).

---

### `student_social_profiles`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | |
| student_id | VARCHAR(255) NOT NULL | FK → `students` |
| tenant_id | VARCHAR(255) NOT NULL | FK → `tenants` |
| username | VARCHAR(255) | |
| type | VARCHAR(50) | |
| url | VARCHAR(500) | |
| created_at, updated_at | TIMESTAMP | |

**Migration:** `V21__Create_student_social_profiles_table.sql`.

---

### `student_submission_urls`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | |
| artifact_id | VARCHAR(255) NOT NULL | FK → `student_formal_submissions(artifact_id)` |
| tenant_id | VARCHAR(255) NOT NULL | FK → `tenants` |
| url | VARCHAR(500) NOT NULL | CHECK http(s) |
| type | VARCHAR(50) | CHECK (see migration) |
| created_at, updated_at | TIMESTAMP | |

**Migration:** `V14__Create_student_submission_urls_table.sql`.

---

### `students`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | |
| register_number | VARCHAR(50) NOT NULL | unique per tenant |
| tenant_id | VARCHAR(255) NOT NULL | FK → `tenants` |
| name | VARCHAR(255) NOT NULL | |
| email | VARCHAR(255) NOT NULL UNIQUE | |
| phone | VARCHAR(20) | |
| password | VARCHAR(255) | |
| date_of_birth | DATE | |
| gender | VARCHAR(10) | CHECK |
| address | TEXT | |
| city, state, country | VARCHAR | |
| postal_code | VARCHAR(20) | |
| profile_picture_url, resume_url | VARCHAR(500) | |
| department | VARCHAR(100) | |
| year | VARCHAR(10) | |
| passing_out_year | INTEGER | |
| degree | VARCHAR(100) | |
| section | VARCHAR(50) | |
| tag1–tag4 | VARCHAR(100) | |
| last_login | TIMESTAMP | |
| favorite_job_ids, favorite_skill_ids | TEXT[] | |
| is_active | BOOLEAN NOT NULL DEFAULT TRUE | |
| is_assigned | BOOLEAN NOT NULL DEFAULT FALSE | |
| current_education_level | VARCHAR(50) | CHECK |
| current_institution, current_course | VARCHAR(255) | |
| graduation_year | INTEGER | |
| cgpa | DECIMAL(3,2) | |
| current_cgpa | DECIMAL(4,2) | 0–10 |
| completed_education | TEXT[] | |
| alternate_email | VARCHAR(255) | |
| created_at, updated_at | TIMESTAMP | |

**Migration:** `V5__Create_students_table.sql`.

---

### `subcategories`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK DEFAULT gen_random_uuid()::text | |
| type | VARCHAR(50) NOT NULL | CHECK: job \| skill |
| category_id | VARCHAR(255) NOT NULL | FK → `categories(id)` |
| name | VARCHAR(255) NOT NULL | |
| tenant_id | VARCHAR(255) | |
| role | VARCHAR(50) | |
| is_active | BOOLEAN NOT NULL DEFAULT TRUE | |
| created_at, updated_at | TIMESTAMP | |
| created_by, updated_by | VARCHAR(255) | |

**Migration:** `V33__Create_subcategories_table.sql` — UNIQUE(`type`, `category_id`, `name`, `tenant_id`).

---

### `tenant_feature_subscriptions`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | |
| tenant_id | VARCHAR(255) NOT NULL | FK → `tenants` |
| feature_id | VARCHAR(255) NOT NULL | FK → `feature_flag_config` |
| is_enabled | BOOLEAN NOT NULL DEFAULT FALSE | |
| enabled_by, disabled_by | VARCHAR(255) | |
| enabled_at, disabled_at | TIMESTAMP | |
| created_at, updated_at | TIMESTAMP | |

**Migration:** `V53__Create_tenant_feature_subscriptions_table.sql` — UNIQUE(`tenant_id`, `feature_id`).

---

### `tenant_job_ontology`

| Column | Type | Notes |
|--------|------|-------|
| job_ontology_id | VARCHAR(255) PK | |
| tenant_id | VARCHAR(255) NOT NULL | FK → `tenants` |
| job_id | VARCHAR(255) NOT NULL | FK → `job_taxonomy(job_id)` |
| must_have_weightage, good_to_have_weightage, must_have_behavioural_weightage | DECIMAL(5,2) | |
| required_level | VARCHAR(50) NOT NULL | |
| created_by | VARCHAR(255) NOT NULL | |
| created_at, updated_at | TIMESTAMP | |
| is_active | BOOLEAN NOT NULL DEFAULT TRUE | |

**Migration:** `V8__Create_tenant_job_ontology_table.sql` — partial unique (`tenant_id`, `job_id`) WHERE `is_active`.

---

### `tenants`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | |
| name | VARCHAR(255) NOT NULL | |
| job_category_ids, skill_category_ids | VARCHAR(255)[] | |
| logo_url, favicon | VARCHAR(500) | |
| status | VARCHAR(50) NOT NULL DEFAULT ACTIVE | CHECK |
| subscription_plan | VARCHAR(50) NOT NULL DEFAULT BASIC | CHECK |
| created_at, updated_at | TIMESTAMP | |

**Migration:** `V1__Create_tenants_table.sql`.

---

### `user_permission_mapping`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | |
| user_id | VARCHAR(255) NOT NULL | FK → `users(id)` |
| permission_id | VARCHAR(255) NOT NULL | FK → `permissions_list(id)` |
| granted_by | VARCHAR(255) | |
| created_at | TIMESTAMP DEFAULT now | |

**Migration:** `V50__Create_user_permission_mapping_table.sql` — UNIQUE(`user_id`, `permission_id`).

---

### `users`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | |
| tenant_id | VARCHAR(255) | FK → `tenants` |
| email | VARCHAR(255) NOT NULL UNIQUE | |
| password | VARCHAR(255) | |
| first_name, last_name | VARCHAR(100) NOT NULL | |
| role | VARCHAR(50) NOT NULL | CHECK: MASTER_ADMIN, ADMIN, SUPER_ADMIN, MENTOR, EVALUATOR, STUDENT |
| parent_admin_id | VARCHAR(255) | FK → `users(id)` |
| token_version | INTEGER NOT NULL DEFAULT 0 | |
| status | VARCHAR(50) NOT NULL DEFAULT ACTIVE | CHECK |
| last_login | TIMESTAMP | |
| phone | VARCHAR(20) | |
| department | VARCHAR(255) | |
| specialization, qualification | VARCHAR(500) | |
| experience | VARCHAR(100) | |
| created_at, updated_at | TIMESTAMP | |
| is_active | BOOLEAN NOT NULL DEFAULT TRUE | |

**Migration:** `V4__Create_users_table.sql`.

---

### `vendor_api_keys`

| Column | Type | Notes |
|--------|------|-------|
| id | VARCHAR(255) PK | |
| tenant_id | VARCHAR(255) NOT NULL | FK → `tenants` |
| api_key_hash | VARCHAR(255) NOT NULL | |
| key_prefix | VARCHAR(16) | |
| vendor_name | VARCHAR(255) NOT NULL | |
| is_active | BOOLEAN NOT NULL DEFAULT TRUE | |
| created_at, updated_at | TIMESTAMP | |
| last_used_at | TIMESTAMP | |
| rate_limit_per_minute | INTEGER | |
| allowed_ips | TEXT[] | |

**Migration:** `V36__Create_vendor_api_keys_table.sql`.

---

## Migrations that change constraints only (no new tables)

| Version | Summary |
|---------|---------|
| `V34` | FKs from `skill_taxonomy` / `job_taxonomy` to `categories` and `subcategories` |
| `V57` | `formal_parameters` unique constraint: drop `type` from unique key |
| `V59` | Drop incorrect FK from `student_formal_submissions` to `formal_parameters` |
| `V60` | Drop incorrect FK from `student_submission_urls` to `student_formal_submissions` |

---

## Functions, triggers, and procedural SQL

Hundreds of **functions** and **triggers** are defined across migrations (notably **`V26`**, **`V28`**, **`V31`**, **`V38`–`V42`**, **`V45`–`V46`**). For the authoritative list, search the migration folder for `CREATE OR REPLACE FUNCTION` and `CREATE TRIGGER`, or use `pg_dump --schema-only` on a migrated database.

---

*Generated for sharing and AI tooling context. Regenerate or diff against `pg_dump` when precision matters.*
