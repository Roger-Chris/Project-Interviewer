# Run the unified SkillForge API from the SkillForge repo root.
# Usage (from anywhere):
#   pwsh -File C:\path\to\SkillForge\scripts\run-api.ps1
#   pwsh -File .\scripts\run-api.ps1 -Port 8000

param(
    [int] $Port = 8000,
    [string] $BindHost = "0.0.0.0",
    [switch] $NoReload
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Set-Location $Root

Write-Host "SkillForge root: $Root"
Write-Host "Installing dependencies from requirements.txt ..."
python -m pip install -r (Join-Path $Root "requirements.txt")

$extra = @()
if ($NoReload) { $extra += "--no-reload" }

Write-Host "Starting unified API on ${BindHost}:$Port ..."
python (Join-Path $Root "run_api.py") --host $BindHost --port $Port @extra
