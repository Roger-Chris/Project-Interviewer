# skill_suggester

Suggests skills for a student experiential submission from project metadata, outcomes, and an uploaded ZIP, using the tenant skill catalog and Azure OpenAI.

Mounted on the **unified SkillForge API** at `POST /api/suggest-skills` (same host, port, and `X-API-Key` as `POST /api/generate-rubric` and `POST /api/analyze-certificate`). Spring Boot calls that URL via `vendor.rubric-engine` — not this service directly from the browser.

## Catalog scope (must match skill-sphere-1)

Skills sent to the LLM are **not** filtered by `skill_taxonomy.tenant_id`. They are limited to active skills whose `category_id` is in the tenant’s `tenants.skill_category_ids` array (skill categories only, `categories.type = 'skill'`), same as student skill search and `findByCategoryInAndIsActiveTrue` in Java.

## Layout (same pattern as `certificate_evaluator/`)

```
skill_suggester/
  app/
    routes/suggest_skills.py   # POST /suggest-skills (prefixed /api when mounted)
    services/                  # DB, ZIP, OpenAI, context
    core/settings.py
  app/unified.py               # mount_skill_suggester() used by evaluator/backend.py
```

## Configuration

Uses **`SkillForge/.env`** when run via `python run_api.py` (evaluator loads it). Keys:

- `AZURE_OPENAI_*`, `DATABASE_URL` (or `DB_*`), `MAX_SKILLS_IN_PROMPT`, `LOG_LEVEL`

## Run standalone (dev only)

```bash
cd skill_suggester
pip install -r ../requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```

## Tests

```bash
cd skill_suggester
pytest
```
