"""Standalone entrypoint: uvicorn main:app (from skill_suggester/)."""

from app.main import app, create_app

__all__ = ["app", "create_app"]
