"""Skill suggester service package."""
