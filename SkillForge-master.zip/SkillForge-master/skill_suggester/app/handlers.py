"""Shared exception handlers for skill_suggester."""

from __future__ import annotations

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from .models.schemas import ErrorResponse
from .services.exceptions import ServiceError
from .utils.logger import get_logger

LOGGER = get_logger(__name__)


def register_exception_handlers(app: FastAPI) -> None:
    """Register skill_suggester error envelopes on a FastAPI app."""

    @app.exception_handler(ServiceError)
    async def _service_error_handler(request: Request, exc: ServiceError) -> JSONResponse:
        tenant_id = getattr(request.state, "tenant_id", None)
        payload = ErrorResponse(error=exc.error_type, detail=str(exc), tenant_id=tenant_id)
        return JSONResponse(status_code=exc.status_code, content=payload.model_dump())

    @app.exception_handler(Exception)
    async def _unhandled_error_handler(request: Request, exc: Exception) -> JSONResponse:
        tenant_id = getattr(request.state, "tenant_id", None)
        LOGGER.exception("Unhandled exception")
        payload = ErrorResponse(
            error="internal_error", detail="Internal server error", tenant_id=tenant_id
        )
        return JSONResponse(status_code=500, content=payload.model_dump())
