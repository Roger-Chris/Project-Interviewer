"""API routes for the skill suggester service."""

from __future__ import annotations

import asyncio
import time
from typing import List

from fastapi import APIRouter, Depends, File, Form, Request, Response, UploadFile

from ..core.settings import Settings, get_settings
from ..models.schemas import SkillSuggestionMetadata, SkillSuggestionResponse
from ..services.context_builder import build_context
from ..services.exceptions import ConfigurationError
from ..services.openai_service import suggest_skills
from ..services.skill_db_service import fetch_tenant_skills
from ..services.zip_processor import process_zip_bytes
from ..utils.logger import get_logger

LOGGER = get_logger(__name__)

router = APIRouter()


@router.get("/health")
async def health_check() -> dict:
    """Health endpoint for uptime checks."""

    return {"status": "ok", "version": "1.0.0"}


@router.post("/suggest-skills", response_model=SkillSuggestionResponse)
async def suggest_skills_route(
    request: Request,
    response: Response,
    tenant_id: str = Form(...),
    project_title: str = Form(...),
    project_desc: str = Form(...),
    project_outcomes: str = Form(...),
    project_zip: UploadFile = File(...),
    settings: Settings = Depends(get_settings),
) -> SkillSuggestionResponse:
    """Suggest skills for a given project payload."""

    missing = [
        name
        for name, value in {
            "AZURE_OPENAI_API_KEY": settings.azure_openai_api_key,
            "AZURE_OPENAI_ENDPOINT": settings.azure_openai_endpoint,
            "AZURE_OPENAI_DEPLOYMENT": settings.azure_openai_deployment,
            "AZURE_OPENAI_API_VERSION": settings.azure_openai_api_version,
        }.items()
        if not value
    ]
    if missing:
        raise ConfigurationError(
            "Missing Azure OpenAI configuration: " + ", ".join(missing)
        )

    request.state.tenant_id = tenant_id
    start_time = time.perf_counter()

    zip_bytes = await project_zip.read()
    pool = getattr(request.app.state, 'skill_suggester_pool', None) or request.app.state.db_pool

    tenant_skills, zip_summary = await asyncio.gather(
        fetch_tenant_skills(tenant_id=tenant_id, pool=pool, logger=LOGGER),
        asyncio.to_thread(process_zip_bytes, zip_bytes, LOGGER),
    )

    context = build_context(
        tenant_id=tenant_id,
        project_title=project_title,
        project_description=project_desc,
        project_outcomes=project_outcomes,
        skills=tenant_skills,
        zip_summary=zip_summary,
        max_skills_in_prompt=settings.max_skills_in_prompt,
        logger=LOGGER,
    )

    suggestions = await suggest_skills(
        context=context,
        tenant_skills=tenant_skills,
        settings=settings,
        logger=LOGGER,
    )

    processing_time_ms = int((time.perf_counter() - start_time) * 1000)
    response.headers["X-Processing-Time-Ms"] = str(processing_time_ms)

    metadata = SkillSuggestionMetadata(
        total_tenant_skills=len(tenant_skills),
        file_extensions_detected=zip_summary.get("file_extensions", []),
        requirements_modules=zip_summary.get("requirements_modules", []),
        model_used=settings.azure_openai_deployment,
        processing_time_ms=processing_time_ms,
    )

    return SkillSuggestionResponse(
        tenant_id=tenant_id,
        project_title=project_title,
        suggested_skills=suggestions,
        metadata=metadata,
    )
