"""Application configuration using pydantic-settings."""

from __future__ import annotations

from functools import lru_cache

from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
	"""Typed settings loaded from environment variables."""

	azure_openai_api_key: str | None = Field(default=None, alias="AZURE_OPENAI_API_KEY")
	azure_openai_endpoint: str | None = Field(default=None, alias="AZURE_OPENAI_ENDPOINT")
	azure_openai_deployment: str | None = Field(
		default=None, alias="AZURE_OPENAI_DEPLOYMENT"
	)
	azure_openai_api_version: str | None = Field(default=None, alias="AZURE_OPENAI_API_VERSION")
	database_url: str | None = Field(default=None, alias="DATABASE_URL")
	db_host: str | None = Field(default=None, alias="DB_HOST")
	db_port: int = Field(default=5432, alias="DB_PORT")
	db_name: str | None = Field(default=None, alias="DB_NAME")
	db_user: str | None = Field(default=None, alias="DB_USER")
	db_password: str | None = Field(default=None, alias="DB_PASSWORD")
	max_skills_in_prompt: int = Field(default=700, alias="MAX_SKILLS_IN_PROMPT")
	log_level: str = Field(default="INFO", alias="LOG_LEVEL")
	openai_input_cost_per_1k: float = Field(default=0.0, alias="OPENAI_INPUT_COST_PER_1K")
	openai_output_cost_per_1k: float = Field(default=0.0, alias="OPENAI_OUTPUT_COST_PER_1K")

	model_config = SettingsConfigDict(
		env_file=".env",
		env_file_encoding="utf-8",
		case_sensitive=False,
		extra="ignore",
	)

	@model_validator(mode="after")
	def _ensure_database_url(self) -> "Settings":
		"""Construct database URL from components when not provided."""

		if self.database_url:
			return self
		if not all([self.db_host, self.db_name, self.db_user, self.db_password]):
			missing = [
				name
				for name, value in {
					"DB_HOST": self.db_host,
					"DB_NAME": self.db_name,
					"DB_USER": self.db_user,
					"DB_PASSWORD": self.db_password,
				}.items()
				if not value
			]
			raise ValueError(
				"DATABASE_URL is required or provide DB_HOST, DB_NAME, DB_USER, DB_PASSWORD; "
				f"missing: {', '.join(missing)}"
			)
		self.database_url = (
			f"postgresql://{self.db_user}:{self.db_password}"
			f"@{self.db_host}:{self.db_port}/{self.db_name}"
		)
		return self


@lru_cache(maxsize=1)
def get_settings() -> Settings:
	"""Return cached application settings."""

	return Settings()
