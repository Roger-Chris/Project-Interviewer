"""Mount skill_suggester on the unified SkillForge evaluator FastAPI app."""

from __future__ import annotations

import logging
from typing import Any, Sequence

import asyncpg
from fastapi import FastAPI

from .core.settings import get_settings
from .handlers import register_exception_handlers
from .routes.suggest_skills import router as suggest_skills_router

logger = logging.getLogger(__name__)


def mount_skill_suggester(
    app: FastAPI,
    *,
    dependencies: Sequence[Any] | None = None,
) -> bool:
    """
    Attach POST /api/suggest-skills (and health) to the unified SkillForge app.

    Returns True when routes were registered.
    """
    deps: list[Any] = list(dependencies or [])
    app.include_router(
        suggest_skills_router,
        prefix="/api",
        tags=["skill-suggester"],
        dependencies=deps,
    )
    if not getattr(app.state, "_skill_suggester_handlers_registered", False):
        register_exception_handlers(app)
        app.state._skill_suggester_handlers_registered = True

    @app.on_event("startup")
    async def _skill_suggester_startup() -> None:
        if getattr(app.state, "skill_suggester_pool", None) is not None:
            return
        settings = get_settings()
        logger.info("Creating skill_suggester database pool for unified API")
        app.state.skill_suggester_pool = await asyncpg.create_pool(settings.database_url)
        app.state.db_pool = app.state.skill_suggester_pool

    @app.on_event("shutdown")
    async def _skill_suggester_shutdown() -> None:
        pool = getattr(app.state, "skill_suggester_pool", None)
        if pool is not None:
            await pool.close()
            app.state.skill_suggester_pool = None

    return True
