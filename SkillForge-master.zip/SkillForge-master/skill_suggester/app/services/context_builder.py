"""Builds prompt context for OpenAI."""

from __future__ import annotations

import json
from typing import Dict, List

from ..utils.logger import get_logger

LOGGER = get_logger(__name__)


def _truncate(text: str, max_len: int) -> str:
    """Truncate text to a maximum length."""

    return text if len(text) <= max_len else text[: max_len - 3].rstrip() + "..."


def _estimate_tokens(payload: Dict[str, object]) -> int:
    """Roughly estimate token count for the payload."""

    return max(1, len(json.dumps(payload, ensure_ascii=False)) // 3)


def build_context(
    *,
    tenant_id: str,
    project_title: str,
    project_description: str,
    project_outcomes: str,
    skills: List[Dict[str, str]],
    zip_summary: Dict[str, List[str]],
    max_skills_in_prompt: int,
    logger=LOGGER,
) -> Dict[str, object]:
    """Create a structured prompt context for OpenAI.

    Args:
        tenant_id: Tenant UUID.
        project_title: Project title.
        project_description: Project description.
        project_outcomes: Project outcomes.
        skills: Tenant skills list.
        zip_summary: Output from zip processor.
        max_skills_in_prompt: Max skills to include in prompt.
        logger: Logger instance.

    Returns:
        Dict ready for prompt formatting.
    """

    # Use all skills from the DB; token estimation will trigger description
    # trimming if the payload becomes too large.
    def build_skill_list() -> List[Dict[str, str]]:
        return [
            {
                "skill_id": skill["skill_id"],
                "skill_name": skill["skill_name"],
            }
            for skill in skills
        ]

    skill_list = build_skill_list()
    payload = {
        "tenant_id": tenant_id,
        "project_title": project_title,
        "project_description": project_description,
        "project_outcomes": project_outcomes,
        "file_extensions": zip_summary.get("file_extensions", []),
        "requirements_modules": zip_summary.get("requirements_modules", []),
        "total_skills": len(skills),
        "skill_list": skill_list,
    }

    if _estimate_tokens(payload) > 80000:
        logger.warning("Prompt payload exceeded token limit; consider reducing skills")

    return payload
