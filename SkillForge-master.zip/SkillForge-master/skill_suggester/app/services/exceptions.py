"""Custom exception types for service errors."""

from __future__ import annotations


class ServiceError(Exception):
    """Base class for service-layer exceptions."""

    error_type = "service_error"
    status_code = 500

    def __init__(self, message: str) -> None:
        super().__init__(message)


class SkillDBError(ServiceError):
    """Raised when a database operation fails."""

    error_type = "skill_db_error"
    status_code = 503


class ZipProcessingError(ServiceError):
    """Raised when zip processing fails."""

    error_type = "zip_processing_error"
    status_code = 422


class OpenAIServiceError(ServiceError):
    """Raised when OpenAI calls fail."""

    error_type = "openai_service_error"
    status_code = 502


class ConfigurationError(ServiceError):
    """Raised when required configuration is missing."""

    error_type = "config_error"
    status_code = 500
