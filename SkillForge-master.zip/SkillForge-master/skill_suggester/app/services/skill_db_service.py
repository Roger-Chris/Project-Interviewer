"""Database access for tenant-scoped skill catalog."""

from __future__ import annotations

import time
from typing import Dict, List

import asyncpg

from .exceptions import SkillDBError
from ..utils.logger import get_logger

LOGGER = get_logger(__name__)

# Aligns with skill-sphere-1: tenants.skill_category_ids → categories (type=skill) → skill_taxonomy.category_id
_TENANT_SKILL_CATALOG_SQL = """
SELECT st.skill_id, st.skill_name, st.description
FROM skill_taxonomy st
INNER JOIN categories c ON c.id = st.category_id
WHERE st.is_active = true
  AND c.is_active = true
  AND LOWER(c.type) = 'skill'
  AND c.id = ANY(
    COALESCE(
      (SELECT skill_category_ids FROM tenants WHERE id = $1),
      ARRAY[]::varchar[]
    )
  )
ORDER BY st.skill_name
"""


async def fetch_tenant_skills(
    tenant_id: str,
    pool: asyncpg.Pool,
    logger=LOGGER,
) -> List[Dict[str, str]]:
    """Fetch active skills in the tenant's assigned skill categories.

    Catalog scope matches Java (SkillSearchService, findByCategoryInAndIsActiveTrue):
    ``tenants.skill_category_ids`` → ``categories`` (type skill) → ``skill_taxonomy``.

    Args:
        tenant_id: Tenant id (tenants.id).
        pool: Asyncpg connection pool.
        logger: Logger instance.

    Returns:
        List of skill records for the prompt catalog.

    Raises:
        SkillDBError: If the DB query fails.
    """

    start_time = time.perf_counter()
    row_count = 0
    try:
        async with pool.acquire() as connection:
            rows = await connection.fetch(_TENANT_SKILL_CATALOG_SQL, tenant_id)
            row_count = len(rows)
    except asyncpg.PostgresError as exc:
        logger.exception("Skill DB query failed", extra={"tenant_id": tenant_id})
        raise SkillDBError("Failed to fetch tenant skills") from exc
    finally:
        duration_ms = int((time.perf_counter() - start_time) * 1000)
        logger.info(
            "Skill DB query completed",
            extra={
                "tenant_id": tenant_id,
                "duration_ms": duration_ms,
                "skill_count": row_count,
            },
        )

    if row_count == 0:
        logger.warning(
            "No skills in catalog for tenant (check tenants.skill_category_ids and category assignments)",
            extra={"tenant_id": tenant_id},
        )

    return [
        {
            "skill_id": str(row["skill_id"]),
            "skill_name": row["skill_name"],
            "skill_description": row["description"] or "",
        }
        for row in rows
    ]
