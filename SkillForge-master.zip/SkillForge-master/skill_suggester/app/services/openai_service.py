"""Azure OpenAI integration for skill suggestions."""

from __future__ import annotations

import json
import time
from typing import Dict, List

from openai import AsyncAzureOpenAI, OpenAIError

from ..core.settings import Settings
from .exceptions import OpenAIServiceError
from ..utils.logger import get_logger

LOGGER = get_logger(__name__)

SYSTEM_PROMPT = """
You are a technical skill assessment engine. Your only job is to
analyze a software project's metadata and suggest which skills
from a provided catalog are actually demonstrated or required
by that project.

Rules:
- Only suggest skills that are clearly evidenced by the project
  details given. Do NOT invent or assume skills not supported
  by the data.
- Limit suggestions to a maximum of 20 skills.
- Respond ONLY with a valid JSON array. No preamble, no markdown
  fences, no explanation outside the JSON.
""".strip()


def _build_user_prompt(context: Dict[str, object]) -> str:
    """Render the user prompt from context."""

    skill_list_json = json.dumps(context["skill_list"], ensure_ascii=False, indent=2)
    return f"""
PROJECT TITLE: {context['project_title']}

PROJECT DESCRIPTION:
{context['project_description']}

PROJECT OUTCOMES:
{context['project_outcomes']}

FILES DETECTED:
Extensions: {context['file_extensions']}
Requirements/modules: {context['requirements_modules']}

AVAILABLE SKILLS CATALOG ({context['total_skills']} skills):
{skill_list_json}

Return a JSON array of suggested skills in this exact schema:
[
  {{
    "skill_id": "<id from catalog>",
        "skill_name": "<name from catalog>"
  }}
]
""".strip()


def _filter_valid_skills(
    suggestions: List[Dict[str, object]],
    catalog: Dict[str, Dict[str, str]],
) -> List[Dict[str, object]]:
    """Drop suggestions not in the tenant catalog."""

    valid: List[Dict[str, object]] = []
    for item in suggestions:
        skill_id = str(item.get("skill_id", ""))
        if skill_id not in catalog:
            continue
        catalog_entry = catalog[skill_id]
        valid.append(
            {
                "skill_id": skill_id,
                "skill_name": catalog_entry["skill_name"],
            }
        )
    return valid[:20]


async def suggest_skills(
    *,
    context: Dict[str, object],
    tenant_skills: List[Dict[str, str]],
    settings: Settings,
    logger=LOGGER,
) -> List[Dict[str, object]]:
    """Call Azure OpenAI to get skill suggestions.

    Args:
        context: Prompt context.
        tenant_skills: Tenant skill catalog.
        settings: Application settings.
        logger: Logger instance.

    Returns:
        List of suggested skills.

    Raises:
        OpenAIServiceError: On API failure or invalid response.
    """

    start_time = time.perf_counter()
    catalog = {skill["skill_id"]: skill for skill in tenant_skills}
    client = AsyncAzureOpenAI(
        api_key=settings.azure_openai_api_key,
        azure_endpoint=settings.azure_openai_endpoint,
        api_version=settings.azure_openai_api_version,
    )

    user_prompt = _build_user_prompt(context)
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": user_prompt},
    ]

    usage_snapshot: Dict[str, int] = {}

    async def _call_openai(msgs: List[Dict[str, str]]) -> str:
        response = await client.chat.completions.create(
            model=settings.azure_openai_deployment,
            temperature=0.1,
            max_tokens=4096,
            messages=msgs,
        )
        if response.usage:
            usage_snapshot["prompt_tokens"] = response.usage.prompt_tokens or 0
            usage_snapshot["completion_tokens"] = response.usage.completion_tokens or 0
            usage_snapshot["total_tokens"] = response.usage.total_tokens or 0
        return response.choices[0].message.content or ""

    try:
        content = await _call_openai(messages)
        try:
            parsed = json.loads(content)
        except json.JSONDecodeError:
            messages.append(
                {
                    "role": "user",
                    "content": "The previous response was invalid JSON. Return ONLY a valid JSON array.",
                }
            )
            content = await _call_openai(messages)
            parsed = json.loads(content)
    except (OpenAIError, json.JSONDecodeError) as exc:
        logger.exception("OpenAI request failed")
        raise OpenAIServiceError("Failed to retrieve skill suggestions") from exc
    finally:
        duration_ms = int((time.perf_counter() - start_time) * 1000)
        prompt_tokens = usage_snapshot.get("prompt_tokens", 0)
        completion_tokens = usage_snapshot.get("completion_tokens", 0)
        total_tokens = usage_snapshot.get("total_tokens", 0)
        cost = (
            (prompt_tokens / 1000) * settings.openai_input_cost_per_1k
            + (completion_tokens / 1000) * settings.openai_output_cost_per_1k
        )
        logger.info(
            "OpenAI request completed",
            extra={
                "duration_ms": duration_ms,
                "model": settings.azure_openai_deployment,
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "total_tokens": total_tokens,
                "estimated_cost_usd": round(cost, 6),
            },
        )

    if not isinstance(parsed, list):
        raise OpenAIServiceError("OpenAI response did not contain a JSON array")

    return _filter_valid_skills(parsed, catalog)
