"""In-memory ZIP processing utilities."""

from __future__ import annotations

import io
import re
import time
import zipfile
from pathlib import PurePosixPath
from typing import Dict, List

from .exceptions import ZipProcessingError
from ..utils.logger import get_logger

LOGGER = get_logger(__name__)

IGNORED_DIRS = {"__macosx", ".git", "__pycache__"}
IGNORED_FILES = {".ds_store", "thumbs.db"}
BINARY_EXTENSIONS = {
    ".png",
    ".jpg",
    ".jpeg",
    ".gif",
    ".mp4",
    ".mov",
    ".avi",
    ".pdf",
    ".zip",
    ".gz",
    ".tar",
    ".7z",
    ".ico",
}


def _is_ignored_path(path: PurePosixPath) -> bool:
    """Return True if the path should be ignored."""

    parts = [part.lower() for part in path.parts]
    if not parts:
        return True
    if any(part in IGNORED_DIRS for part in parts):
        return True
    if path.name.lower() in IGNORED_FILES:
        return True
    return False


def _clean_requirement(line: str) -> str | None:
    """Normalize a requirements.txt line into a package name."""

    line = line.split("#", 1)[0].strip()
    if not line:
        return None
    if line.startswith("-") or line.startswith("git+"):
        return None
    base = re.split(r"[<>=!~]", line, maxsplit=1)[0]
    base = base.split("[", 1)[0].strip()
    return base.lower() if base else None


def process_zip_bytes(zip_bytes: bytes, logger=LOGGER) -> Dict[str, List[str]]:
    """Extract file extensions and requirements from a ZIP archive.

    Args:
        zip_bytes: Raw zip bytes.
        logger: Logger instance.

    Returns:
        Dict with file extensions and requirements modules.

    Raises:
        ZipProcessingError: When the ZIP is invalid or empty.
    """

    start_time = time.perf_counter()
    try:
        with zipfile.ZipFile(io.BytesIO(zip_bytes)) as archive:
            names = [name for name in archive.namelist() if not name.endswith("/")]
            if not names:
                raise ZipProcessingError("ZIP archive contains no files")

            extensions: set[str] = set()
            requirements: set[str] = set()
            for name in names:
                path = PurePosixPath(name)
                if _is_ignored_path(path):
                    continue
                if path.suffix.lower() in BINARY_EXTENSIONS:
                    continue
                if path.name.lower() == "requirements.txt":
                    try:
                        content = archive.read(name).decode("utf-8", errors="ignore")
                    except (RuntimeError, UnicodeDecodeError) as exc:
                        raise ZipProcessingError("Failed to read requirements.txt") from exc
                    for line in content.splitlines():
                        cleaned = _clean_requirement(line)
                        if cleaned:
                            requirements.add(cleaned)
                if path.suffix:
                    extensions.add(path.suffix.lower())
    except ZipProcessingError:
        raise
    except (zipfile.BadZipFile, RuntimeError, ValueError) as exc:
        logger.exception("ZIP processing failed")
        raise ZipProcessingError("Invalid or unreadable ZIP archive") from exc
    finally:
        duration_ms = int((time.perf_counter() - start_time) * 1000)
        logger.info("ZIP processing completed", extra={"duration_ms": duration_ms})

    return {
        "file_extensions": sorted(extensions),
        "requirements_modules": sorted(requirements),
    }
