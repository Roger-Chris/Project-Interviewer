"""FastAPI application factory for skill_suggester (standalone or tests)."""

from __future__ import annotations

import logging
from typing import Optional

import asyncpg
from fastapi import FastAPI

from .core.settings import Settings, get_settings
from .handlers import register_exception_handlers
from .routes.suggest_skills import router as suggest_skills_router
from .utils.logger import get_logger

LOGGER = get_logger(__name__)


def _configure_logging(settings: Settings) -> None:
    level = logging.getLevelName(settings.log_level.upper())
    logging.getLogger().setLevel(level)
    LOGGER.setLevel(level)


def create_app(*, db_pool_override: Optional[asyncpg.Pool] = None, skip_db_init: bool = False) -> FastAPI:
    """Create the skill_suggester FastAPI application."""

    settings = get_settings()
    _configure_logging(settings)

    app = FastAPI(title="skill_suggester", version="1.0.0")
    app.include_router(suggest_skills_router, prefix="/api", tags=["skill-suggester"])
    register_exception_handlers(app)

    app.state.skill_suggester_pool = db_pool_override
    app.state.db_pool = db_pool_override  # legacy alias for tests

    @app.on_event("startup")
    async def _startup() -> None:
        if skip_db_init:
            return
        if app.state.skill_suggester_pool is None:
            LOGGER.info("Creating skill_suggester database pool")
            app.state.skill_suggester_pool = await asyncpg.create_pool(settings.database_url)
            app.state.db_pool = app.state.skill_suggester_pool

    @app.on_event("shutdown")
    async def _shutdown() -> None:
        pool = app.state.skill_suggester_pool
        if pool is not None:
            await pool.close()

    return app


app = create_app()
