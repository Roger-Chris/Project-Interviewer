"""Pydantic models for requests and responses."""

from __future__ import annotations

from typing import List, Literal

from pydantic import BaseModel, Field


class SkillSuggestionItem(BaseModel):
	"""Represents a suggested skill."""

	skill_id: str = Field(..., description="Skill UUID from catalog")
	skill_name: str = Field(..., description="Skill name")


class SkillSuggestionMetadata(BaseModel):
	"""Metadata returned with skill suggestions."""

	total_tenant_skills: int
	file_extensions_detected: List[str]
	requirements_modules: List[str]
	model_used: str
	processing_time_ms: int


class SkillSuggestionResponse(BaseModel):
	"""Response returned to the Java client."""

	tenant_id: str
	project_title: str
	suggested_skills: List[SkillSuggestionItem]
	metadata: SkillSuggestionMetadata


class ErrorResponse(BaseModel):
	"""Error envelope for consistent error responses."""

	error: str
	detail: str
	tenant_id: str | None = None
