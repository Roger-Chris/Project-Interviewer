"""Structured JSON logging utilities."""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any, Dict


class JsonFormatter(logging.Formatter):
	"""Format log records as JSON."""

	def format(self, record: logging.LogRecord) -> str:  # noqa: D401
		base: Dict[str, Any] = {
			"timestamp": datetime.now(timezone.utc).isoformat(),
			"level": record.levelname,
			"logger": record.name,
			"message": record.getMessage(),
		}
		if record.exc_info:
			base["exception"] = self.formatException(record.exc_info)
		for key, value in record.__dict__.items():
			if key.startswith("_") or key in base:
				continue
			if key in {"args", "msg", "exc_info", "exc_text", "stack_info"}:
				continue
			base[key] = value
		return json.dumps(base, default=str)


def get_logger(name: str) -> logging.Logger:
	"""Return a configured JSON logger."""

	logger = logging.getLogger(name)
	if not logger.handlers:
		handler = logging.StreamHandler()
		handler.setFormatter(JsonFormatter())
		logger.addHandler(handler)
	logger.setLevel(logging.INFO)
	logger.propagate = False
	return logger
