"""Tests for tenant-scoped skill catalog SQL."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest

from app.services.skill_db_service import _TENANT_SKILL_CATALOG_SQL, fetch_tenant_skills


@pytest.mark.asyncio
async def test_fetch_tenant_skills_uses_category_scope_query() -> None:
    connection = AsyncMock()
    connection.fetch = AsyncMock(return_value=[])
    pool = MagicMock()
    pool.acquire.return_value.__aenter__ = AsyncMock(return_value=connection)
    pool.acquire.return_value.__aexit__ = AsyncMock(return_value=False)

    result = await fetch_tenant_skills("tenant-abc", pool)

    assert result == []
    connection.fetch.assert_awaited_once()
    args = connection.fetch.await_args
    assert args is not None
    assert "skill_category_ids" in args.args[0]
    assert "categories" in args.args[0]
    assert "skill_taxonomy" in args.args[0]
    assert args.args[0] == _TENANT_SKILL_CATALOG_SQL
    assert args.args[1] == "tenant-abc"


@pytest.mark.asyncio
async def test_fetch_tenant_skills_maps_rows() -> None:
    row = {"skill_id": "s1", "skill_name": "Python", "description": "Desc"}
    connection = AsyncMock()
    connection.fetch = AsyncMock(return_value=[row])
    pool = MagicMock()
    pool.acquire.return_value.__aenter__ = AsyncMock(return_value=connection)
    pool.acquire.return_value.__aexit__ = AsyncMock(return_value=False)

    result = await fetch_tenant_skills("tenant-1", pool)

    assert result == [
        {
            "skill_id": "s1",
            "skill_name": "Python",
            "skill_description": "Desc",
        }
    ]
