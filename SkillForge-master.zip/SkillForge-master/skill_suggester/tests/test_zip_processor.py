"""Tests for ZIP processing."""

from __future__ import annotations

import io
import zipfile

import pytest

from app.services.exceptions import ZipProcessingError
from app.services.zip_processor import process_zip_bytes


def _make_zip(files: dict[str, bytes]) -> bytes:
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        for name, content in files.items():
            archive.writestr(name, content)
    return buffer.getvalue()


def test_valid_zip_with_requirements() -> None:
    zip_bytes = _make_zip(
        {
            "app/main.py": b"print('hello')",
            "requirements.txt": b"fastapi==0.110\npytest>=8\n",
        }
    )
    result = process_zip_bytes(zip_bytes)
    assert result["file_extensions"] == [".py", ".txt"]
    assert result["requirements_modules"] == ["fastapi", "pytest"]


def test_zip_missing_requirements() -> None:
    zip_bytes = _make_zip({"src/app.py": b"print('hello')"})
    result = process_zip_bytes(zip_bytes)
    assert result["file_extensions"] == [".py"]
    assert result["requirements_modules"] == []


def test_zip_with_only_binary_files() -> None:
    zip_bytes = _make_zip({"assets/logo.png": b"binary"})
    result = process_zip_bytes(zip_bytes)
    assert result["file_extensions"] == []
    assert result["requirements_modules"] == []


def test_malformed_zip_raises() -> None:
    with pytest.raises(ZipProcessingError):
        process_zip_bytes(b"not a zip")
