"""Tests for prompt context builder."""

from __future__ import annotations

from app.services.context_builder import build_context


def _make_skills(count: int, desc_length: int) -> list[dict[str, str]]:
    return [
        {
            "skill_id": f"id-{idx}",
            "skill_name": f"Skill {idx}",
            "skill_description": "x" * desc_length,
        }
        for idx in range(count)
    ]


def test_context_builder_field_mapping() -> None:
    skills = _make_skills(2, 50)
    zip_summary = {"file_extensions": [".py"], "requirements_modules": []}
    context = build_context(
        tenant_id="tenant-1",
        project_title="Project",
        project_description="Desc",
        project_outcomes="Outcomes",
        skills=skills,
        zip_summary=zip_summary,
        max_skills_in_prompt=700,
    )
    assert context["project_title"] == "Project"
    assert context["file_extensions"] == [".py"]
    assert context["requirements_modules"] == []
    assert context["total_skills"] == 2


def test_context_builder_trims_on_large_payload() -> None:
    skills = _make_skills(1500, 300)
    zip_summary = {"file_extensions": [".py"], "requirements_modules": []}
    context = build_context(
        tenant_id="tenant-2",
        project_title="Project",
        project_description="Desc",
        project_outcomes="Outcomes",
        skills=skills,
        zip_summary=zip_summary,
        max_skills_in_prompt=1500,
    )
    assert all("skill_description" not in skill for skill in context["skill_list"])
