"""API route tests."""

from __future__ import annotations

import io
import zipfile
from typing import Any

import pytest
from fastapi.testclient import TestClient
from app.services.exceptions import SkillDBError


def _make_zip() -> bytes:
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("main.py", "print('hello')")
    return buffer.getvalue()


@pytest.fixture()
def client(monkeypatch: pytest.MonkeyPatch) -> TestClient:
    monkeypatch.setenv("AZURE_OPENAI_API_KEY", "test")
    monkeypatch.setenv("AZURE_OPENAI_ENDPOINT", "https://example.com")
    monkeypatch.setenv("AZURE_OPENAI_DEPLOYMENT_NAME", "test-deploy")
    monkeypatch.setenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview")
    monkeypatch.setenv("DATABASE_URL", "postgresql://test")

    import importlib

    main = importlib.import_module("app.main")
    app = main.create_app(skip_db_init=True)
    app.state.skill_suggester_pool = None
    app.state.db_pool = None
    return TestClient(app)


def test_suggest_skills_success(client: TestClient, monkeypatch: pytest.MonkeyPatch) -> None:
    async def _mock_fetch(*args: Any, **kwargs: Any) -> list[dict[str, str]]:
        return [
            {"skill_id": "skill-1", "skill_name": "Python", "skill_description": "Desc"}
        ]

    async def _mock_openai(*args: Any, **kwargs: Any) -> list[dict[str, Any]]:
        return [
            {
                "skill_id": "skill-1",
                "skill_name": "Python",
            }
        ]

    def _mock_zip(*args: Any, **kwargs: Any) -> dict[str, list[str]]:
        return {"file_extensions": [".py"], "requirements_modules": []}

    monkeypatch.setattr("app.routes.suggest_skills.fetch_tenant_skills", _mock_fetch)
    monkeypatch.setattr("app.routes.suggest_skills.suggest_skills", _mock_openai)
    monkeypatch.setattr("app.routes.suggest_skills.process_zip_bytes", _mock_zip)

    response = client.post(
        "/api/suggest-skills",
        data={
            "tenant_id": "tenant-1",
            "project_title": "Title",
            "project_desc": "Desc",
            "project_outcomes": "Outcomes",
        },
        files={"project_zip": ("project.zip", _make_zip(), "application/zip")},
    )

    assert response.status_code == 200
    payload = response.json()
    assert payload["tenant_id"] == "tenant-1"
    assert payload["metadata"]["total_tenant_skills"] == 1


def test_missing_fields_returns_422(client: TestClient) -> None:
    response = client.post("/api/suggest-skills", data={"tenant_id": "tenant-1"})
    assert response.status_code == 422


def test_db_failure_returns_503(client: TestClient, monkeypatch: pytest.MonkeyPatch) -> None:
    async def _mock_fetch(*args: Any, **kwargs: Any) -> list[dict[str, str]]:
        raise SkillDBError("DB down")

    monkeypatch.setattr("app.routes.suggest_skills.fetch_tenant_skills", _mock_fetch)
    monkeypatch.setattr("app.routes.suggest_skills.process_zip_bytes", lambda *args, **kwargs: {"file_extensions": [], "requirements_modules": []})
    monkeypatch.setattr("app.routes.suggest_skills.suggest_skills", lambda *args, **kwargs: [])

    response = client.post(
        "/api/suggest-skills",
        data={
            "tenant_id": "tenant-1",
            "project_title": "Title",
            "project_desc": "Desc",
            "project_outcomes": "Outcomes",
        },
        files={"project_zip": ("project.zip", _make_zip(), "application/zip")},
    )

    assert response.status_code == 503
    assert response.json()["error"] == "skill_db_error"
