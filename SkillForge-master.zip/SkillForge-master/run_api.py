"""
Run the unified SkillForge API (evaluator + student-chatbot + certificate_evaluator + skill_suggester).

Always run from the SkillForge directory (the folder that contains .env and this file):

    pip install -r requirements.txt
    python run_api.py

Optional:

    python run_api.py --port 8000 --no-reload

Or: pwsh -File scripts/run-api.ps1
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(description="SkillForge unified API server")
    parser.add_argument("--host", default="0.0.0.0", help="Bind host")
    parser.add_argument("--port", type=int, default=8000, help="Bind port")
    parser.add_argument(
        "--no-reload",
        action="store_true",
        help="Disable autoreload (use in production)",
    )
    args = parser.parse_args()

    skillforge_root = Path(__file__).resolve().parent
    evaluator_dir = skillforge_root / "evaluator"
    if not evaluator_dir.is_dir():
        print(f"ERROR: evaluator directory not found: {evaluator_dir}", file=sys.stderr)
        sys.exit(1)

    # Same PYTHONPATH convention as Docker: repo root (packages) + evaluator (backend module).
    root_s = str(skillforge_root)
    eval_s = str(evaluator_dir)
    for entry in (root_s, eval_s):
        if entry not in sys.path:
            sys.path.insert(0, entry)
    os.chdir(evaluator_dir)

    import uvicorn  # noqa: PLC0415

    uvicorn.run(
        "backend:app",
        host=args.host,
        port=args.port,
        reload=not args.no_reload,
        reload_dirs=[str(evaluator_dir), str(skillforge_root)],
    )


if __name__ == "__main__":
    main()
