"""CLI runner for rubric generation."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from grading_module import generate_project_rubric


def main() -> None:
    if len(sys.argv) < 2:
        raise SystemExit("Usage: python run_rubric.py <input.json>")

    input_path = Path(sys.argv[1])
    if not input_path.is_file():
        raise SystemExit(f"Input JSON not found: {input_path}")

    with input_path.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)

    rubric = generate_project_rubric(payload)
    print(json.dumps(rubric, indent=2))


if __name__ == "__main__":
    main()
