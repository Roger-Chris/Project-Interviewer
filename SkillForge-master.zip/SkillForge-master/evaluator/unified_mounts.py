"""
Standard mounting helpers for the unified SkillForge API (evaluator/backend.py).

Patterns:

1. PACKAGE (certificate_evaluator, skill_suggester) — SkillForge root on sys.path, then:
       from {service}.app.unified import mount_{service}

2. LEGACY_PATH (student-chatbot/ai-service only) — flat layout with routers/, core/:
       import_from_service_path(ai_service_dir, mount_fn)

New services should use PACKAGE + relative imports under ``{service}/app/``.
"""

from __future__ import annotations

import logging
import sys
from collections.abc import Callable
from pathlib import Path
from typing import Any, TypeVar

logger = logging.getLogger(__name__)

T = TypeVar("T")

# SkillForge repo root (/app in Docker, parent of evaluator/).
SKILLFORGE_ROOT = Path(__file__).resolve().parent.parent


def ensure_skillforge_root_on_path() -> Path:
    """Ensure subprojects are importable as packages (certificate_evaluator, skill_suggester, ...)."""
    root_s = str(SKILLFORGE_ROOT)
    if root_s not in sys.path:
        sys.path.insert(0, root_s)
    return SKILLFORGE_ROOT


def subproject_dir(*parts: str) -> Path:
    """Path under SkillForge root, e.g. subproject_dir('skill_suggester')."""
    return SKILLFORGE_ROOT.joinpath(*parts)


def insert_service_path(service_dir: Path) -> bool:
    """Prepend *service_dir* to sys.path (student-chatbot LEGACY_PATH only)."""
    if not service_dir.is_dir():
        return False
    dir_s = str(service_dir)
    if dir_s not in sys.path:
        sys.path.insert(0, dir_s)
    return True


def try_mount(
    service_dir: Path,
    *,
    label: str,
    mount_fn: Callable[[], None],
    on_missing: Callable[[Path], None] | None = None,
) -> bool:
    """
    If *service_dir* exists, run *mount_fn*; log and return False on failure.

    *on_missing* is called when the directory does not exist (default: info log).
    """
    if not service_dir.is_dir():
        if on_missing is not None:
            on_missing(service_dir)
        else:
            logger.info("%s: directory not found at %s; routes disabled", label, service_dir)
        return False
    try:
        mount_fn()
        return True
    except Exception as exc:
        logger.exception("Failed to mount %s: %s", label, exc)
        return False


def import_from_service_path(service_dir: Path, importer: Callable[[], T]) -> T:
    """Run *importer* after ensuring *service_dir* is on sys.path (student-chatbot only)."""
    insert_service_path(service_dir)
    return importer()
