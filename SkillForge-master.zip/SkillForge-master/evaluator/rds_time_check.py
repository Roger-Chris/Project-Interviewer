import logging
import os
from urllib.parse import unquote, urlparse

import psycopg2
import requests
from dotenv import load_dotenv
from psycopg2 import OperationalError
from azure.storage.blob import BlobServiceClient
from azure.core.exceptions import ResourceNotFoundError

from skillforge_env import resolve_dotenv_path

load_dotenv(resolve_dotenv_path())

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def get_db_config() -> dict:
    return {
        "host": os.getenv("DB_HOST"),
        "port": int(os.getenv("DB_PORT", "5432")),
        "user": os.getenv("DB_USER"),
        "password": os.getenv("DB_PASSWORD"),
        "dbname": os.getenv("DB_NAME"),
    }


def get_connection():
    config = get_db_config()
    return psycopg2.connect(**config)


def get_blob_service_client() -> BlobServiceClient:
    connection_string = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
    account_name = os.getenv("AZURE_STORAGE_ACCOUNT_NAME") or os.getenv("AccountName")
    account_key = os.getenv("AZURE_STORAGE_ACCOUNT_KEY") or os.getenv("AccountKey")
    endpoint_suffix = (
        os.getenv("AZURE_STORAGE_ENDPOINT_SUFFIX")
        or os.getenv("EndpointSuffix")
        or "core.windows.net"
    )

    if connection_string:
        if "AccountName=" not in connection_string:
            raise ValueError(
                "AZURE_STORAGE_CONNECTION_STRING is missing AccountName. "
                "Provide a full connection string or set AccountName/AccountKey."
            )
        return BlobServiceClient.from_connection_string(connection_string)

    if account_name and account_key:
        connection_string = (
            "DefaultEndpointsProtocol=https;"
            f"AccountName={account_name};"
            f"AccountKey={account_key};"
            f"EndpointSuffix={endpoint_suffix}"
        )
        return BlobServiceClient.from_connection_string(connection_string)

    raise ValueError(
        "Azure Storage credentials are not set. Provide AZURE_STORAGE_CONNECTION_STRING "
        "or AccountName/AccountKey in the environment."
    )


def fetch_server_time() -> None:
    connection = None

    try:
        connection = get_connection()

        with connection.cursor() as cursor:
            cursor.execute("SELECT NOW();")
            server_time = cursor.fetchone()[0]
            logger.info("Connected. Server time: %s", server_time)
    except (OperationalError, Exception) as exc:
        logger.error("Connection failed: %s", exc)
    finally:
        if connection is not None:
            connection.close()


def get_submission_by_parameter_id(tenant_id: str, parameter_id: str):
    """Fetch outcomes, description, student_id, and title by parameter_id.

    This function performs a read-only SELECT and returns the row (or None if not found).
    """
    connection = None

    try:
        connection = get_connection()

        with connection.cursor() as cursor:
            cursor.execute(
                """
                                SELECT outcomes, description, student_id, title
                FROM student_experience_submissions
                WHERE parameter_id = %s
                                    AND tenant_id = %s;
                """,
                                (parameter_id, tenant_id),
            )
            return cursor.fetchone()
    except (OperationalError, Exception) as exc:
        logger.error("Query failed: %s", exc)
        return None
    finally:
        if connection is not None:
            connection.close()


def get_submission_urls_by_parameter_id(parameter_id: str):
    """Fetch url and type from student_submission_urls by artifact_id (parameter_id).

    This function performs a read-only SELECT and returns all matching rows.
    """
    connection = None

    try:
        connection = get_connection()

        with connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT url, type
                FROM student_submission_urls
                WHERE artifact_id = %s;
                """,
                (parameter_id,),
            )
            return cursor.fetchall()
    except (OperationalError, Exception) as exc:
        logger.error("Query failed: %s", exc)
        return []
    finally:
        if connection is not None:
            connection.close()


def get_admin_skill_ids(admin_id: str, tenant_id: str):
    """Fetch skill IDs from admin_skills by admin_id and tenant_id.

    This function performs a read-only SELECT and returns all matching rows.
    """
    connection = None

    try:
        connection = get_connection()

        with connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT skill_id
                FROM admin_skills
                WHERE admin_id = %s
                  AND tenant_id = %s;
                """,
                (admin_id, tenant_id),
            )
            return cursor.fetchall()
    except (OperationalError, Exception) as exc:
        logger.error("Query failed: %s", exc)
        return []
    finally:
        if connection is not None:
            connection.close()


def get_experience_skill_ids(parameter_id: str, tenant_id: str):
    """Fetch skill IDs from experience_skill_mapping by parameter_id and tenant_id.

    This function performs a read-only SELECT and returns all matching rows.
    """
    connection = None

    try:
        connection = get_connection()

        with connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT skill_id
                FROM experience_skill_mapping
                WHERE parameter_id = %s
                  AND tenant_id = %s;
                """,
                (parameter_id, tenant_id),
            )
            return cursor.fetchall()
    except (OperationalError, Exception) as exc:
        logger.error("Query failed: %s", exc)
        return []
    finally:
        if connection is not None:
            connection.close()


def get_common_skill_names(admin_skill_rows, experience_skill_rows):
    """Fetch skill names for IDs common to admin and experience mappings.

    This function performs a read-only SELECT and returns all matching names.
    """
    admin_skill_ids = {row[0] for row in admin_skill_rows if row}
    experience_skill_ids = {row[0] for row in experience_skill_rows if row}
    common_skill_ids = admin_skill_ids.intersection(experience_skill_ids)

    if not common_skill_ids:
        return []

    connection = None

    try:
        connection = get_connection()

        with connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT skill_name
                FROM skill_taxonomy
                WHERE skill_id = ANY(%s);
                """,
                (list(common_skill_ids),),
            )
            return cursor.fetchall()
    except (OperationalError, Exception) as exc:
        logger.error("Query failed: %s", exc)
        return []
    finally:
        if connection is not None:
            connection.close()


def download_submission_files(parameter_id: str, output_dir: str = "downloads"):
    """Download ZIP files for FILE_URL entries tied to a parameter_id.

    This uses Azure Blob Storage and only reads from storage.
    Returns a list of downloaded file paths.
    """
    urls = get_submission_urls_by_parameter_id(parameter_id)
    if not urls:
        return []

    os.makedirs(output_dir, exist_ok=True)
    blob_service_client = get_blob_service_client()
    downloaded_files = []

    for url, url_type in urls:
        if url_type != "FILE_URL":
            continue

        parsed_url = urlparse(url)
        if not parsed_url.path:
            continue

        path_parts = parsed_url.path.lstrip("/").split("/", 1)
        if len(path_parts) != 2:
            continue

        container_name, blob_name = path_parts
        decoded_blob_name = unquote(blob_name)
        blob_client = blob_service_client.get_blob_client(
            container=container_name,
            blob=decoded_blob_name,
        )

        filename = os.path.basename(decoded_blob_name) or f"{parameter_id}.zip"
        destination = os.path.join(output_dir, filename)

        try:
            with open(destination, "wb") as file_handle:
                download_stream = blob_client.download_blob()
                file_handle.write(download_stream.readall())

            downloaded_files.append(destination)
        except ResourceNotFoundError:
            logger.warning("Blob not found for URL: %s", url)
            continue

    return downloaded_files


def build_project_payload(admin_id: str, tenant_id: str, parameter_id: str, output_dir: str = "downloads"):
    """Build a project payload using DB fields and downloaded zip files.

    Returns a dict with title, description, skills, outcomes, and zip file paths.
    """
    submission_row = get_submission_by_parameter_id(tenant_id, parameter_id)
    if not submission_row:
        return None

    outcomes, description, _student_id, title = submission_row

    admin_skill_rows = get_admin_skill_ids(admin_id, tenant_id)
    experience_skill_rows = get_experience_skill_ids(parameter_id, tenant_id)
    common_skill_rows = get_common_skill_names(admin_skill_rows, experience_skill_rows)
    skills = [row[0] for row in common_skill_rows if row]

    zip_files = download_submission_files(parameter_id, output_dir=output_dir)

    return {
        "submission_id": parameter_id,
        "project_title": title,
        "project_description": description,
        "skills_and_technologies": skills,
        "outcomes_and_learnings": outcomes,
        "zip_files": zip_files,
    }


def submit_payload_to_backend(payload: dict, backend_url: str) -> dict:
    """Send the payload to backend.py /api/rubric-upload endpoint.

    Uses the first ZIP file in payload['zip_files'] as the upload.
    """
    zip_files = payload.get("zip_files") or []
    if not zip_files:
        raise ValueError("Payload has no zip_files to upload.")

    zip_path = zip_files[0]
    if not os.path.isfile(zip_path):
        raise FileNotFoundError(f"Zip file not found: {zip_path}")

    form_data = {
        "submission_id": payload.get("submission_id", ""),
        "project_title": payload.get("project_title", ""),
        "project_description": payload.get("project_description", ""),
        "skills_and_technologies": ",".join(payload.get("skills_and_technologies", [])),
        "outcomes_and_learnings": payload.get("outcomes_and_learnings", ""),
        "questions_per_skill": "2",
        "enforce_skill_relevance": "true",
    }

    with open(zip_path, "rb") as zip_handle:
        files = {"zip_file": (os.path.basename(zip_path), zip_handle, "application/zip")}
        response = requests.post(f"{backend_url.rstrip('/')}/api/rubric-upload", data=form_data, files=files)

    response.raise_for_status()
    return response.json()


def generate_and_send_questions(tenant_id: str, parameter_id: str, admin_id: str, backend_url: str | None = None) -> dict:
    """Generate questions payload from DB and send to backend.py.

    Requires tenant_id, parameter_id, and admin_id from the caller.
    """
    payload = build_project_payload(
        admin_id=admin_id,
        tenant_id=tenant_id,
        parameter_id=parameter_id,
    )
    if not payload:
        raise ValueError("No submission data found for the provided IDs.")

    target_url = backend_url or os.getenv("BACKEND_URL")
    if not target_url:
        raise ValueError("BACKEND_URL is not set and no backend_url was provided.")

    return submit_payload_to_backend(payload, target_url)


if __name__ == "__main__":
    response = generate_and_send_questions(
        tenant_id="22d90dd6-1cc0-42eb-8ceb-79401527774d",
        parameter_id="fa2f8e65-3079-4572-b998-359217e9aa04",
        admin_id="061ceeac-8416-433d-a6d4-397a89515eba",
    )
    logger.info("Backend response: %s", response)

