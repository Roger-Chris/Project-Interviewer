# Grading Rubric Generator

This module extracts language-agnostic signals from a student's project ZIP and uses Azure OpenAI to generate a contextual technical interview rubric.

## ✅ Features
- Safe ZIP extraction with path traversal checks
- Language-agnostic file tree, dependency manifests, and code snippets
- Azure OpenAI integration with structured JSON output
- Pydantic validation for input/output schemas

## ⚙️ Environment Variables
Set these in **`SkillForge/.env`** at the repo root (recommended) or export them in your shell:
- `AZURE_OPENAI_ENDPOINT`
- `AZURE_OPENAI_API_KEY`
- `AZURE_OPENAI_DEPLOYMENT`
- `AZURE_OPENAI_API_VERSION` (optional, defaults to `2024-02-15-preview`)

### .env setup
1. Copy `SkillForge/.env.example` to `SkillForge/.env` (repo root template — one file for all services).
2. Fill in your Azure OpenAI values (and other services you use).

## 🧪 Usage
```python
from grading_module import generate_project_rubric

payload = {
    "submission_id": "sub_12345",
    "project_title": "Forecasting Service",
    "project_description": "A service that forecasts demand.",
    "skills_and_technologies": ["Python", "Azure"],
    "outcomes_and_learnings": "Built an API and learned Azure deployments.",
    "zip_file_path": "C:/path/to/project.zip",
    "questions_per_skill": 2,
    "enforce_skill_relevance": False,
}

rubric = generate_project_rubric(payload)
print(rubric)
```

### Cost-effective controls
- `questions_per_skill` (default 2): minimum questions per skill.
- `enforce_skill_relevance` (default false): when true, drops skills not found in the codebase context.

The generator also performs a lightweight metadata-vs-code mismatch check and will
prioritize questions that validate real implementation details when a mismatch is detected.

### CLI runner
1. Create a JSON file with the submission payload.
2. Run the CLI script:

```powershell
python run_rubric.py path\to\submission.json
```

## 🌐 Unified API + demo frontend
Run everything (rubric + `/chat` + certificate + skill suggester routes) from the **SkillForge** folder:

```powershell
cd ..   # SkillForge (parent of evaluator/)
pip install -r requirements.txt
python run_api.py --port 8000
```

Or use the helper script from `SkillForge/`:

```powershell
pwsh -File scripts/run-api.ps1 -Port 8000
```

Or from **evaluator/** only (legacy):

```powershell
pip install -r ..\requirements.txt
uvicorn backend:app --reload --port 8000
```

Then open: `http://127.0.0.1:8000/`

## ⚛️ React demo frontend (TSX)
The React 16 TSX version lives in `demo_frontend_react`.

```powershell
cd demo_frontend_react
npm install
npm run dev
```

It proxies `/api` to the FastAPI server at `http://127.0.0.1:8000`.

### UI behavior
- ZIP uploads are required; there is no server-side ZIP path input.
- Each skill generates a minimum of 2 questions.
- Use “Generate 2 more” on any skill card to add more questions.


## 📝 Notes
- The rubric generator enforces **exactly 2 questions per technology**.
- Binary files, images, and common dependency folders are ignored to keep token usage low.
