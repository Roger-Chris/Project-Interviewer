"""FastAPI backend for demo rubric generation."""

from __future__ import annotations

import asyncio
import hmac
import json
import logging
import socket
import sys
from pathlib import Path
from typing import Any, Dict, Optional, List
from tempfile import NamedTemporaryFile
import os
from json import JSONDecodeError

from dotenv import dotenv_values, load_dotenv
from fastapi import BackgroundTasks, Depends, FastAPI, HTTPException, Request, UploadFile, File, Form
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

from skillforge_env import resolve_dotenv_path

# SkillForge/.env (fallback: evaluator/.env for Docker or legacy). Fixes missing keys when cwd is not evaluator/.
_SKILLFORGE_ENV_PATH = resolve_dotenv_path()
load_dotenv(_SKILLFORGE_ENV_PATH)
# Force this flag on for all runtime environments (local, CI, container, Key Vault overrides).
os.environ["VENDOR_RUBRIC_ENGINE_ENABLED"] = "true"


def _rubric_async_mode_from_env_file() -> bool:
    """True only if SkillForge/.env (resolved path) sets GENERATE_RUBRIC_ASYNC_MODE (ignores Windows/Java shell env)."""
    if not _SKILLFORGE_ENV_PATH.is_file():
        return False
    raw = (dotenv_values(_SKILLFORGE_ENV_PATH).get("GENERATE_RUBRIC_ASYNC_MODE") or "").strip().lower()
    return raw in ("1", "true", "yes")

from grading_module import generate_project_rubric, SubmissionData, CodebaseExtractor, RubricGenerator
from evaluator_service import EvaluationService

app = FastAPI(title="Rubric Demo API", version="1.0")

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

from unified_mounts import (  # noqa: E402
    ensure_skillforge_root_on_path,
    import_from_service_path,
    subproject_dir,
    try_mount,
)

ensure_skillforge_root_on_path()


def _mount_student_chat() -> None:
    ai_service_dir = subproject_dir("student-chatbot", "ai-service")

    def _do_mount() -> None:
        from routers import student_chat as student_chat_router  # type: ignore
        from core import db as student_chat_db  # type: ignore

        app.include_router(student_chat_router.router, prefix="/chat", tags=["student-chat"])
        logger.info("student-chat routes mounted at /chat from %s", ai_service_dir)

        @app.on_event("startup")
        async def _startup_student_chat_db() -> None:
            await student_chat_db.get_pool()

        @app.on_event("shutdown")
        async def _shutdown_student_chat_db() -> None:
            await student_chat_db.close_pool()

    import_from_service_path(ai_service_dir, _do_mount)


try_mount(
    subproject_dir("student-chatbot", "ai-service"),
    label="student-chat",
    mount_fn=_mount_student_chat,
    on_missing=lambda p: logger.warning(
        "student-chat service folder not found at %s; /chat routes disabled", p
    ),
)


def _log_generate_rubric_auth_at_startup() -> None:
    """Helps debug 503 vs 401: whether Python loaded a key, and whether anonymous mode is on."""
    allow_anon = os.getenv("GENERATE_RUBRIC_ALLOW_ANONYMOUS", "").lower() in ("1", "true", "yes")
    if allow_anon:
        logger.warning(
            "generate-rubric: GENERATE_RUBRIC_ALLOW_ANONYMOUS=true — API key not required on this server"
        )
        return
    header = os.getenv("GENERATE_RUBRIC_API_KEY_HEADER", "X-API-Key")
    if (os.getenv("GENERATE_RUBRIC_API_KEY") or "").strip():
        logger.info(
            "generate-rubric: GENERATE_RUBRIC_API_KEY is set — expect inbound %s (must match Java VENDOR_RUBRIC_ENGINE_API_KEY)",
            header,
        )
    else:
        logger.warning(
            "generate-rubric: GENERATE_RUBRIC_API_KEY is not set — POST /api/generate-rubric will return 503. "
            "Set the key in SkillForge/.env (same value as Java) and restart, or set GENERATE_RUBRIC_ALLOW_ANONYMOUS=true for local dev."
        )


_log_generate_rubric_auth_at_startup()


def _log_generate_rubric_response_mode_at_startup() -> None:
    """Synchronous by default: same HTTP response includes the full rubric (questions)."""
    async_mode = _rubric_async_mode_from_env_file()
    if async_mode:
        logger.info(
            "generate-rubric: GENERATE_RUBRIC_ASYNC_MODE=true — HTTP 202 + background job; "
            "rubric is not in the response body (use callback). For questions in the same response, "
            "remove GENERATE_RUBRIC_ASYNC_MODE from SkillForge/.env or set GENERATE_RUBRIC_ASYNC_MODE=false."
        )
    else:
        logger.info(
            "generate-rubric: synchronous mode (default) — HTTP 200 returns "
            '"status":"completed", "parameter_id", and "rubric" (questions) in one response.'
        )


_log_generate_rubric_response_mode_at_startup()

_evaluation_service: Optional[EvaluationService] = None


def _get_evaluation_service() -> EvaluationService:
    """Built on first use so the app can start without DB/Azure when only demo routes are used."""
    global _evaluation_service
    if _evaluation_service is None:
        _evaluation_service = EvaluationService()
    return _evaluation_service

STATIC_DIR = Path(__file__).parent / "demo_frontend"
REACT_DIST_DIR = Path(__file__).parent / "demo_frontend_react" / "dist"

if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

if REACT_DIST_DIR.exists():
    app.mount("/app", StaticFiles(directory=REACT_DIST_DIR, html=True), name="react-app")


@app.get("/health")
async def health() -> Dict[str, str]:
    return {"status": "ok"}


@app.get("/", response_model=None)
async def index(request: Request) -> FileResponse | RedirectResponse:
    index_path = STATIC_DIR / "index.html"
    if index_path.is_file():
        return FileResponse(index_path)

    # If this app is already bound to 5173 (e.g. Docker), do not redirect to the same
    # port — the socket check would succeed for our own server and loop forever.
    server = request.scope.get("server")
    serving_on_vite_port = (
        isinstance(server, tuple)
        and len(server) >= 2
        and server[1] == 5173
    )
    if not serving_on_vite_port and _is_dev_server_running("127.0.0.1", 5173):
        return RedirectResponse(url="http://127.0.0.1:5173/")

    react_index = REACT_DIST_DIR / "index.html"
    if react_index.is_file():
        return FileResponse(react_index)

    raise HTTPException(
        status_code=404,
        detail="index.html not found. Start the React dev server at http://127.0.0.1:5173 or build it to demo_frontend_react/dist.",
    )


def _is_dev_server_running(host: str, port: int) -> bool:
    try:
        with socket.create_connection((host, port), timeout=0.2):
            return True
    except OSError:
        return False


def _normalize_caller_base_url(url: str) -> str:
    return (url or "").strip().rstrip("/")


def _require_generate_rubric_auth(request: Request) -> None:
    """API key (X-API-Key) + optional allowlisted caller base URL (X-Caller-Base-Url)."""
    allow_anon = os.getenv("GENERATE_RUBRIC_ALLOW_ANONYMOUS", "").lower() in ("1", "true", "yes")
    if allow_anon:
        logger.warning(
            "GENERATE_RUBRIC_ALLOW_ANONYMOUS is set; /api/generate-rubric accepts requests without API key"
        )
        return

    expected = (os.getenv("GENERATE_RUBRIC_API_KEY") or "").strip()
    if not expected:
        logger.warning(
            "generate-rubric: rejecting request — GENERATE_RUBRIC_API_KEY is empty in this process "
            "(SkillForge/.env not loaded or key missing; fix Python env and restart)"
        )
        raise HTTPException(
            status_code=503,
            detail=(
                "Rubric generation is not configured: set GENERATE_RUBRIC_API_KEY to the same value "
                "as Java VENDOR_RUBRIC_ENGINE_API_KEY, or set GENERATE_RUBRIC_ALLOW_ANONYMOUS=true "
                "for local development only."
            ),
        )

    header_name = os.getenv("GENERATE_RUBRIC_API_KEY_HEADER", "X-API-Key")
    received = request.headers.get(header_name)
    if received is None or not str(received).strip():
        logger.warning(
            "generate-rubric: %s header missing or empty — set $key in curl/PowerShell or VENDOR_RUBRIC_ENGINE_API_KEY in Java",
            header_name,
        )
        raise HTTPException(status_code=401, detail="Missing API key")
    # hmac.compare_digest raises ValueError if lengths differ; empty/wrong-length key must be 401, not 500.
    if len(received) != len(expected) or not hmac.compare_digest(received, expected):
        logger.warning(
            "generate-rubric: %s present but does not match GENERATE_RUBRIC_API_KEY (check Java and Python use the same secret)",
            header_name,
        )
        raise HTTPException(status_code=401, detail="Invalid API key")

    allowed_raw = (os.getenv("GENERATE_RUBRIC_ALLOWED_CALLER_URL") or "").strip()
    if not allowed_raw:
        return
    allowed = {
        _normalize_caller_base_url(part)
        for part in allowed_raw.split(",")
        if _normalize_caller_base_url(part)
    }
    if not allowed:
        return

    caller_header = os.getenv("GENERATE_RUBRIC_CALLER_URL_HEADER", "X-Caller-Base-Url")
    caller_received = request.headers.get(caller_header)
    if caller_received is None:
        raise HTTPException(
            status_code=403,
            detail=f"Missing header {caller_header} (must match GENERATE_RUBRIC_ALLOWED_CALLER_URL)",
        )
    got = _normalize_caller_base_url(caller_received)
    if got not in allowed:
        raise HTTPException(status_code=403, detail="Caller base URL not allowed")


def _require_certificate_evaluator_api_key(request: Request) -> None:
    """Same auth as POST /api/generate-rubric so Spring can reuse X-API-Key."""
    _require_generate_rubric_auth(request)


def _mount_certificate_evaluator() -> None:
    from certificate_evaluator.app.unified import (  # type: ignore  # noqa: E402
        mount_certificate_evaluator,
    )

    mount_certificate_evaluator(
        app,
        dependencies=[Depends(_require_certificate_evaluator_api_key)],
    )
    logger.info(
        "certificate-evaluator mounted at POST /api/analyze-certificate "
        "(same %s as generate-rubric)",
        os.getenv("GENERATE_RUBRIC_API_KEY_HEADER", "X-API-Key"),
    )


_cert_eval_dir = subproject_dir("certificate_evaluator")
if not _cert_eval_dir.is_dir():
    logger.warning(
        "certificate_evaluator folder not found at %s; /api/analyze-certificate disabled",
        _cert_eval_dir,
    )
elif not try_mount(_cert_eval_dir, label="certificate-evaluator", mount_fn=_mount_certificate_evaluator):
    logger.error(
        "POST /api/analyze-certificate is not registered (clients will see 404). "
        "Common fix in Docker: use opencv-python-headless and ensure certificate_evaluator imports succeed at build time."
    )


def _mount_skill_suggester() -> None:
    from skill_suggester.app.unified import mount_skill_suggester  # type: ignore  # noqa: E402

    mount_skill_suggester(
        app,
        dependencies=[Depends(_require_generate_rubric_auth)],
    )
    logger.info(
        "skill_suggester mounted at POST /api/suggest-skills (same %s as generate-rubric)",
        os.getenv("GENERATE_RUBRIC_API_KEY_HEADER", "X-API-Key"),
    )


_skill_suggester_dir = subproject_dir("skill_suggester")
if _skill_suggester_dir.is_dir() and not try_mount(
    _skill_suggester_dir, label="skill_suggester", mount_fn=_mount_skill_suggester
):
    logger.error(
        "POST /api/suggest-skills is not registered; fix skill_suggester imports or env."
    )


@app.post("/api/rubric")
async def create_rubric(_: Dict[str, Any]) -> Dict[str, Any]:
    raise HTTPException(
        status_code=400,
        detail="ZIP upload required. Use /api/rubric-upload instead.",
    )


@app.post("/api/rubric-more")
async def create_more_questions(_: Dict[str, Any]) -> Dict[str, Any]:
    raise HTTPException(
        status_code=400,
        detail="ZIP upload required. Use /api/rubric-more-upload instead.",
    )


@app.post("/api/rubric-upload")
async def create_rubric_with_upload(
    submission_id: str = Form(...),
    project_title: str = Form(...),
    project_description: str = Form(...),
    skills_and_technologies: str = Form(...),
    outcomes_and_learnings: str = Form(...),
    questions_per_skill: int = Form(2),
    enforce_skill_relevance: bool = Form(True),
    zip_file: UploadFile = File(...),
) -> Dict[str, Any]:
    temp_path: Optional[str] = None
    try:
        with NamedTemporaryFile(delete=False, suffix=".zip") as temp_file:
            temp_path = temp_file.name
            temp_file.write(await zip_file.read())

        payload = {
            "submission_id": submission_id,
            "project_title": project_title,
            "project_description": project_description,
            "skills_and_technologies": [
                item.strip()
                for item in skills_and_technologies.split(",")
                if item.strip()
            ],
            "outcomes_and_learnings": outcomes_and_learnings,
            "zip_file_path": temp_path,
            "questions_per_skill": questions_per_skill,
            "enforce_skill_relevance": enforce_skill_relevance,
        }
        return generate_project_rubric(payload)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    finally:
        if temp_path and os.path.exists(temp_path):
            os.remove(temp_path)


@app.post("/api/rubric-more-upload")
async def create_more_questions_with_upload(
    submission_id: str = Form(...),
    project_title: str = Form(...),
    project_description: str = Form(...),
    skills_and_technologies: str = Form(...),
    outcomes_and_learnings: str = Form(...),
    skill: str = Form(...),
    existing_questions: str = Form(""),
    enforce_skill_relevance: bool = Form(True),
    zip_file: UploadFile = File(...),
) -> Dict[str, Any]:
    temp_path: Optional[str] = None
    try:
        with NamedTemporaryFile(delete=False, suffix=".zip") as temp_file:
            temp_path = temp_file.name
            temp_file.write(await zip_file.read())

        submission_payload = {
            "submission_id": submission_id,
            "project_title": project_title,
            "project_description": project_description,
            "skills_and_technologies": [
                item.strip()
                for item in skills_and_technologies.split(",")
                if item.strip()
            ],
            "outcomes_and_learnings": outcomes_and_learnings,
            "zip_file_path": temp_path,
            "questions_per_skill": 2,
            "enforce_skill_relevance": enforce_skill_relevance,
        }
        submission = SubmissionData.model_validate(submission_payload)
        extractor = CodebaseExtractor()
        extraction_result = extractor.extract(submission.zip_file_path)

        generator = RubricGenerator()
        question_list = [q.strip() for q in existing_questions.split("||") if q.strip()]
        new_questions = generator.generate_more_questions(
            submission=submission,
            extracted_context=extraction_result.context_blob,
            skill=skill,
            existing_questions=question_list,
        )

        return {
            "skill": skill,
            "questions": [q.model_dump() for q in new_questions],
        }
    except FileNotFoundError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    finally:
        if temp_path and os.path.exists(temp_path):
            os.remove(temp_path)


@app.post("/api/generate-rubric")
async def generate_rubric(request: Request, background_tasks: BackgroundTasks) -> JSONResponse:
    _require_generate_rubric_auth(request)
    try:
        payload = await request.json()
    except JSONDecodeError as exc:
        raise HTTPException(
            status_code=422,
            detail="Body must be valid JSON with parameter_id, tenant_id, and admin_id. "
            "On Windows PowerShell, prefer Invoke-RestMethod or curl -d @body.json instead of -d $body.",
        ) from exc
    parameter_id = payload.get("parameter_id")
    tenant_id = payload.get("tenant_id")
    admin_id = payload.get("admin_id")

    if not parameter_id or not tenant_id or not admin_id:
        raise HTTPException(status_code=422, detail="parameter_id, tenant_id, and admin_id are required")

    try:
        svc = _get_evaluation_service()
    except ValueError as exc:
        raise HTTPException(
            status_code=503,
            detail=(
                f"Rubric worker not configured: {exc} "
                "Set DB_HOST, DB_PORT, DB_USER, DB_PASSWORD, DB_NAME, and AZURE_STORAGE_CONNECTION_STRING "
                "(SkillForge/.env locally, or Azure Container App / Key Vault env vars in production)."
            ),
        ) from exc
    except Exception as exc:
        # e.g. psycopg2.OperationalError when RDS is unreachable from localhost, or Azure client init failures
        logger.exception("EvaluationService failed to initialize for /api/generate-rubric")
        raise HTTPException(
            status_code=503,
            detail=(
                f"Rubric worker unavailable (DB or blob client failed to initialize): {exc}. "
                "If this machine cannot reach RDS/security groups, run the SkillForge API where the DB is reachable "
                "or use a tunnel/VPN."
            ),
        ) from exc

    async_mode = _rubric_async_mode_from_env_file()
    if async_mode:
        background_tasks.add_task(
            svc.process_request,
            tenant_id,
            parameter_id,
            admin_id,
        )
        logger.info("Accepted async rubric generation for parameter_id=%s", parameter_id)
        return JSONResponse(
            content={"status": "accepted", "parameter_id": parameter_id},
            status_code=202,
        )

    try:
        rubric = await asyncio.to_thread(svc.run_rubric_generation, tenant_id, parameter_id, admin_id)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except FileNotFoundError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception("Synchronous rubric generation failed for parameter_id=%s", parameter_id)
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    if os.getenv("GENERATE_RUBRIC_CALLBACK_AFTER_SYNC", "true").lower() in ("1", "true", "yes"):
        await asyncio.to_thread(svc._post_callback, rubric)

    logger.info("Completed synchronous rubric generation for parameter_id=%s", parameter_id)
    return JSONResponse(
        content={
            "status": "completed",
            "parameter_id": parameter_id,
            "rubric": rubric,
        },
        status_code=200,
    )


@app.post("/api/callback")
async def receive_callback(payload: Dict[str, Any]) -> Dict[str, str]:
    logger.info("Received callback payload: %s", payload)
    return {"status": "received"}


@app.get("/api/sample")
async def sample_payload() -> Dict[str, Any]:
    sample_path = Path(__file__).parent / "submission.json"
    if not sample_path.is_file():
        raise HTTPException(status_code=404, detail="sample payload not found")
    return json.loads(sample_path.read_text(encoding="utf-8"))
