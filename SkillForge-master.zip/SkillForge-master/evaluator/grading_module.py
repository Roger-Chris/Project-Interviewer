"""Production-ready grading and fraud-detection rubric generator.

This module extracts language-agnostic signals from a student's codebase ZIP,
then uses Azure OpenAI to generate a contextual technical interview rubric.
"""

from __future__ import annotations

import json
import os
import re
import time
import zipfile
from dataclasses import dataclass
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Dict, Iterable, List, Literal, Optional, Sequence, Tuple

from openai import AzureOpenAI, RateLimitError, APITimeoutError, APIError
from pydantic import BaseModel, Field, ValidationError
from dotenv import load_dotenv
from difflib import SequenceMatcher

from skillforge_env import resolve_dotenv_path

load_dotenv(resolve_dotenv_path())


SKILL_KEYWORD_HINTS = {
    "python": ["python", "py", "pydantic", "fastapi", "django", "flask"],
    "machine learning": [
        "machine",
        "learning",
        "ml",
        "model",
        "training",
        "predict",
        "inference",
        "sklearn",
        "scikit",
        "tensorflow",
        "pytorch",
        "xgboost",
        "lightgbm",
    ],
    "data science": [
        "data",
        "science",
        "dataset",
        "pandas",
        "numpy",
        "jupyter",
        "notebook",
        "analysis",
        "eda",
        "matplotlib",
        "seaborn",
    ],
    "fastapi": ["fastapi"],
    "django": ["django"],
    "flask": ["flask"],
    "sqlite": ["sqlite", "sqlite3"],
    "postgres": ["postgres", "postgresql", "psql"],
    "mysql": ["mysql"],
    "rest": ["rest", "api", "endpoint"],
    "graphql": ["graphql"],
    "pagination": ["pagination", "page", "limit", "offset"],
    "docker": ["docker", "dockerfile"],
    "kubernetes": ["kubernetes", "k8s"],
    "redis": ["redis"],
    "celery": ["celery"],
    "react": ["react", "jsx", "tsx"],
    "frontend": ["frontend", "html", "css", "javascript", "react", "vue", "angular"],
    "html": ["html", "htm"],
}

SOFT_SKILL_KEYWORDS = {
    "communication",
    "leadership",
    "teamwork",
    "collaboration",
    "presentation",
}


def extract_keywords(text: str) -> set[str]:
    tokens = re.findall(r"[a-zA-Z][a-zA-Z0-9_\-]+", text.lower())
    return {token for token in tokens if len(token) > 2}


def filter_relevant_skills(
    skills: Sequence[str],
    context_words: set[str],
    enforce: bool = True,
) -> List[str]:
    if not enforce:
        return list(skills)

    relevant: List[str] = []
    for skill in skills:
        skill_lower = skill.lower()
        if skill_lower in SOFT_SKILL_KEYWORDS:
            continue
        hints = SKILL_KEYWORD_HINTS.get(skill_lower, [skill_lower])
        if any(_fuzzy_contains(context_words, hint) for hint in hints):
            relevant.append(skill)

    return relevant


def _fuzzy_contains(context_words: set[str], hint: str, threshold: float = 0.85) -> bool:
    if hint in context_words:
        return True

    for word in context_words:
        if abs(len(word) - len(hint)) > 4:
            continue
        if SequenceMatcher(a=word, b=hint).ratio() >= threshold:
            return True

    return False


def detect_metadata_mismatch(
    title: str,
    description: str,
    outcomes: str,
    context_words: set[str],
    threshold: float = 0.03,
) -> bool:
    metadata_words = extract_keywords(f"{title} {description} {outcomes}")
    if not metadata_words:
        return False

    overlap = metadata_words.intersection(context_words)
    overlap_ratio = len(overlap) / max(len(metadata_words), 1)
    return overlap_ratio < threshold

# -------------------------------
# Pydantic schemas
# -------------------------------


class SubmissionData(BaseModel):
    submission_id: str
    project_title: str
    project_description: str
    skills_and_technologies: List[str]
    outcomes_and_learnings: str
    zip_file_path: str
    questions_per_skill: int = Field(default=2, ge=1, le=6)
    enforce_skill_relevance: bool = False


class RubricQuestion(BaseModel):
    question_text: str
    expected_key_points: List[str]
    # conceptual = broad competency / project-fit; codebase_specific = must tie to this repo's files or code
    question_focus: Literal["conceptual", "codebase_specific"] = "conceptual"


class RubricSection(BaseModel):
    technology: str
    questions: List[RubricQuestion]


class RubricMetadata(BaseModel):
    total_tokens_used: int
    extraction_time_ms: int


class EvaluationRubric(BaseModel):
    submission_id: str
    evaluation_rubric: List[RubricSection]
    metadata: RubricMetadata


# -------------------------------
# Extraction utilities
# -------------------------------


@dataclass(frozen=True)
class ExtractionResult:
    context_blob: str
    extraction_time_ms: int


class CodebaseExtractor:
    """Extracts a compact, language-agnostic representation of a codebase."""

    MAX_EXTRACTED_BYTES = 50 * 1024 * 1024
    MIN_SNIPPET_BYTES = 512
    MAX_SNIPPET_BYTES = 500_000
    PRIORITY_NAME_TOKENS = ("main", "app", "index", "server", "api", "service")
    EXCLUDED_NAME_TOKENS = ("test", "spec", "config", "settings", "fixture")
    IGNORE_DIRS = {
        ".git",
        "node_modules",
        "venv",
        ".venv",
        "__pycache__",
        "target",
        "bin",
        "obj",
        ".idea",
        ".vscode",
        ".pytest_cache",
        ".mypy_cache",
        "dist",
        "build",
    }

    MANIFEST_FILES = {
        "package.json",
        "requirements.txt",
        "pyproject.toml",
        "pom.xml",
        "build.gradle",
        "go.mod",
        "gemfile",
        "cargo.toml",
        "composer.json",
    }

    TEXT_SOURCE_EXTENSIONS = {
        ".py",
        ".js",
        ".ts",
        ".tsx",
        ".jsx",
        ".java",
        ".kt",
        ".go",
        ".rb",
        ".php",
        ".cs",
        ".cpp",
        ".c",
        ".h",
        ".hpp",
        ".rs",
        ".swift",
        ".scala",
        ".sql",
        ".html",
        ".css",
        ".scss",
        ".md",
        ".yaml",
        ".yml",
        ".toml",
        ".json",
        ".xml",
        ".sh",
        ".ps1",
        ".bat",
    }

    BINARY_EXTENSIONS = {
        ".png",
        ".jpg",
        ".jpeg",
        ".gif",
        ".bmp",
        ".ico",
        ".pdf",
        ".zip",
        ".tar",
        ".gz",
        ".7z",
        ".exe",
        ".dll",
        ".so",
        ".dylib",
        ".class",
        ".jar",
        ".war",
        ".mp4",
        ".mp3",
        ".mov",
        ".avi",
        ".wasm",
    }

    def extract(self, zip_file_path: str) -> ExtractionResult:
        start_time = time.perf_counter()
        if not Path(zip_file_path).is_file():
            raise FileNotFoundError(f"ZIP file not found: {zip_file_path}")

        try:
            with TemporaryDirectory() as temp_dir:
                self._safe_extract_zip(zip_file_path, temp_dir)
                root_path = Path(temp_dir)

                file_tree = self._build_file_tree(root_path)
                dependency_text = self._extract_manifests(root_path)
                snippets = self._extract_snippets(root_path)

                context_blob = (
                    f"<FILE_TREE>\n{file_tree}\n</FILE_TREE>\n"
                    f"<DEPENDENCIES>\n{dependency_text}\n</DEPENDENCIES>\n"
                    f"<SNIPPETS>\n{snippets}\n</SNIPPETS>"
                )
        except zipfile.BadZipFile as exc:
            raise ValueError("Invalid or corrupted ZIP file.") from exc

        extraction_time_ms = int((time.perf_counter() - start_time) * 1000)
        return ExtractionResult(context_blob=context_blob, extraction_time_ms=extraction_time_ms)

    def _safe_extract_zip(self, zip_file_path: str, temp_dir: str) -> None:
        with zipfile.ZipFile(zip_file_path, "r") as zf:
            extracted_size = 0
            for member in zf.infolist():
                self._validate_zip_member(member)
                extracted_size += member.file_size
                if extracted_size > self.MAX_EXTRACTED_BYTES:
                    raise ValueError("Extraction limit exceeded")
                zf.extract(member, temp_dir)

    def _validate_zip_member(self, member: zipfile.ZipInfo) -> None:
        if member.filename.startswith(("/", "\\")) or ".." in Path(member.filename).parts:
            raise ValueError("Unsafe ZIP file path detected.")

    def _build_file_tree(self, root_path: Path) -> str:
        tree_entries: List[str] = []
        for path in sorted(root_path.rglob("*")):
            if path.is_dir():
                if path.name in self.IGNORE_DIRS:
                    # Skip entire ignored directories.
                    continue
                continue

            if self._should_ignore_file(path):
                continue

            relative_path = path.relative_to(root_path).as_posix()
            tree_entries.append(relative_path)

        return "\n".join(tree_entries) or "(no relevant files found)"

    def _extract_manifests(self, root_path: Path) -> str:
        manifest_chunks: List[str] = []
        for path in sorted(root_path.rglob("*")):
            if path.is_dir():
                if path.name in self.IGNORE_DIRS:
                    continue
                continue

            if path.name.lower() in self.MANIFEST_FILES and not self._should_ignore_file(path):
                content = self._read_text_file(path, max_chars=8000)
                manifest_chunks.append(f"## {path.name}\n{content}")

        return "\n\n".join(manifest_chunks) or "(no dependency manifests found)"

    def _extract_snippets(self, root_path: Path) -> str:
        candidate_files: List[Tuple[int, Path]] = []
        for path in root_path.rglob("*"):
            if path.is_dir():
                if path.name in self.IGNORE_DIRS:
                    continue
                continue

            if self._should_ignore_file(path):
                continue

            if not self._is_source_like(path):
                continue

            try:
                size = path.stat().st_size
            except OSError:
                continue

            if size < self.MIN_SNIPPET_BYTES or size > self.MAX_SNIPPET_BYTES:
                continue

            candidate_files.append((size, path))

        prioritized = sorted(
            candidate_files,
            key=lambda item: (self._priority_score(item[1]), -item[0]),
        )
        chosen_files = [path for _, path in prioritized[:3]]
        snippet_chunks: List[str] = []
        for path in chosen_files:
            content = self._read_text_file(path, max_lines=50)
            snippet_chunks.append(
                f"## {path.relative_to(root_path).as_posix()}\n{content}"
            )

        return "\n\n".join(snippet_chunks) or "(no source snippets extracted)"

    def _priority_score(self, path: Path) -> int:
        name = path.stem.lower()
        score = 0

        if any(token in name for token in self.PRIORITY_NAME_TOKENS):
            score += 10
        if any(token in name for token in self.EXCLUDED_NAME_TOKENS):
            score -= 5

        return -score

    def _should_ignore_file(self, path: Path) -> bool:
        if any(part in self.IGNORE_DIRS for part in path.parts):
            return True

        if path.suffix.lower() in self.BINARY_EXTENSIONS:
            return True

        if path.name.startswith(".") and path.suffix.lower() not in {".env", ".md"}:
            return True

        if self._is_binary_file(path):
            return True

        return False

    def _is_source_like(self, path: Path) -> bool:
        suffix = path.suffix.lower()
        if suffix in self.TEXT_SOURCE_EXTENSIONS:
            return not self._looks_minified(path)
        return False

    def _looks_minified(self, path: Path) -> bool:
        if ".min." in path.name.lower():
            return True

        try:
            with path.open("r", encoding="utf-8", errors="ignore") as handle:
                lines = [handle.readline() for _ in range(5)]
        except OSError:
            return True

        avg_len = sum(len(line) for line in lines) / max(len(lines), 1)
        return avg_len > 300

    def _is_binary_file(self, path: Path) -> bool:
        try:
            with path.open("rb") as handle:
                chunk = handle.read(2048)
        except OSError:
            return True

        if not chunk:
            return False

        if b"\x00" in chunk:
            return True

        text_chars = sum(1 for byte in chunk if 32 <= byte <= 126 or byte in (9, 10, 13))
        return text_chars / len(chunk) < 0.7

    def _read_text_file(
        self, path: Path, max_lines: Optional[int] = None, max_chars: Optional[int] = None
    ) -> str:
        try:
            with path.open("r", encoding="utf-8", errors="ignore") as handle:
                if max_lines is not None:
                    lines = []
                    for _ in range(max_lines):
                        line = handle.readline()
                        if not line:
                            break
                        lines.append(line.rstrip("\n"))
                    return "\n".join(lines)

                content = handle.read()
                if max_chars is not None:
                    content = content[:max_chars]
                return content.strip()
        except OSError:
            return "(unreadable file)"


# -------------------------------
# Azure OpenAI integration
# -------------------------------


class RubricGenerator:
    """Generates a contextual interview rubric via Azure OpenAI."""

    def __init__(self, deployment_name: Optional[str] = None) -> None:
        api_key = os.getenv("AZURE_OPENAI_API_KEY")
        endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
        if not api_key or not endpoint:
            raise ValueError("Missing Azure OpenAI credentials in AZURE_OPENAI_API_KEY or AZURE_OPENAI_ENDPOINT.")

        self.client = AzureOpenAI(
            api_key=api_key,
            azure_endpoint=endpoint,
            api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview"),
        )
        self.deployment_name = deployment_name or os.getenv("AZURE_OPENAI_DEPLOYMENT")
        if not self.deployment_name:
            raise ValueError("Missing Azure deployment name in AZURE_OPENAI_DEPLOYMENT.")

    def generate(
        self,
        submission: SubmissionData,
        extracted_context: str,
        extraction_time_ms: int,
    ) -> EvaluationRubric:
        prompt = self._build_prompt(submission, extracted_context)

        try:
            response = self.client.chat.completions.create(
                model=self.deployment_name,
                messages=prompt,
                temperature=0.2,
                response_format={"type": "json_object"},
            )
        except (RateLimitError, APITimeoutError) as exc:
            raise RuntimeError("Azure OpenAI request timed out or was rate limited.") from exc
        except APIError as exc:
            raise RuntimeError("Azure OpenAI request failed.") from exc

        if not response.choices:
            raise RuntimeError("Azure OpenAI returned no choices.")

        content = response.choices[0].message.content or ""
        try:
            payload = json.loads(content)
        except json.JSONDecodeError as exc:
            raise RuntimeError("Azure OpenAI response was not valid JSON.") from exc

        # Enforce schema with Pydantic validation.
        metadata_tokens = int(getattr(response.usage, "total_tokens", 0) or 0)
        payload.setdefault("metadata", {})
        payload["metadata"].setdefault("total_tokens_used", metadata_tokens)
        payload["metadata"].setdefault("extraction_time_ms", extraction_time_ms)
        payload.setdefault("submission_id", submission.submission_id)

        try:
            return EvaluationRubric.model_validate(payload)
        except ValidationError as exc:
            raise RuntimeError("OpenAI returned invalid schema.") from exc

    def _build_prompt(self, submission: SubmissionData, context_blob: str) -> List[Dict[str, str]]:
        context_words = extract_keywords(context_blob)
        relevant_skills = filter_relevant_skills(
            submission.skills_and_technologies,
            context_words,
            enforce=submission.enforce_skill_relevance,
        )

        if not relevant_skills:
            relevant_skills = submission.skills_and_technologies

        mismatch_flag = detect_metadata_mismatch(
            submission.project_title,
            submission.project_description,
            submission.outcomes_and_learnings,
            context_words,
        )

        mismatch_note = (
            "There is a possible mismatch between project metadata and the codebase; "
            "prioritize questions that validate real implementation details. "
            if mismatch_flag
            else ""
        )

        n = submission.questions_per_skill
        if n == 1:
            focus_rules = (
                "For each technology, generate exactly 1 question. Set question_focus to "
                "\"codebase_specific\" only. The question MUST cite concrete artifacts from codebase_context "
                "(file path, module, class, or function names that appear in the context). "
                "If the context does not contain enough detail, say so in the question and ask how they would locate it."
            )
        else:
            focus_rules = (
                f"For each technology, generate exactly {n} questions in a fixed order. "
                f"Questions 1 through {n - 1}: set question_focus to \"conceptual\". "
                "These should test understanding and how the technology fits this project (broader; may mention "
                "patterns without requiring a specific file path). "
                f"Question {n} only: set question_focus to \"codebase_specific\". "
                "It MUST explicitly reference at least one concrete artifact from codebase_context "
                "(filename, path, import, class, or function visible in the snippets). "
                "Do not invent file names that do not appear in codebase_context."
            )

        system_prompt = (
            "You are an expert technical interviewer. Generate a rubric that verifies "
            "whether a student truly built the submitted project. "
            f"Generate exactly {n} questions per technology listed by the student. "
            f"{focus_rules} "
            f"{mismatch_note} "
            "If a skill appears irrelevant to the codebase context, keep questions conservative and avoid fabrication. "
            "Every question object MUST include the field question_focus with value \"conceptual\" or \"codebase_specific\". "
            "Return JSON that matches the EvaluationRubric schema with 2-3 expected_key_points per question."
        )

        user_payload = {
            "submission": {
                **submission.model_dump(),
                "skills_and_technologies": relevant_skills,
            },
            "codebase_context": context_blob,
            "output_schema": {
                "submission_id": "string",
                "evaluation_rubric": [
                    {
                        "technology": "string (must match one from input)",
                        "questions": [
                            {
                                "question_text": "string",
                                "question_focus": "conceptual | codebase_specific",
                                "expected_key_points": ["string", "string", "string"],
                            }
                        ],
                    }
                ],
                "metadata": {
                    "total_tokens_used": "integer",
                    "extraction_time_ms": "integer",
                },
            },
        }

        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": json.dumps(user_payload)},
        ]

    def generate_more_questions(
        self,
        submission: SubmissionData,
        extracted_context: str,
        skill: str,
        existing_questions: Sequence[str],
    ) -> List[RubricQuestion]:
        system_prompt = (
            "You are an expert technical interviewer. Generate exactly 2 additional questions "
            f"for the technology '{skill}'. Avoid duplicating the existing questions. "
            "Question 1: question_focus=\"conceptual\" (broader fit for this project). "
            "Question 2: question_focus=\"codebase_specific\" (must cite filenames, paths, or symbols from codebase_context). "
            "Return JSON with a 'questions' array of objects with question_text, question_focus, and expected_key_points."
        )

        user_payload = {
            "technology": skill,
            "existing_questions": list(existing_questions),
            "codebase_context": extracted_context,
            "output_schema": {
                "questions": [
                    {
                        "question_text": "string",
                        "question_focus": "conceptual | codebase_specific",
                        "expected_key_points": ["string", "string", "string"],
                    }
                ]
            },
        }

        try:
            response = self.client.chat.completions.create(
                model=self.deployment_name,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": json.dumps(user_payload)},
                ],
                temperature=0.2,
                response_format={"type": "json_object"},
            )
        except (RateLimitError, APITimeoutError) as exc:
            raise RuntimeError("OpenAI request timed out or was rate limited.") from exc
        except APIError as exc:
            raise RuntimeError("OpenAI request failed.") from exc

        if not response.choices:
            raise RuntimeError("OpenAI returned no choices.")

        content = response.choices[0].message.content or ""
        try:
            payload = json.loads(content)
        except json.JSONDecodeError as exc:
            raise RuntimeError("OpenAI response was not valid JSON.") from exc

        questions = payload.get("questions", [])
        try:
            return [RubricQuestion.model_validate(item) for item in questions]
        except ValidationError as exc:
            raise RuntimeError("OpenAI returned invalid schema.") from exc


# -------------------------------
# Public API entry point
# -------------------------------


def generate_project_rubric(input_data: Dict) -> Dict:
    """Entry point for generating a rubric from submission data.

    Args:
        input_data: dictionary matching SubmissionData schema.

    Returns:
        Dictionary matching EvaluationRubric schema.
    """

    try:
        submission = SubmissionData.model_validate(input_data)
    except ValidationError as exc:
        raise ValueError("Input data does not match SubmissionData schema.") from exc

    extractor = CodebaseExtractor()
    extraction_result = extractor.extract(submission.zip_file_path)

    generator = RubricGenerator()
    rubric = generator.generate(
        submission=submission,
        extracted_context=extraction_result.context_blob,
        extraction_time_ms=extraction_result.extraction_time_ms,
    )

    return rubric.model_dump()
