
from __future__ import annotations

import logging
import os
import shutil
import tempfile
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional
from urllib.parse import unquote, urlparse

import psycopg2
from psycopg2 import pool
from psycopg2.extras import RealDictCursor
import requests
from azure.core.exceptions import ResourceNotFoundError
from azure.storage.blob import BlobServiceClient

from grading_module import generate_project_rubric

logger = logging.getLogger(__name__)


class EvaluationService:
    """Coordinates data fetch, rubric generation, and callback delivery."""

    def __init__(self) -> None:
        self._db_pool = self._create_db_pool()
        self._blob_service_client = self._create_blob_client()
        self._callback_url = os.getenv("JAVA_CALLBACK_URL")
        self._temp_root = Path(os.getenv("EVAL_TMP_DIR", "/tmp/evaluations"))

        if not self._callback_url:
            backend_url = os.getenv("BACKEND_URL")
            if backend_url:
                self._callback_url = f"{backend_url.rstrip('/')}/api/callback"
                logger.warning("JAVA_CALLBACK_URL not set. Falling back to %s", self._callback_url)

    @staticmethod
    def _create_db_pool() -> pool.SimpleConnectionPool:
        db_config = {
            "host": os.getenv("DB_HOST"),
            "port": int(os.getenv("DB_PORT", "5432")),
            "user": os.getenv("DB_USER"),
            "password": os.getenv("DB_PASSWORD"),
            "dbname": os.getenv("DB_NAME"),
        }
        missing = [key for key, value in db_config.items() if not value]
        if missing:
            raise ValueError(f"Missing DB environment variables: {', '.join(missing)}")
        return pool.SimpleConnectionPool(minconn=1, maxconn=5, **db_config)

    @staticmethod
    def _create_blob_client() -> BlobServiceClient:
        connection_string = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
        if not connection_string:
            raise ValueError("AZURE_STORAGE_CONNECTION_STRING is required for blob access.")
        return BlobServiceClient.from_connection_string(connection_string)

    @contextmanager
    def _get_conn(self):
        conn = self._db_pool.getconn()
        try:
            yield conn
        finally:
            self._db_pool.putconn(conn)

    def _fetch_one(self, query: str, params: Iterable) -> Optional[dict]:
        with self._get_conn() as conn:
            with conn.cursor(cursor_factory=RealDictCursor) as cursor:
                cursor.execute(query, params)
                return cursor.fetchone()

    def _fetch_all(self, query: str, params: Iterable) -> List[dict]:
        with self._get_conn() as conn:
            with conn.cursor(cursor_factory=RealDictCursor) as cursor:
                cursor.execute(query, params)
                return cursor.fetchall()

    def _fetch_submission_metadata(self, tenant_id: str, parameter_id: str) -> Optional[dict]:
        query = (
            "SELECT outcomes, description, title, status "
            "FROM student_experience_submissions "
            "WHERE parameter_id = %s AND tenant_id = %s"
        )
        return self._fetch_one(query, (parameter_id, tenant_id))

    def _fetch_common_skills(self, admin_id: str, tenant_id: str, parameter_id: str) -> List[str]:
        admin_rows = self._fetch_all(
            "SELECT skill_id FROM admin_skills WHERE admin_id = %s AND tenant_id = %s",
            (admin_id, tenant_id),
        )
        experience_rows = self._fetch_all(
            "SELECT skill_id FROM experience_skill_mapping WHERE parameter_id = %s AND tenant_id = %s",
            (parameter_id, tenant_id),
        )
        admin_skill_ids = {row["skill_id"] for row in admin_rows}
        experience_skill_ids = {row["skill_id"] for row in experience_rows}
        common_ids = list(admin_skill_ids.intersection(experience_skill_ids))
        if not common_ids:
            return []
        rows = self._fetch_all(
            "SELECT skill_name FROM skill_taxonomy WHERE skill_id = ANY(%s)",
            (common_ids,),
        )
        return [row["skill_name"] for row in rows]

    def _fetch_submission_urls(self, parameter_id: str) -> List[dict]:
        query = "SELECT url, type FROM student_submission_urls WHERE artifact_id = %s"
        return self._fetch_all(query, (parameter_id,))

    def _download_zip(self, parameter_id: str, temp_dir: Path) -> Path:
        urls = self._fetch_submission_urls(parameter_id)
        if not urls:
            raise FileNotFoundError("No submission URLs found for parameter_id.")

        for row in urls:
            if row.get("type") != "FILE_URL":
                continue
            url = row.get("url")
            if not url:
                continue
            parsed = urlparse(url)
            if not parsed.path:
                continue
            path_parts = parsed.path.lstrip("/").split("/", 1)
            if len(path_parts) != 2:
                continue
            container_name, blob_name = path_parts
            decoded_blob_name = unquote(blob_name)
            blob_client = self._blob_service_client.get_blob_client(
                container=container_name,
                blob=decoded_blob_name,
            )
            filename = os.path.basename(decoded_blob_name) or f"{parameter_id}.zip"
            destination = temp_dir / filename
            try:
                with destination.open("wb") as handle:
                    stream = blob_client.download_blob()
                    handle.write(stream.readall())
                return destination
            except ResourceNotFoundError:
                logger.warning("Blob not found for URL %s", url)
                continue

        raise FileNotFoundError("No downloadable ZIP found for parameter_id.")

    def _post_callback(self, payload: dict) -> None:
        if not self._callback_url:
            logger.error("JAVA_CALLBACK_URL is not set; cannot send callback.")
            return
        try:
            response = requests.post(self._callback_url, json=payload, timeout=30)
            response.raise_for_status()
        except requests.RequestException as exc:
            logger.exception("Failed to send callback: %s", exc)

    def run_rubric_generation(self, tenant_id: str, parameter_id: str, admin_id: str) -> Dict[str, Any]:
        """Load submission, ZIP, and return the rubric dict from the model. Raises on failure."""
        temp_dir = None
        zip_path = None
        try:
            self._temp_root.mkdir(parents=True, exist_ok=True)
            temp_dir = Path(tempfile.mkdtemp(dir=self._temp_root))

            metadata = self._fetch_submission_metadata(tenant_id, parameter_id)
            if not metadata:
                raise ValueError("Submission metadata not found.")

            status = (metadata.get("status") or "").upper()
            if status != "ASSIGNED":
                raise ValueError(f"Submission status is not ASSIGNED (status={status}).")

            skills = self._fetch_common_skills(admin_id, tenant_id, parameter_id)
            zip_path = self._download_zip(parameter_id, temp_dir)

            payload = {
                "submission_id": parameter_id,
                "project_title": metadata["title"],
                "project_description": metadata["description"],
                "skills_and_technologies": skills,
                "outcomes_and_learnings": metadata["outcomes"],
                "zip_file_path": str(zip_path),
                "questions_per_skill": 2,
                "enforce_skill_relevance": True,
            }
            return generate_project_rubric(payload)
        finally:
            if zip_path and zip_path.exists():
                try:
                    zip_path.unlink()
                except OSError:
                    logger.warning("Failed to remove zip file %s", zip_path)
            if temp_dir and temp_dir.exists():
                shutil.rmtree(temp_dir, ignore_errors=True)

    def process_request(self, tenant_id: str, parameter_id: str, admin_id: str) -> None:
        try:
            rubric = self.run_rubric_generation(tenant_id, parameter_id, admin_id)
            self._post_callback(rubric)
        except Exception as exc:
            logger.exception("Rubric generation failed: %s", exc)
            error_payload = {
                "status": "error",
                "message": str(exc),
                "parameter_id": parameter_id,
                "tenant_id": tenant_id,
                "admin_id": admin_id,
            }
            self._post_callback(error_payload)
