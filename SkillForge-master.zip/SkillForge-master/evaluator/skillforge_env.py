"""Resolve the single SkillForge/.env with fallback to evaluator/.env (Docker or legacy)."""

from pathlib import Path


def resolve_dotenv_path() -> Path:
    here = Path(__file__).resolve().parent
    shared = here.parent / ".env"
    local = here / ".env"  # evaluator/.env when SkillForge/.env is absent
    if shared.is_file():
        return shared
    if local.is_file():
        return local
    return shared
