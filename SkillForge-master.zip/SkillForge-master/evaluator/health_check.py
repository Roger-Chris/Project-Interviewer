"""Health check for OpenAI credentials and model access."""

from __future__ import annotations

import os

from dotenv import load_dotenv
from openai import AzureOpenAI

from skillforge_env import resolve_dotenv_path


def main() -> None:
    load_dotenv(resolve_dotenv_path())
    api_key = os.getenv("AZURE_OPENAI_API_KEY")
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT")
    api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview")

    if not api_key or not endpoint:
        raise SystemExit("Missing AZURE_OPENAI_API_KEY or AZURE_OPENAI_ENDPOINT in environment or .env file.")
    if not deployment:
        raise SystemExit("Missing AZURE_OPENAI_DEPLOYMENT in environment or .env file.")

    client = AzureOpenAI(
        api_key=api_key,
        azure_endpoint=endpoint,
        api_version=api_version,
    )
    response = client.chat.completions.create(
    model=deployment,
        messages=[
            {"role": "system", "content": "You are a health check."},
            {"role": "user", "content": "Reply with OK."},
        ],
        temperature=0,
        max_tokens=5,
    )

    print("Health check success:", response.choices[0].message.content)


if __name__ == "__main__":
    main()
